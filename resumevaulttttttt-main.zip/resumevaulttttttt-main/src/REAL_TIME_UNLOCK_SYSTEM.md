# Real-Time Unlock System

## GOAL
When credits are added, subscriptions change, or overrides are applied:
- ✅ Features unlock INSTANTLY (no refresh)
- ✅ Dashboard shows correct unlock status
- ✅ Buttons enable immediately
- ✅ All UI syncs across devices

## ARCHITECTURE

### 1. Central Access Check (Single Source of Truth)
**File:** `lib/checkUserAccess.js`

```js
const access = await checkUserAccess(userEmail, featureKey);
// Returns: { canUse: true/false, reason: '...', creditsNeeded: N }
```

**Reasons (Priority Order):**
1. `admin_override` - Feature unlocked by admin
2. `plan_unlimited` - Feature included in subscription
3. `plan_monthly_limit` - Monthly quota available
4. `credit_purchase` - User has credits to spend
5. `locked` - Feature is locked
6. `admin_lock` - Feature explicitly locked by admin

### 2. Credit Addition Flow

**Step 1: Admin adds credits**
```
AdminOverridePanel
  ↓ calls
addCreditsAndSync() backend function
  ↓ does
1. Update UserProfile.ai_credits
2. Log to CreditHistory
  ↓ triggers
UserProfile.subscribe() listener on frontend
  ↓ automatically
Dashboard updates, features unlock
```

**Step 2: User sees unlock instantly**
```
Frontend listens:
  base44.entities.UserProfile.subscribe((event) => {
    if (event.data?.created_by === user.email) {
      setProfile(event.data);  // Triggers re-render
    }
  });
```

### 3. Subscription Upgrade Flow

**Step 1: Admin upgrades plan**
```
AdminOverridePanel
  ↓ calls
upgradeSubscriptionAndSync() backend function
  ↓ does
1. Update UserProfile.subscription_plan
2. Log to CreditHistory
  ↓ triggers
UserProfile.subscribe() listener on frontend
  ↓ automatically
Dashboard updates, all plan features unlock
```

### 4. Override Unlock Flow

**Step 1: Admin unlocks feature**
```
AdminOverridePanel
  ↓ creates
AdminOverride record
  ↓ triggers
AdminOverride.subscribe() listener on frontend
  ↓ frontend calls
refreshAccessMap()
  ↓ automatically
Feature access recalculated, UI updates
```

## KEY COMPONENTS

### FeatureUnlockDisplay.jsx
Shows all unlocked features in real-time.
- Listens to `UserProfile` changes
- Listens to `AdminOverride` changes
- Calls `checkUserAccess()` for each feature
- Updates when any change detected

### FeatureButton.jsx
Wraps action buttons to enforce access.
- Checks access before allowing click
- Shows lock icon if blocked
- Opens upgrade modal if needed
- Works with subscriptions and credits

### Dashboard
- Shows current plan, credits, unlocks
- Real-time sync on profile change
- Updates credit balance instantly
- Removes locked badges instantly

## CRITICAL RULES

### Rule 1: Update UserProfile, Sync Follows
```js
// Update profile (triggers listeners)
await base44.entities.UserProfile.update(profileId, {
  ai_credits: newCredits,
  subscription_plan: newPlan,
});

// Frontend listener fires automatically
base44.entities.UserProfile.subscribe((event) => {
  if (event.data?.created_by === user.email) {
    // UI UPDATES AUTOMATICALLY — NO REFRESH NEEDED
  }
});
```

### Rule 2: Filter by created_by (User Isolation)
```js
// Wrong — updates ALL profiles
const profiles = await base44.entities.UserProfile.filter({
  subscription_plan: 'pro'
});

// Right — only this user's profile
const profiles = await base44.entities.UserProfile.filter({
  created_by: userEmail
});
```

### Rule 3: Admin Isolation with User Email Lowercase
```js
// Filter overrides only for THIS user
const overrides = await base44.entities.AdminOverride.filter({
  user_email: userEmail.toLowerCase(),
  is_active: true,
});
```

### Rule 4: Check Admin Role Safely
```js
// Frontend (user object has role)
if (user?.role === 'admin') {
  // Show admin UI
}

// Backend (verify via token)
const user = await base44.auth.me();
if (user.role !== 'admin') {
  return Response.json({ error: 'Forbidden' }, { status: 403 });
}
```

## UNLOCK SCENARIOS

### Scenario 1: Admin Adds 50 Credits
```
1. Admin clicks "Add Credits" in AdminOverridePanel
2. Input: 50 credits
3. Backend: UPDATE UserProfile SET ai_credits = 50
4. Trigger: UserProfile event fires
5. Frontend: Dashboard listens, calls refreshAccessMap()
6. Result: All 5-credit-cost features unlock instantly
7. Display: Credit balance shows 50
8. Buttons: Feature buttons now enabled
```

### Scenario 2: User Subscribes to Pro
```
1. User completes Stripe checkout
2. Backend: UPDATE UserProfile SET subscription_plan = 'pro'
3. Trigger: UserProfile event fires
4. Frontend: Dashboard listens, refreshes
5. Result: All pro features unlock instantly
6. Display: Plan badge changes to "Pro"
7. Buttons: 80 monthly resumes now available
8. Features: Job Analyzer, ATS tools, Cover Letters unlock
```

### Scenario 3: Credits Hit 0
```
1. User spends last 5 credits on resume generation
2. Backend: UPDATE UserProfile SET ai_credits = 0
3. Trigger: UserProfile event fires
4. Frontend: Dashboard refreshes access map
5. Result: Credit-based features lock again
6. Display: Credit balance shows 0
7. Buttons: Feature buttons disabled, show upgrade prompt
```

### Scenario 4: Admin Removes Override
```
1. Admin removes feature unlock override
2. Backend: UPDATE AdminOverride SET is_active = false
3. Trigger: AdminOverride event fires
4. Frontend: FeatureUnlockDisplay listens, calls refreshAccessMap()
5. Result: Feature locked again (if no subscription/credits)
6. Display: Lock icon returns
7. Buttons: Feature disabled again
```

## TESTING

### Test 1: Credits Add Instantly
```
Window A: Admin page
Window B: Dashboard

1. Admin adds 50 credits
2. Window B: See 50 credits instantly (no refresh)
3. Window B: Feature buttons enable instantly
```

### Test 2: Subscription Unlocks All Features
```
Window A: Admin page  
Window B: Dashboard

1. Admin upgrades to Pro
2. Window B: See "Pro" badge instantly
3. Window B: 10+ features unlock instantly
4. Window B: Monthly limits show (80 resumes, etc)
```

### Test 3: Cross-Device Sync
```
Device A: Desktop logged in
Device B: Mobile logged in

1. Admin adds credits on Desktop A
2. Device B: Mobile dashboard updates instantly
3. Both sync without refresh
```

### Test 4: Credits Deduct on Use
```
1. User has 50 credits
2. User generates resume (costs 5)
3. Dashboard: Shows 45 credits
4. CreditHistory: New entry logged
5. No refresh needed
```

## DEBUGGING CHECKLIST

- [ ] UserProfile has `created_by` field
- [ ] AdminOverride has `user_email` field (lowercase)
- [ ] Filter queries use lowercase for email
- [ ] AdminOverridePanel calls backend sync functions
- [ ] Backend updates UserProfile (triggers listeners)
- [ ] Frontend FeatureUnlockDisplay subscribes to changes
- [ ] checkUserAccess() returns correct result
- [ ] Real-time listeners trigger without page refresh
- [ ] CreditHistory logs all transactions
- [ ] Admin role check works on backend

## EMERGENCY FIXES

### Features not unlocking?
1. Check UserProfile.ai_credits was updated (query DB)
2. Check UserProfile.subscription_plan was updated
3. Check frontend is calling checkUserAccess()
4. Check real-time subscription is active

### Profile not syncing?
1. Check user email matches in filter (case-insensitive)
2. Check created_by field populated correctly
3. Check UserProfile.subscribe() listener is attached
4. Check browser console for errors

### Credits not deducting?
1. Check recordFeatureUsage() was called
2. Check CreditHistory entries exist
3. Check UserProfile.ai_credits updated
4. Check backend returned success

### Override not applying?
1. Check AdminOverride record created
2. Check user_email is lowercase
3. Check is_active = true
4. Check AdminOverride.subscribe() listener firing