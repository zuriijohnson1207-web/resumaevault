import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

// Monthly usage limits per plan per feature
export const PLAN_LIMITS = {
  free: {
    resume: 2,
    cover_letter: 2,
    job_analysis: 2,
    follow_up_email: 2,
    mock_interview: 0,
    auto_apply: 0,
    salary_negotiation: 0,
    career_roadmap: 0,
    portfolio_ideas: 0,
  },
  pro: {
    resume: 80,
    cover_letter: Infinity,
    job_analysis: Infinity,
    follow_up_email: Infinity,
    mock_interview: 20,
    auto_apply: 50,
    salary_negotiation: Infinity,
    career_roadmap: Infinity,
    portfolio_ideas: Infinity,
  },
  elite: {
    resume: 150,
    cover_letter: Infinity,
    job_analysis: Infinity,
    follow_up_email: Infinity,
    mock_interview: Infinity,
    auto_apply: 200,
    salary_negotiation: Infinity,
    career_roadmap: Infinity,
    portfolio_ideas: Infinity,
  },
};

export const FEATURE_LABELS = {
  resume: 'AI Resume',
  cover_letter: 'Cover Letter',
  job_analysis: 'Job Analysis',
  follow_up_email: 'Follow-Up Email',
  mock_interview: 'Mock Interview',
  auto_apply: 'Auto Apply',
  salary_negotiation: 'Salary Negotiation',
  career_roadmap: 'Career Roadmap',
  portfolio_ideas: 'Portfolio Ideas',
};

// Credit cost per feature — defined at module level so it's accessible everywhere
export const CREDIT_COSTS = {
  resume: 5,
  cover_letter: 3,
  job_analysis: 2,
  follow_up_email: 2,
  mock_interview: 10,
  auto_apply: 2,
  salary_negotiation: 3,
  career_roadmap: 3,
  portfolio_ideas: 3,
};

export function usePlanLimits() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [overrides, setOverrides] = useState([]);
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const fetchProfile = async () => {
    if (!user?.email) return;
    try {
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      setProfile(profiles[0] || null);
    } catch (err) {
      console.error('Failed to fetch profile:', err);
    }
  };

  useEffect(() => {
    if (!user?.email) return;
    fetchProfile().then(() => setLoading(false));

    // Real-time sync — update immediately when profile changes (admin overrides, payments, etc.)
    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      // Trigger on any update to the current user's profile (created_by match or email match)
      if ((event.type === 'update' || event.type === 'create')) {
        const eventEmail = event.data?.created_by || event.data?.email;
        const userEmail = user.email?.toLowerCase();
        if (eventEmail?.toLowerCase() === userEmail) {
          // Force refetch to ensure latest state
          fetchProfile();
        }
      }
    });
    return () => unsubscribe();
  }, [user?.email]);

  // Load and subscribe to admin overrides
  useEffect(() => {
    if (!user?.email) return;

    const loadOverrides = async () => {
      try {
        const active = await base44.entities.AdminOverride.filter({
          user_email: user.email,
          is_active: true,
        });
        setOverrides(active);
      } catch (e) {
        console.error('Failed to load overrides:', e);
      }
    };

    loadOverrides();

    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email === user.email) {
        if (event.type === 'create' || event.type === 'update') {
          setOverrides(prev => {
            const filtered = prev.filter(o => o.id !== event.data.id);
            return event.data.is_active ? [...filtered, event.data] : filtered;
          });
        }
      }
    });

    return unsubscribe;
  }, [user?.email]);

  const plan = profile?.subscription_plan || 'free';
  const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;
  const usageCounts = profile?.usage_counts || {};

  /**
   * Admins bypass ALL limits — full access to every feature always.
   */
  const canUse = (feature) => {
    if (isAdmin) return true;

    // Check feature unlock override
    const featureUnlock = overrides.find(
      o => o.override_type === 'feature_unlock' && o.features_affected?.includes(feature)
    );
    if (featureUnlock) return true;

    // Check feature lock override
    const featureLock = overrides.find(
      o => o.override_type === 'feature_lock' && o.features_affected?.includes(feature)
    );
    if (featureLock) return false;

    const limit = limits[feature];
    if (limit === Infinity) return true;
    if (limit > 0) {
      const used = usageCounts[feature] || 0;
      if (used < limit) return true;
    }
    // Credits as fallback unlock for ANY feature
    const creditCost = CREDIT_COSTS[feature] || 1;
    return (profile?.ai_credits || 0) >= creditCost;
  };

  const isUnlockedByCreditsOnly = (feature) => {
    if (isAdmin) return false; // admins never need credit unlock messaging
    const limit = limits[feature];
    if (limit === Infinity) return false;
    if (limit > 0) {
      const used = usageCounts[feature] || 0;
      if (used < limit) return false;
    }
    const creditCost = CREDIT_COSTS[feature] || 1;
    return (profile?.ai_credits || 0) >= creditCost;
  };

  const getUsage = (feature) => {
    if (isAdmin) return { used: 0, limit: Infinity, remaining: Infinity };
    const limit = limits[feature];
    const used = usageCounts[feature] || 0;
    return { used, limit, remaining: limit === Infinity ? Infinity : Math.max(0, limit - used) };
  };

  const incrementUsage = async (feature) => {
    if (!profile) return;
    if (isAdmin) return;
    const current = usageCounts[feature] || 0;
    const newCounts = { ...usageCounts, [feature]: current + 1 };
    const creditCost = CREDIT_COSTS[feature] || 1;
    const currentCredits = profile.ai_credits || 0;
    const newCredits = Math.max(0, currentCredits - creditCost);
    await base44.entities.UserProfile.update(profile.id, { usage_counts: newCounts, ai_credits: newCredits });
    setProfile(p => ({ ...p, usage_counts: newCounts, ai_credits: newCredits }));
    // Log to credit history
    base44.entities.CreditHistory.create({
      user_email: user?.email || profile.created_by || '',
      action: 'deduct',
      feature: feature,
      credits_spent: creditCost,
      credits_added: 0,
      balance_after: newCredits,
      source: profile.subscription_plan || 'free',
      notes: `Used ${FEATURE_LABELS[feature] || feature}`,
    }).catch(() => {});
  };

  return { profile, plan, limits, canUse, isUnlockedByCreditsOnly, getUsage, incrementUsage, loading, CREDIT_COSTS, isAdmin, refreshProfile: fetchProfile };
}