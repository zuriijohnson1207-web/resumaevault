import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { checkUserAccess, FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';
import { useAuth } from '@/lib/AuthContext';

/**
 * Real-time access hook
 * Subscribes to profile + override changes
 * Triggers instant access recalculation
 * No refresh needed
 */
export function useRealTimeAccess(featureKey) {
  const { user } = useAuth();
  const [access, setAccess] = useState({ canUse: false, reason: 'loading', creditsNeeded: 0 });
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkAccess = useCallback(async () => {
    if (!user?.email || !featureKey) {
      setLoading(false);
      return;
    }
    try {
      const result = await checkUserAccess(user.email, featureKey);
      setAccess(result);
    } catch (e) {
      console.error('Access check error:', e);
      setAccess({ canUse: false, reason: 'error', creditsNeeded: 0 });
    }
    setLoading(false);
  }, [user?.email, featureKey]);

  // Initial load
  useEffect(() => {
    checkAccess();
  }, [checkAccess]);

  // Real-time profile changes
  useEffect(() => {
    if (!user?.email) return;

    const unsubscribeProfile = base44.entities.UserProfile.subscribe((event) => {
      if (event.data?.created_by?.toLowerCase() === user.email.toLowerCase()) {
        setProfile(event.data);
        checkAccess();
      }
    });

    return () => unsubscribeProfile();
  }, [user?.email, checkAccess]);

  // Real-time override changes
  useEffect(() => {
    if (!user?.email) return;

    const unsubscribeOverride = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email?.toLowerCase() === user.email.toLowerCase()) {
        checkAccess();
      }
    });

    return () => unsubscribeOverride();
  }, [user?.email, checkAccess]);

  return { access, profile, loading, refetch: checkAccess };
}

/**
 * Hook to get all unlocked features for current user
 */
export function useUnlockedFeatures() {
  const { user } = useAuth();
  const [unlocked, setUnlocked] = useState([]);
  const [loading, setLoading] = useState(true);

  const checkAll = useCallback(async () => {
    if (!user?.email) {
      setLoading(false);
      return;
    }

    const results = {};
    for (const featureKey of Object.keys(FEATURE_DEFINITIONS)) {
      try {
        const access = await checkUserAccess(user.email, featureKey);
        results[featureKey] = access.canUse;
      } catch (e) {
        results[featureKey] = false;
      }
    }
    setUnlocked(results);
    setLoading(false);
  }, [user?.email]);

  // Initial load
  useEffect(() => {
    checkAll();
  }, [checkAll]);

  // Real-time sync
  useEffect(() => {
    if (!user?.email) return;

    const unsubProfile = base44.entities.UserProfile.subscribe((event) => {
      if (event.data?.created_by?.toLowerCase() === user.email.toLowerCase()) {
        checkAll();
      }
    });

    const unsubOverride = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email?.toLowerCase() === user.email.toLowerCase()) {
        checkAll();
      }
    });

    return () => {
      unsubProfile();
      unsubOverride();
    };
  }, [user?.email, checkAll]);

  return { unlocked, loading, refetch: checkAll };
}