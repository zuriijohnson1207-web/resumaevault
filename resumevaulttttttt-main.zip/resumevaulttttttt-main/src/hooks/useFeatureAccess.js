import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const FEATURE_PRICING = {
  resume_generation: { free: 2, pro: 80, elite: 150, credit_cost: 5 },
  cover_letter: { free: 2, pro: -1, elite: -1, credit_cost: 3 },
  job_analysis: { free: 2, pro: -1, elite: -1, credit_cost: 2 },
  ats_score: { free: 0, pro: 20, elite: -1, credit_cost: 1 },
  advanced_ats_report: { free: false, pro: 10, elite: -1, credit_cost: 3 },
  resume_templates: { free: 3, pro: 10, elite: -1, credit_cost: 0 },
  resume_comparison: { free: false, pro: true, elite: true, credit_cost: 0 },
  auto_apply: { free: 0, pro: 50, elite: 200, credit_cost: 2 },
  library_editing: { free: true, pro: true, elite: true, credit_cost: 0 },
  pdf_download: { free: true, pro: true, elite: true, credit_cost: 0 },
  word_download: { free: false, pro: true, elite: true, credit_cost: 0 },
  mock_interview: { free: false, pro: 20, elite: -1, credit_cost: 10 },
  salary_negotiation: { free: false, pro: true, elite: true, credit_cost: 3 },
  career_roadmap: { free: false, pro: true, elite: true, credit_cost: 3 },
  portfolio_ideas: { free: false, pro: true, elite: true, credit_cost: 0 },
};

export function useFeatureAccess(userEmail, userProfile) {
  const [overrides, setOverrides] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) return;

    const loadOverrides = async () => {
      try {
        const activeOverrides = await base44.entities.AdminOverride.filter({
          user_email: userEmail,
          is_active: true,
        });
        setOverrides(activeOverrides);
      } catch (e) {
        console.error('Failed to load overrides:', e);
      } finally {
        setLoading(false);
      }
    };

    loadOverrides();

    // Subscribe to override changes
    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email === userEmail && event.data?.is_active) {
        if (event.type === 'create' || event.type === 'update') {
          setOverrides(prev => {
            const filtered = prev.filter(o => o.id !== event.data.id);
            return [...filtered, event.data];
          });
        } else if (event.type === 'delete') {
          setOverrides(prev => prev.filter(o => o.id !== event.id));
        }
      }
    });

    return unsubscribe;
  }, [userEmail]);

  const getFeatureAccess = (featureKey) => {
    if (!userProfile) return { access: false, reason: 'No profile' };

    // Check for feature unlock override
    const featureUnlockOverride = overrides.find(
      o => o.override_type === 'feature_unlock' && o.features_affected?.includes(featureKey)
    );
    if (featureUnlockOverride) return { access: true, reason: 'admin_override' };

    // Check for feature lock override
    const featureLockOverride = overrides.find(
      o => o.override_type === 'feature_lock' && o.features_affected?.includes(featureKey)
    );
    if (featureLockOverride) return { access: false, reason: 'admin_lock' };

    const plan = userProfile.subscription_plan || 'free';
    const credits = userProfile.ai_credits || 0;
    const featureDef = FEATURE_PRICING[featureKey];

    if (!featureDef) return { access: false, reason: 'Unknown feature' };

    // Check plan access
    const planLimit = featureDef[plan];
    if (planLimit === false || planLimit === 0) {
      // Feature not available in this plan, check credits
      if (credits >= featureDef.credit_cost) {
        return { access: true, reason: 'credit_purchase', creditCost: featureDef.credit_cost };
      }
      return { access: false, reason: 'plan_locked', needsUpgrade: true };
    }

    // Feature available in plan
    return { access: true, reason: 'plan_included' };
  };

  const hasTemporaryAccess = (featureKey) => {
    return overrides.some(
      o => o.override_type === 'temporary_access' &&
        o.features_affected?.includes(featureKey) &&
        new Date(o.temporary_until) > new Date()
    );
  };

  const getActiveOverrides = () => {
    return overrides.map(o => ({
      id: o.id,
      type: o.override_type,
      plan: o.plan_granted,
      credits: o.credits_amount,
      features: o.features_affected,
      until: o.temporary_until,
      reason: o.reason,
      appliedBy: o.admin_email,
    }));
  };

  return {
    loading,
    getFeatureAccess,
    hasTemporaryAccess,
    getActiveOverrides,
    FEATURE_PRICING,
  };
}