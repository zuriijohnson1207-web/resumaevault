import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

// Unified feature definitions — single source of truth
export const UNIFIED_FEATURES = {
  resume: { label: 'AI Resume', creditCost: 5, free: 2, pro: 80, elite: 150 },
  cover_letter: { label: 'Cover Letter', creditCost: 3, free: 2, pro: Infinity, elite: Infinity },
  job_analysis: { label: 'Job Analysis', creditCost: 2, free: 2, pro: Infinity, elite: Infinity },
  follow_up_email: { label: 'Follow-Up Email', creditCost: 2, free: 2, pro: Infinity, elite: Infinity },
  mock_interview: { label: 'Mock Interview', creditCost: 10, free: 0, pro: 20, elite: Infinity },
  auto_apply: { label: 'Auto Apply', creditCost: 2, free: 0, pro: 50, elite: 200 },
  salary_negotiation: { label: 'Salary Negotiation', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  career_roadmap: { label: 'Career Roadmap', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  portfolio_ideas: { label: 'Portfolio Ideas', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  ats_score: { label: 'ATS Score', creditCost: 1, free: 0, pro: Infinity, elite: Infinity },
  advanced_ats_report: { label: 'Advanced ATS Report', creditCost: 3, free: false, pro: true, elite: true },
  resume_templates: { label: 'Resume Templates', creditCost: 0, free: 3, pro: Infinity, elite: Infinity },
  resume_comparison: { label: 'Resume Comparison', creditCost: 0, free: false, pro: true, elite: true },
  library_editing: { label: 'Library Editing', creditCost: 0, free: true, pro: true, elite: true },
  pdf_download: { label: 'PDF Download', creditCost: 0, free: true, pro: true, elite: true },
  word_download: { label: 'Word Download', creditCost: 0, free: false, pro: true, elite: true },
};

export function useUnifiedAccess() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [overrides, setOverrides] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch user profile
  useEffect(() => {
    if (!user?.email) return;

    const fetchProfile = async () => {
      try {
        const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
        setProfile(profiles[0] || null);
      } catch (err) {
        console.error('Failed to fetch profile:', err);
      }
    };

    fetchProfile();

    // Real-time profile sync
    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      if (event.type === 'update' && event.data?.created_by?.toLowerCase() === user.email?.toLowerCase()) {
        setProfile(event.data);
      }
    });

    return () => unsubscribe();
  }, [user?.email]);

  // Fetch and subscribe to admin overrides
  useEffect(() => {
    if (!user?.email) return;

    const loadOverrides = async () => {
      try {
        const active = await base44.entities.AdminOverride.filter({
          user_email: user.email,
          is_active: true,
        });
        setOverrides(active);
        setLoading(false);
      } catch (e) {
        console.error('Failed to load overrides:', e);
        setLoading(false);
      }
    };

    loadOverrides();

    // Real-time override sync
    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email === user.email) {
        if (event.type === 'create' || event.type === 'update') {
          setOverrides(prev => {
            const filtered = prev.filter(o => o.id !== event.data.id);
            return event.data.is_active ? [...filtered, event.data] : filtered;
          });
        }
      }
    });

    return () => unsubscribe();
  }, [user?.email]);

  /**
   * CENTRAL ACCESS CHECK — This is the single source of truth for feature access
   * Priority: Admin override > Subscription + Usage > Credits > Plan limit
   */
  const checkAccess = (featureKey) => {
    // Admins always have access
    if (user?.role === 'admin') {
      return { canUse: true, reason: 'admin', creditsNeeded: 0 };
    }

    if (!profile) {
      return { canUse: false, reason: 'no_profile', creditsNeeded: 0 };
    }

    const feature = UNIFIED_FEATURES[featureKey];
    if (!feature) {
      return { canUse: false, reason: 'unknown_feature', creditsNeeded: 0 };
    }

    // Check feature unlock override
    const featureUnlock = overrides.find(
      o => o.override_type === 'feature_unlock' && o.features_affected?.includes(featureKey)
    );
    if (featureUnlock) {
      return { canUse: true, reason: 'admin_override', creditsNeeded: 0 };
    }

    // Check feature lock override
    const featureLock = overrides.find(
      o => o.override_type === 'feature_lock' && o.features_affected?.includes(featureKey)
    );
    if (featureLock) {
      return { canUse: false, reason: 'admin_lock', creditsNeeded: 0 };
    }

    // Check temporary access override
    const tempAccess = overrides.find(
      o => o.override_type === 'temporary_access' &&
        o.features_affected?.includes(featureKey) &&
        new Date(o.temporary_until) > new Date()
    );
    if (tempAccess) {
      return { canUse: true, reason: 'temporary_access', creditsNeeded: 0 };
    }

    // Check plan-based access
    const plan = profile.subscription_plan || 'free';
    const planLimit = feature[plan];
    const usage = profile.usage_counts?.[featureKey] || 0;
    const credits = profile.ai_credits || 0;

    // Plan includes unlimited uses
    if (planLimit === Infinity) {
      return { canUse: true, reason: 'plan_unlimited', creditsNeeded: 0 };
    }

    // Plan includes monthly limit
    if (typeof planLimit === 'number' && planLimit > 0 && usage < planLimit) {
      return { canUse: true, reason: 'plan_monthly_limit', creditsNeeded: 0 };
    }

    // Feature requires credits
    if (credits >= feature.creditCost) {
      return { canUse: true, reason: 'credit_purchase', creditsNeeded: feature.creditCost };
    }

    // Locked for this plan, no credits
    return { canUse: false, reason: 'locked', creditsNeeded: feature.creditCost };
  };

  /**
   * Get usage info for a feature (used/limit/remaining)
   */
  const getUsageInfo = (featureKey) => {
    if (user?.role === 'admin') {
      return { used: 0, limit: Infinity, remaining: Infinity };
    }

    if (!profile) return { used: 0, limit: 0, remaining: 0 };

    const feature = UNIFIED_FEATURES[featureKey];
    if (!feature) return { used: 0, limit: 0, remaining: 0 };

    const plan = profile.subscription_plan || 'free';
    const limit = feature[plan];
    const used = profile.usage_counts?.[featureKey] || 0;

    return {
      used,
      limit: limit === true ? Infinity : limit === false ? 0 : limit || 0,
      remaining: limit === Infinity ? Infinity : Math.max(0, limit - used),
    };
  };

  /**
   * Increment usage and deduct credits
   */
  const useFeature = async (featureKey) => {
    if (!profile || user?.role === 'admin') return;

    const feature = UNIFIED_FEATURES[featureKey];
    if (!feature) return;

    try {
      const newUsage = { ...profile.usage_counts, [featureKey]: (profile.usage_counts?.[featureKey] || 0) + 1 };
      const access = checkAccess(featureKey);
      let newCredits = profile.ai_credits || 0;

      // Deduct credits if using credit-based access
      if (access.reason === 'credit_purchase') {
        newCredits = Math.max(0, newCredits - feature.creditCost);
      }

      // Update profile
      await base44.entities.UserProfile.update(profile.id, {
        usage_counts: newUsage,
        ai_credits: newCredits,
      });

      // Log to credit history
      if (access.reason === 'credit_purchase') {
        await base44.entities.CreditHistory.create({
          user_email: user.email,
          action: 'deduct',
          feature: featureKey,
          credits_spent: feature.creditCost,
          credits_added: 0,
          balance_after: newCredits,
          source: 'feature_usage',
          notes: `Used ${feature.label}`,
        }).catch(() => {});
      }

      return { success: true };
    } catch (err) {
      console.error('Failed to use feature:', err);
      return { success: false, error: err.message };
    }
  };

  return {
    profile,
    overrides,
    loading,
    checkAccess,
    getUsageInfo,
    useFeature,
    UNIFIED_FEATURES,
  };
}