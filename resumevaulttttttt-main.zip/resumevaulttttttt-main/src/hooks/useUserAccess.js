import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { checkUserAccess, FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';

/**
 * React hook that wraps checkUserAccess with real-time sync
 * This hook automatically updates when profile or overrides change
 */
export function useUserAccess(userEmail) {
  const [accessCache, setAccessCache] = useState({});
  const [loading, setLoading] = useState(true);

  // Check access for a feature
  const getAccess = useCallback(async (featureKey) => {
    if (!userEmail) return { canUse: false, reason: 'no_email', creditsNeeded: 0 };

    // Check cache first
    const cacheKey = `${userEmail}:${featureKey}`;
    if (accessCache[cacheKey]) {
      return accessCache[cacheKey];
    }

    try {
      const result = await checkUserAccess(userEmail, featureKey);
      setAccessCache(prev => ({ ...prev, [cacheKey]: result }));
      return result;
    } catch (e) {
      console.error('getAccess error:', e);
      return { canUse: false, reason: 'error', creditsNeeded: 0 };
    }
  }, [userEmail, accessCache]);

  // Invalidate cache when profile or overrides change
  const invalidateCache = useCallback(() => {
    setAccessCache({});
  }, []);

  // Set up real-time listeners
  useEffect(() => {
    if (!userEmail) return;

    const userEmail_lower = userEmail.toLowerCase();

    // Listen to profile changes
    const unsubProfile = base44.entities.UserProfile.subscribe((event) => {
      if (event.data?.created_by?.toLowerCase() === userEmail_lower) {
        invalidateCache();
      }
    });

    // Listen to override changes
    const unsubOverride = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email?.toLowerCase() === userEmail_lower) {
        invalidateCache();
      }
    });

    setLoading(false);

    return () => {
      unsubProfile();
      unsubOverride();
    };
  }, [userEmail, invalidateCache]);

  return {
    getAccess,
    invalidateCache,
    loading,
    FEATURE_DEFINITIONS,
  };
}