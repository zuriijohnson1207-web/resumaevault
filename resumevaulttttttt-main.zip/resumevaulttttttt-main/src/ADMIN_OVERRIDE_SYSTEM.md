# Admin Override & Credit Unlock System

## Overview
Complete admin control system for managing user credits, plans, and feature access in real-time.

## Architecture

### Entities
- **AdminOverride** — Audit trail of all admin changes (credits, plans, features)
- **UserProfile** — User plan and credit state
- **CreditHistory** — Financial/usage transactions

### Components
- **AdminOverridePanel** — Admin form to apply overrides
- **AdminOverrideLogsPanel** — View override history
- **OverrideBadges** — Show active overrides on user dashboard
- **useFeatureAccess** — Check what features are unlocked (new)
- **usePlanLimits** — Enhanced to check overrides

## Functionality

### Admin Override Types
1. **credit_add** — Add credits to user
2. **credit_remove** — Remove credits
3. **credit_reset** — Reset to 0
4. **plan_upgrade** — Upgrade user plan
5. **plan_downgrade** — Downgrade user plan
6. **feature_unlock** — Unlock specific features
7. **feature_lock** — Lock specific features
8. **temporary_access** — Give time-limited access
9. **subscription_extend** — Extend subscription
10. **override_cancel** — Cancel override

### Features Controllable
- resume_generation
- cover_letter
- job_analysis
- ats_score
- advanced_ats_report
- resume_templates
- resume_comparison
- auto_apply
- library_editing
- pdf_download
- word_download
- mock_interview
- salary_negotiation
- career_roadmap
- portfolio_ideas

## Usage Guide

### For Admins
1. Go to `/admin` → Users tab
2. Click user to expand
3. Click "⚡ Advanced Override System"
4. Click "Add Override"
5. Select override type
6. Fill in details (credits, plan, features, days, reason)
7. Click "Apply Override"
8. View logs below to confirm

### For Users
- Dashboard shows active overrides at top
- Features unlock immediately when override applied
- Can use feature right away without refresh needed
- Override details visible in dashboard badge

## Real-Time Sync

### Data Flow
1. Admin applies override
2. AdminOverride entity created
3. UserProfile updated (if credits/plan changed)
4. Both entities broadcast changes
5. User's hooks detect changes
6. Dashboard/features update instantly

### Key Sync Points
- `useFeatureAccess()` — Subscribes to AdminOverride changes
- `usePlanLimits()` — Subscribes to AdminOverride + UserProfile changes
- `OverrideBadges` — Real-time override display
- `PlanGate` — Feature access gates updated

## Testing Checklist

### 1. Admin Credits Override
- [ ] Admin adds 100 credits to user
- [ ] User sees credit increase immediately on dashboard
- [ ] User can use paid features with new credits
- [ ] CreditHistory logged

### 2. Admin Plan Upgrade
- [ ] Admin upgrades user to Pro
- [ ] User sees "Pro" badge on dashboard
- [ ] All Pro features unlock immediately
- [ ] AdminOverride log shows change

### 3. Admin Feature Unlock
- [ ] Admin unlocks "mock_interview" for free user
- [ ] Free user can access mock interview without upgrade
- [ ] Override badge shows on dashboard
- [ ] Feature accessible immediately (no refresh needed)

### 4. Admin Temporary Access
- [ ] Admin gives 7-day access to "auto_apply"
- [ ] User sees override with expiration date
- [ ] Can use auto_apply for 7 days
- [ ] After 7 days, access revokes
- [ ] Still works if plan allows

### 5. Sync After Refresh/Logout
- [ ] Admin applies override
- [ ] User logs out/refresh page
- [ ] Override persists
- [ ] Feature still unlocked
- [ ] No data loss

### 6. Multiple Overrides (Highest Wins)
- [ ] User has Pro plan + feature lock on "resume_generation"
- [ ] Feature should be locked (lock wins)
- [ ] Remove feature lock override
- [ ] Feature unlocks (Pro plan wins)
- [ ] Add temporary access instead
- [ ] Feature unlocked (override wins)

### 7. Override Removal
- [ ] Admin applies override
- [ ] Admin removes override
- [ ] User returns to normal plan/credit state
- [ ] Features lock if plan doesn't allow
- [ ] AdminOverride.is_active = false

### 8. Stripe + Override Coexist
- [ ] User has Stripe Pro subscription
- [ ] Admin adds 50 bonus credits
- [ ] Both apply simultaneously
- [ ] User uses both Pro features + credits
- [ ] CreditHistory shows both sources
- [ ] Stripe payment fails, Pro revokes but override credits remain

### 9. Credit Deduction Still Works
- [ ] User has 10 credits
- [ ] Uses paid feature (5 credits cost)
- [ ] Sees credit decrease to 5
- [ ] CreditHistory logged
- [ ] Can use feature again (5 remaining)

### 10. Admin Lock Prevents Usage
- [ ] Free user (can normally use 2 resumes)
- [ ] Admin locks "resume_generation"
- [ ] User cannot use resume feature
- [ ] Shows lock badge
- [ ] Even with credits, still locked

## API Reference

### AdminOverride Entity
```json
{
  "user_email": "user@example.com",
  "admin_email": "admin@example.com",
  "override_type": "credit_add",
  "credits_amount": 100,
  "plan_granted": "pro",
  "features_affected": ["mock_interview", "auto_apply"],
  "temporary_until": "2026-05-25T23:59:59Z",
  "reason": "Customer support bonus",
  "previous_value": "50 credits",
  "new_value": "150 credits",
  "is_active": true
}
```

### useFeatureAccess Hook
```javascript
const { loading, getFeatureAccess, hasTemporaryAccess, getActiveOverrides, FEATURE_PRICING } = useFeatureAccess(userEmail, userProfile);

// Check if feature accessible
const { access, reason, creditCost } = getFeatureAccess('resume_generation');

// Get all active overrides
const overrides = getActiveOverrides(); // Returns array with details
```

### usePlanLimits Enhancement
```javascript
// Now checks overrides automatically
const { canUse, profile, plan, overrides } = usePlanLimits();

// Feature gates respect overrides
if (canUse('mock_interview')) { /* feature available */ }
```

## Security & Validation

### Admin-Only
- Only admins can access `/admin` page
- AdminOverride.create requires admin role
- Admins can only override other users (not themselves)

### Audit Trail
- Every override logged with:
  - Admin email
  - User email
  - Timestamp
  - What changed
  - Reason
- Cannot delete logs (only soft-delete via is_active)

### Override Rules
- Credits can't go negative
- Plan must be valid (free/pro/elite)
- Features must exist
- Days must be > 0
- Temporary access expiry calculated server-side

## Troubleshooting

### Feature Not Unlocking After Override
1. Check AdminOverride.is_active = true
2. Verify feature name matches FEATURE_PRICING keys
3. Check user email exact match
4. Try page refresh
5. Check browser console for errors

### Credits Not Updating
1. Confirm UserProfile updated alongside override
2. Check CreditHistory entry created
3. Verify real-time subscription active
4. Clear browser cache
5. Check admin email in override matches logged-in admin

### Temporary Access Not Expiring
1. Check temporary_until date/time correct
2. Verify override is_active still true
3. Check client timezone matches server
4. Override expires client-side (not auto-revoked server)
5. Feature gate checks expiration on access attempt

## Files Modified

- `entities/AdminOverride.json` — New entity
- `hooks/useFeatureAccess.js` — New hook for feature access
- `hooks/usePlanLimits.js` — Enhanced with override checks
- `components/admin/AdminOverridePanel.jsx` — New admin form
- `components/admin/AdminOverrideLogsPanel.jsx` — New logs display
- `components/dashboard/OverrideBadges.jsx` — New user dashboard badges
- `components/PlanGate.jsx` — Enhanced with override support
- `pages/AdminControls.jsx` — Integrated override system
- `pages/Dashboard.jsx` — Added OverrideBadges

## Future Enhancements

1. **Bulk Overrides** — Apply same override to multiple users
2. **Override Expiry** — Auto-revoke overrides after date
3. **Override Conditions** — Trigger overrides on specific events
4. **Webhook Notifications** — Notify users when override applied
5. **Override Analytics** — Track which overrides are used most
6. **Override Templates** — Save common override configurations
7. **Override Approval** — Require approval before applying