# Unlock System Deployment Checklist

## Pre-Deployment (Development)

### Database Verification
- [ ] `UserProfile` table has:
  - `ai_credits` (number, default 0)
  - `subscription_plan` (string, enum: free/pro/elite)
  - `usage_counts` (object, tracks monthly usage)
  - `created_by` (email of creator)

- [ ] `AdminOverride` table has:
  - `user_email` (string, lowercase)
  - `admin_email` (string, lowercase)
  - `override_type` (enum: credit_add, credit_remove, plan_upgrade, etc)
  - `is_active` (boolean)
  - `features_affected` (array of strings)

- [ ] `CreditHistory` table has:
  - `user_email` (string)
  - `action` (string: add, deduct, purchase, admin_adjustment)
  - `credits_spent` / `credits_added` (numbers)
  - `balance_after` (number)
  - `source` (string: admin_override, stripe_purchase, etc)

### Real-Time Listeners
- [ ] Test `UserProfile.subscribe()` fires on update
- [ ] Test `AdminOverride.subscribe()` fires on create/update
- [ ] Test email filtering is case-insensitive

### Functions Deployed
- [ ] `addCreditsAndSync.js` deployed ✓
- [ ] `upgradeSubscriptionAndSync.js` deployed ✓
- [ ] `syncUnlockState.js` deployed ✓
- [ ] `verifyFeatureAccess.js` deployed ✓

### Components Working
- [ ] `FeatureUnlockDisplay` renders all 10+ features ✓
- [ ] `FeatureButton` checks access before enabling ✓
- [ ] `FeatureGate` gates content correctly ✓
- [ ] Dashboard shows real-time updates ✓

### AdminOverridePanel Working
- [ ] Add credits updates UserProfile ✓
- [ ] Upgrade plan updates UserProfile ✓
- [ ] Feature unlock/lock works ✓
- [ ] Real-time sync fires on all changes ✓

### Test Flows (Run in Dev)
- [ ] Admin adds 50 credits → features unlock instantly ✓
- [ ] User sees 50 credits → no refresh ✓
- [ ] Admin upgrades to Pro → all Pro features unlock ✓
- [ ] User spends credits → balance updates instantly ✓
- [ ] Credits hit 0 → features lock again ✓
- [ ] Mobile + Desktop → both sync correctly ✓

### UnlockSystemTester Component
- [ ] Runs in development mode ✓
- [ ] Tests credit unlock flow ✓
- [ ] Tests subscription unlock flow ✓
- [ ] Tests feature access check ✓
- [ ] Shows all results with timestamps ✓

## Production Deployment

### Remove Development Features
- [ ] Remove `UnlockSystemTester` from Dashboard
  ```jsx
  // Remove this block:
  {process.env.NODE_ENV === 'development' && (
    <div className="mb-6">
      <h2 className="text-lg font-bold mb-3">🧪 Dev Tester</h2>
      <UnlockSystemTester />
    </div>
  )}
  ```

- [ ] Remove debug logs from components
- [ ] Remove console.error calls (or keep for logging)

### Security Review
- [ ] Backend checks user.role === 'admin' ✓
- [ ] Frontend gates are enforced by backend ✓
- [ ] Email filters are case-insensitive ✓
- [ ] User isolation via created_by/user_email ✓
- [ ] Override records logged for audit ✓

### Performance Check
- [ ] No N+1 queries (filter once per request) ✓
- [ ] Real-time listeners don't hammer DB ✓
- [ ] Access checks cached in component state ✓
- [ ] No unnecessary re-renders ✓

### Documentation
- [ ] `REAL_TIME_UNLOCK_SYSTEM.md` present ✓
- [ ] `UNLOCK_SYSTEM_INTEGRATION.md` present ✓
- [ ] `QUICK_UNLOCK_REFERENCE.md` present ✓
- [ ] Comments in AdminOverridePanel ✓
- [ ] Comments in sync functions ✓

### Monitoring Setup
- [ ] Log admin actions to CreditHistory ✓
- [ ] Monitor failed access attempts (optional)
- [ ] Alert on unusual credit patterns (optional)
- [ ] Track sync state via syncUnlockState() (optional)

### User Communication
- [ ] Updated help docs (if applicable)
- [ ] Updated pricing page to reflect features
- [ ] Updated onboarding to explain unlocks
- [ ] Tested with multiple user accounts

## Post-Deployment

### Day 1 Checks
- [ ] Monitor error logs for sync issues
- [ ] Check that credits update instantly
- [ ] Check that plans unlock features correctly
- [ ] Verify CreditHistory logs are accurate
- [ ] Test admin panel still works

### Week 1 Checks
- [ ] No orphaned credit records
- [ ] No duplicate unlocks
- [ ] All sync listeners firing correctly
- [ ] Mobile app syncs correctly (if applicable)
- [ ] Dashboard updates instantly for all users

### Rollback Plan
If issues occur:
1. Disable AdminOverridePanel temporarily
2. Check sync function logs
3. Verify UserProfile has correct fields
4. Clear browser cache and force refresh
5. Restart real-time listeners (refresh page)

## Rollback Steps

```
1. Disable AdminOverridePanel in AdminControls
2. Stop calling sync functions
3. Verify UserProfile data is correct
4. Manually update if needed
5. Clear session/cookies
6. Reload all pages
```

## Success Criteria

✅ Admin adds credits → User dashboard updates instantly
✅ Admin upgrades plan → All plan features unlock instantly
✅ User buys credits → Features unlock instantly
✅ Credits deducted on use → Balance updates instantly
✅ Multiple devices → Both sync correctly
✅ Page refresh → Access still correct
✅ Log out/in → State preserved
✅ CreditHistory logs all transactions
✅ No backend errors in logs
✅ No user complaints about stale state

## Monitoring Queries

### Check recent credit additions
```
SELECT * FROM CreditHistory 
WHERE action = 'add' 
ORDER BY created_date DESC 
LIMIT 10;
```

### Check admin overrides
```
SELECT * FROM AdminOverride 
WHERE is_active = true 
ORDER BY created_date DESC;
```

### Check sync state
Call `syncUnlockState()` for any user to verify current state:
```js
const response = await base44.functions.invoke('syncUnlockState', {});
// Returns { profile, overrides, unlocked, ... }
```

### Check feature access
```js
const access = await checkUserAccess('user@email.com', 'resume');
// Should return correct canUse status
```

## Troubleshooting

### Features not unlocking?
1. Check UserProfile has correct ai_credits/subscription_plan
2. Check subscribe listener is attached
3. Check checkUserAccess() returns true
4. Call syncUnlockState() to verify

### Credits not showing?
1. Check setProfile() called with new data
2. Check created_by matches email
3. Check Dashboard has real-time listener
4. Refresh page

### Overrides not working?
1. Check AdminOverride record exists
2. Check user_email is lowercase
3. Check is_active = true
4. Check features_affected array has feature

## Performance Metrics

Target:
- Feature unlock: < 1 second after action
- Dashboard update: < 500ms after change
- Credit balance update: < 500ms
- Real-time listener: instant (no polling)

## Done!

Once all checks pass:
1. Deploy to production
2. Monitor for 24 hours
3. Collect feedback
4. Ship to all users