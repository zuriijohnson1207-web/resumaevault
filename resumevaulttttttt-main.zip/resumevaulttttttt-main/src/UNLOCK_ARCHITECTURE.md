# Unlock System Architecture

## High-Level Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    UNLOCK SYSTEM FLOW                       │
└─────────────────────────────────────────────────────────────┘

ADMIN ACTION (e.g., Add Credits)
        │
        ↓
AdminOverridePanel (Frontend)
        │
        ↓
addCreditsAndSync() (Backend Function)
        │
        ├─→ Update UserProfile.ai_credits
        ├─→ Log to CreditHistory
        └─→ Return success
        │
        ↓
Database EVENT: UserProfile updated
        │
        ↓
Real-Time Listener Fires:
base44.entities.UserProfile.subscribe((event) => {
  if (event.data?.created_by === user.email) {
    setProfile(event.data);
  }
});
        │
        ↓
Dashboard Component Re-Renders
        │
        ├─→ FeatureUnlockDisplay updates
        ├─→ refreshAccessMap() called
        ├─→ checkUserAccess() checked for each feature
        └─→ UI shows unlocked features ✓
        │
        ↓
RESULT: Features unlock INSTANTLY, no refresh needed
```

## Component Dependency Tree

```
Dashboard
  ├─ FeatureUnlockDisplay
  │   ├─ UserProfile.subscribe() listener
  │   ├─ AdminOverride.subscribe() listener
  │   └─ checkUserAccess() for each feature
  │
  ├─ OverrideBadges
  │   └─ AdminOverride.subscribe() listener
  │
  ├─ CreditHistoryPanel
  │   └─ CreditHistory.subscribe() listener
  │
  └─ UnlockSystemTester (Dev only)
      └─ Test all sync flows

Any Feature Page (e.g., ResumeBuilder)
  └─ FeatureButton
      ├─ checkUserAccess() before click
      ├─ UpgradeModal (if locked)
      └─ Run feature on click

AdminControls
  └─ AdminOverridePanel
      ├─ addCreditsAndSync()
      ├─ upgradeSubscriptionAndSync()
      └─ Create AdminOverride records
```

## Data Flow: Admin Adds Credits

```
┌──────────────────────────────────────────┐
│ AdminOverridePanel (Frontend)            │
│ User: user@email.com                     │
│ Add: 50 credits                          │
└──────────────────────────────────────────┘
           │
           ↓ calls
┌──────────────────────────────────────────┐
│ addCreditsAndSync() (Backend)            │
│                                          │
│ 1. Fetch UserProfile by created_by      │
│ 2. oldCredits = 0                        │
│ 3. newCredits = 0 + 50 = 50              │
│ 4. UPDATE UserProfile SET ai_credits=50 │
│ 5. CREATE CreditHistory entry            │
└──────────────────────────────────────────┘
           │
           ↓ triggers
┌──────────────────────────────────────────┐
│ Database Event                           │
│ UserProfile updated                      │
│ id: xxx, created_by: user@email.com      │
│ ai_credits: 50                           │
└──────────────────────────────────────────┘
           │
           ↓ fires
┌──────────────────────────────────────────┐
│ UserProfile.subscribe()                  │
│                                          │
│ Event: {                                 │
│   type: 'update',                        │
│   data: { ai_credits: 50, ... }          │
│ }                                        │
└──────────────────────────────────────────┘
           │
           ↓ calls
┌──────────────────────────────────────────┐
│ Dashboard.setProfile(newData)            │
│ newData.ai_credits = 50                  │
└──────────────────────────────────────────┘
           │
           ↓ re-renders & calls
┌──────────────────────────────────────────┐
│ FeatureUnlockDisplay.refreshAccessMap()  │
│                                          │
│ For each feature:                        │
│   checkUserAccess(user.email, feature)   │
│                                          │
│ For 'resume' (costs 5 credits):          │
│   profile.ai_credits = 50                │
│   50 >= 5 ✓                              │
│   → canUse: true, reason: 'credit'       │
└──────────────────────────────────────────┘
           │
           ↓ returns
┌──────────────────────────────────────────┐
│ UI Updates:                              │
│ ✓ Credit balance: 50                     │
│ ✓ Resume feature: UNLOCKED               │
│ ✓ Job Analyzer: UNLOCKED                 │
│ ✓ Feature buttons: ENABLED               │
│ ✓ NO REFRESH NEEDED                      │
└──────────────────────────────────────────┘
```

## Real-Time Sync Mechanism

```
┌─────────────────────────────────────────┐
│ Real-Time Event Flow                    │
└─────────────────────────────────────────┘

Backend: UPDATE UserProfile
    ↓
Database: Event emitted
    ↓
Websocket: Message sent to connected clients
    ↓
Frontend: Listener receives event
    ↓
React State: Updated
    ↓
Components: Re-render
    ↓
UI: Reflects new state

SPEED: < 1 second, usually < 100ms
TRIGGER: Database change only
SCOPE: Only matching user's profile
OPTIMIZATION: Listener filters by created_by
```

## Access Decision Tree

```
checkUserAccess(userEmail, 'resume')
    │
    ├─ Is user admin? → canUse: true ✓
    │
    ├─ Check admin override?
    │   ├─ Feature unlocked? → canUse: true ✓
    │   └─ Feature locked? → canUse: false ✗
    │
    ├─ Check subscription plan
    │   ├─ Plan = 'pro', 'elite'?
    │   │   ├─ Feature included? → canUse: true ✓
    │   │   └─ Monthly limit available? → canUse: true ✓
    │   │
    │   └─ Plan = 'free'?
    │       ├─ Feature in free plan? → canUse: true ✓
    │       └─ No? Continue...
    │
    ├─ Check credits
    │   ├─ credits >= creditCost?
    │   │   └─ canUse: true (credit_purchase) ✓
    │   │
    │   └─ credits < creditCost?
    │       └─ Continue...
    │
    └─ Locked: canUse: false ✗
```

## State Consistency Model

```
┌─────────────────────────────────┐
│ Single Source of Truth:         │
│ checkUserAccess()               │
│                                 │
│ Checks in this order:           │
│ 1. AdminOverride (exact)        │
│ 2. UserProfile.subscription     │
│ 3. UserProfile.usage_counts     │
│ 4. UserProfile.ai_credits       │
│ 5. Default: locked              │
└─────────────────────────────────┘

All components use SAME function:
- AdminOverridePanel ✓
- FeatureUnlockDisplay ✓
- FeatureButton ✓
- Dashboard ✓
- Backend verification ✓

Result: CONSISTENT STATE everywhere
```

## Database Tables

```
UserProfile
├─ id
├─ created_by (email)
├─ email
├─ subscription_plan (free/pro/elite)
├─ ai_credits (number)
├─ usage_counts (object: { resume: 2, job_analysis: 1, ... })
└─ monthly_uses (number)

AdminOverride
├─ id
├─ created_by (email)
├─ created_date
├─ user_email (email, lowercase)
├─ admin_email (email, lowercase)
├─ override_type (credit_add/plan_upgrade/feature_unlock/...)
├─ credits_amount (number)
├─ plan_granted (free/pro/elite)
├─ features_affected (array: [resume, job_analysis, ...])
├─ temporary_until (ISO date)
├─ is_active (boolean)
└─ reason (text)

CreditHistory
├─ id
├─ created_by (email)
├─ created_date
├─ user_email (email)
├─ action (add/deduct/purchase/admin_adjustment/subscription)
├─ feature (string)
├─ credits_spent (number)
├─ credits_added (number)
├─ balance_after (number)
├─ source (admin_override/stripe_purchase/feature_usage/...)
└─ notes (text)
```

## Key Invariants

1. **Single Source of Truth**: checkUserAccess() always right
2. **User Isolation**: created_by / user_email filters always applied
3. **Real-Time Sync**: UI updates within 1s of DB change
4. **Lowercase Emails**: All email filters use .toLowerCase()
5. **Audit Trail**: Every change logged to CreditHistory
6. **Instant Updates**: No polling, no delays
7. **Atomic Updates**: Transaction-like (update → log → return)
8. **Admin Enforcement**: Backend validates admin role

## Performance Targets

```
Action → UI Update: < 1 second
API Call: < 100ms
Database Update: < 50ms
Real-Time Listener Fire: < 500ms
Component Re-Render: < 200ms
Total: < 500ms (typical)
```

## Security Model

```
Frontend (UI convenience):
  - Show/hide buttons
  - Format messages
  - Display unlock status
  ├─ User can bypass via DevTools
  └─ UNSAFE for actual access control

Backend (Enforced):
  - checkUserAccess() gate
  - Role verification
  - Feature usage logging
  ├─ User CANNOT bypass
  └─ SAFE for access control
```

## Summary

```
┌─────────────────────────────────────────┐
│ Credit/Plan/Override System             │
├─────────────────────────────────────────┤
│ Single Truth: checkUserAccess()         │
│ Real-Time: UserProfile.subscribe()      │
│ Instant Unlock: < 1 second              │
│ Atomic Updates: Logged + Verified       │
│ Isolated Scopes: created_by filter      │
│ Audit Trail: CreditHistory              │
│ Enforced: Backend gates features        │
│ Scalable: No polling/delays             │
└─────────────────────────────────────────┘
``