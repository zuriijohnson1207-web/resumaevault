/**
 * Resume Templates
 * Each template defines:
 * - theme: colors, fonts
 * - layout: structural layout type
 *   'single'        — full-width single column, banner header
 *   'left-sidebar'  — sidebar left with skills/edu, main right
 *   'right-sidebar' — main left, sidebar right
 *   'centered'      — centered header, full-width sections
 *   'minimal-line'  — clean lines, minimal header, no header bg
 *   'bold-accent'   — left-border accent on section headers
 */

export const RESUME_TEMPLATES = [
  {
    id: 'ats-friendly',
    name: 'ATS-Friendly',
    description: 'Plain single-column. Maximum ATS compatibility. Zero design frills.',
    category: 'ATS-Friendly',
    preview_color: 'from-gray-400 to-gray-600',
    icon: '🤖',
    layout: 'minimal-line',
    theme: {
      bg: '#ffffff',
      text: '#111827',
      accent: '#374151',
      headerBg: '#ffffff',
      headerText: '#111827',
      sectionColor: '#374151',
      font: 'Arial, sans-serif',
      borderColor: '#d1d5db',
    }
  },
  {
    id: 'modern-clean',
    name: 'Modern',
    description: 'Two-column with bold accent sidebar. Clean and contemporary.',
    category: 'Modern',
    preview_color: 'from-blue-500 to-blue-700',
    icon: '✨',
    layout: 'left-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#1a1a2e',
      accent: '#2563eb',
      headerBg: '#2563eb',
      headerText: '#ffffff',
      sidebarBg: '#eff6ff',
      sidebarText: '#1e3a8a',
      sectionColor: '#2563eb',
      font: 'Arial, sans-serif',
      borderColor: '#dbeafe',
    }
  },
  {
    id: 'minimalist',
    name: 'Minimalist',
    description: 'Ultra-clean, minimal white space. Restrained elegance.',
    category: 'Minimalist',
    preview_color: 'from-stone-300 to-stone-500',
    icon: '⬜',
    layout: 'minimal-line',
    theme: {
      bg: '#fafaf9',
      text: '#1c1917',
      accent: '#a8a29e',
      headerBg: '#fafaf9',
      headerText: '#1c1917',
      sectionColor: '#78716c',
      font: '"Helvetica Neue", Helvetica, sans-serif',
      borderColor: '#e7e5e4',
    }
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'Polished and structured. Ideal for most industries.',
    category: 'Professional',
    preview_color: 'from-slate-500 to-slate-700',
    icon: '💼',
    layout: 'single',
    theme: {
      bg: '#ffffff',
      text: '#1e293b',
      accent: '#0f172a',
      headerBg: '#0f172a',
      headerText: '#f8fafc',
      sectionColor: '#334155',
      font: '"Times New Roman", Georgia, serif',
      borderColor: '#cbd5e1',
    }
  },
  {
    id: 'chronological',
    name: 'Chronological',
    description: 'Classic timeline structure. Experience listed top-to-bottom by date.',
    category: 'Chronological',
    preview_color: 'from-zinc-500 to-zinc-700',
    icon: '📅',
    layout: 'bold-accent',
    theme: {
      bg: '#ffffff',
      text: '#18181b',
      accent: '#3f3f46',
      headerBg: '#18181b',
      headerText: '#fafafa',
      sectionColor: '#52525b',
      font: 'Georgia, serif',
      borderColor: '#d4d4d8',
    }
  },
  {
    id: 'creative-minimal',
    name: 'Creative',
    description: 'Sidebar layout with accent color. For designers and creatives.',
    category: 'Creative',
    preview_color: 'from-pink-400 to-rose-500',
    icon: '🎨',
    layout: 'left-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#881337',
      accent: '#e11d48',
      headerBg: '#e11d48',
      headerText: '#ffffff',
      sidebarBg: '#fff1f2',
      sidebarText: '#9f1239',
      sectionColor: '#e11d48',
      font: 'Arial, sans-serif',
      borderColor: '#fda4af',
    }
  },
  {
    id: 'executive',
    name: 'Executive',
    description: 'Centered header, refined serif font. For senior leadership.',
    category: 'Executive',
    preview_color: 'from-purple-600 to-purple-800',
    icon: '👑',
    layout: 'centered',
    theme: {
      bg: '#ffffff',
      text: '#3b0764',
      accent: '#7c3aed',
      headerBg: '#4c1d95',
      headerText: '#faf5ff',
      sectionColor: '#7c3aed',
      font: 'Georgia, serif',
      borderColor: '#ddd6fe',
    }
  },
  {
    id: 'functional',
    name: 'Functional',
    description: 'Skills-first sidebar layout. Ideal for career changers.',
    category: 'Functional',
    preview_color: 'from-teal-400 to-teal-600',
    icon: '🔧',
    layout: 'right-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#134e4a',
      accent: '#0d9488',
      headerBg: '#0d9488',
      headerText: '#ffffff',
      sidebarBg: '#f0fdfa',
      sidebarText: '#134e4a',
      sectionColor: '#0d9488',
      font: 'Arial, sans-serif',
      borderColor: '#99f6e4',
    }
  },
  {
    id: 'tech',
    name: 'Technical',
    description: 'Dark header, monospace accents, sidebar for tech stack.',
    category: 'Technical',
    preview_color: 'from-cyan-500 to-blue-600',
    icon: '💻',
    layout: 'left-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#0f172a',
      accent: '#0284c7',
      headerBg: '#0f172a',
      headerText: '#7dd3fc',
      sidebarBg: '#f0f9ff',
      sidebarText: '#0c4a6e',
      sectionColor: '#0284c7',
      font: '"Courier New", Courier, monospace',
      borderColor: '#bae6fd',
    }
  },
  {
    id: 'academic',
    name: 'Academic',
    description: 'Centered, serif-heavy. Education and publications front-and-center.',
    category: 'Academic',
    preview_color: 'from-indigo-600 to-blue-700',
    icon: '🎓',
    layout: 'centered',
    theme: {
      bg: '#ffffff',
      text: '#1e1b4b',
      accent: '#4338ca',
      headerBg: '#1e1b4b',
      headerText: '#e0e7ff',
      sectionColor: '#4338ca',
      font: '"Times New Roman", Georgia, serif',
      borderColor: '#c7d2fe',
    }
  },
  {
    id: 'entry-level',
    name: 'Entry-Level',
    description: 'Skills-forward sidebar. For new grads and first jobs.',
    category: 'Entry-Level',
    preview_color: 'from-green-400 to-green-600',
    icon: '🌱',
    layout: 'left-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#14532d',
      accent: '#16a34a',
      headerBg: '#16a34a',
      headerText: '#ffffff',
      sidebarBg: '#f0fdf4',
      sidebarText: '#14532d',
      sectionColor: '#15803d',
      font: 'Arial, sans-serif',
      borderColor: '#bbf7d0',
    }
  },
  {
    id: 'customer-service',
    name: 'Customer Service',
    description: 'Warm colors, friendly structure for client-facing roles.',
    category: 'Customer Service',
    preview_color: 'from-orange-400 to-orange-600',
    icon: '🤝',
    layout: 'bold-accent',
    theme: {
      bg: '#ffffff',
      text: '#431407',
      accent: '#ea580c',
      headerBg: '#ea580c',
      headerText: '#ffffff',
      sectionColor: '#c2410c',
      font: 'Arial, sans-serif',
      borderColor: '#fed7aa',
    }
  },
  {
    id: 'healthcare',
    name: 'Healthcare',
    description: 'Clean clinical layout with sidebar for credentials.',
    category: 'Healthcare',
    preview_color: 'from-teal-500 to-teal-700',
    icon: '🏥',
    layout: 'right-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#134e4a',
      accent: '#0d9488',
      headerBg: '#0d9488',
      headerText: '#ffffff',
      sidebarBg: '#f0fdfa',
      sidebarText: '#134e4a',
      sectionColor: '#0d9488',
      font: 'Arial, sans-serif',
      borderColor: '#99f6e4',
    }
  },
  {
    id: 'administrative',
    name: 'Administrative',
    description: 'Neat and structured. Office and admin roles.',
    category: 'Administrative',
    preview_color: 'from-blue-400 to-blue-600',
    icon: '🗂️',
    layout: 'single',
    theme: {
      bg: '#ffffff',
      text: '#1e3a8a',
      accent: '#1d4ed8',
      headerBg: '#1e3a8a',
      headerText: '#dbeafe',
      sectionColor: '#1d4ed8',
      font: '"Times New Roman", Georgia, serif',
      borderColor: '#bfdbfe',
    }
  },
  {
    id: 'remote-work',
    name: 'Remote Work',
    description: 'Modern sidebar highlighting remote skills and flexibility.',
    category: 'Remote Work',
    preview_color: 'from-indigo-400 to-violet-600',
    icon: '🌐',
    layout: 'left-sidebar',
    theme: {
      bg: '#ffffff',
      text: '#3730a3',
      accent: '#6366f1',
      headerBg: '#6366f1',
      headerText: '#ffffff',
      sidebarBg: '#eef2ff',
      sidebarText: '#3730a3',
      sectionColor: '#6366f1',
      font: 'Arial, sans-serif',
      borderColor: '#c7d2fe',
    }
  },
  {
    id: 'sales',
    name: 'Sales & Marketing',
    description: 'Results-focused, bold left accent for metrics and wins.',
    category: 'Sales & Marketing',
    preview_color: 'from-green-600 to-emerald-800',
    icon: '📈',
    layout: 'bold-accent',
    theme: {
      bg: '#ffffff',
      text: '#052e16',
      accent: '#16a34a',
      headerBg: '#14532d',
      headerText: '#dcfce7',
      sectionColor: '#16a34a',
      font: 'Arial, sans-serif',
      borderColor: '#86efac',
    }
  },
  {
    id: 'warehouse-ops',
    name: 'Warehouse / Operations',
    description: 'Bold, direct, single-column. Logistics and operations.',
    category: 'Warehouse/Operations',
    preview_color: 'from-yellow-500 to-amber-600',
    icon: '📦',
    layout: 'single',
    theme: {
      bg: '#ffffff',
      text: '#451a03',
      accent: '#d97706',
      headerBg: '#292524',
      headerText: '#fef3c7',
      sectionColor: '#d97706',
      font: 'Arial, sans-serif',
      borderColor: '#fde68a',
    }
  },
  {
    id: 'corporate',
    name: 'Corporate',
    description: 'Traditional business layout with serif font.',
    category: 'Corporate',
    preview_color: 'from-slate-600 to-slate-800',
    icon: '🏢',
    layout: 'single',
    theme: {
      bg: '#ffffff',
      text: '#1e293b',
      accent: '#334155',
      headerBg: '#1e293b',
      headerText: '#f1f5f9',
      sectionColor: '#334155',
      font: 'Georgia, serif',
      borderColor: '#cbd5e1',
    }
  },
  {
    id: 'simple-classic',
    name: 'Simple Classic',
    description: 'No frills. Clean and universal. Works everywhere.',
    category: 'Simple Classic',
    preview_color: 'from-gray-500 to-gray-700',
    icon: '📄',
    layout: 'minimal-line',
    theme: {
      bg: '#ffffff',
      text: '#111827',
      accent: '#6b7280',
      headerBg: '#ffffff',
      headerText: '#111827',
      sectionColor: '#374151',
      font: 'Arial, sans-serif',
      borderColor: '#e5e7eb',
    }
  },
  {
    id: 'one-page-compact',
    name: 'One-Page Compact',
    description: 'Dense but readable. Fits everything on one page.',
    category: 'One-Page Compact',
    preview_color: 'from-gray-700 to-gray-900',
    icon: '📋',
    layout: 'bold-accent',
    theme: {
      bg: '#ffffff',
      text: '#111827',
      accent: '#4b5563',
      headerBg: '#111827',
      headerText: '#f9fafb',
      sectionColor: '#374151',
      font: '"Helvetica Neue", Arial, sans-serif',
      borderColor: '#d1d5db',
    }
  },
];

export function getTemplateById(id) {
  return RESUME_TEMPLATES.find(t => t.id === id) || RESUME_TEMPLATES[0];
}

export function buildResumePrompt(formData, template) {
  const {
    fullName, email, phone, location, linkedin,
    summary, skills, experience, education, certifications,
    projects, careerGoal, jobDescription, jobTitle, company,
    hsGradYear, resumeLength, quickMode,
  } = formData;

  return `You are an expert resume writer and ATS optimization specialist. Create a professional, honest resume using the "${template?.name || 'ATS-Friendly'}" style.

CRITICAL HONESTY RULES — READ EVERY ONE:
- NEVER invent fake company names, school names, job titles, degrees, dates, certifications, or achievements
- NEVER add false claims or fabricated metrics
- ONLY use information the user has explicitly provided
- When any detail is missing, use a clearly marked placeholder in brackets:
  [Company Name], [School Name], [Start Date], [End Date], [Certification Name], [City, State]
- After any section with placeholders, add this exact note on its own line:
  >> This section needs your real details before applying.
- Use transferable skills and professional wording based only on the user's real experience
- Strong action verbs and ATS keywords are fine — but only tied to real roles or skills the user mentioned
- ${resumeLength === '1page' ? 'Keep to ONE PAGE maximum — be concise' : 'Full resume — be thorough'}
${quickMode ? '- QUICK MODE: The user provided minimal info. Build the strongest possible honest resume from what is given. Use placeholders generously and clearly.' : ''}

FORMATTING RULES:
- NO hashtags, NO pound signs (#), NO asterisks as decoration
- NO emojis, NO special characters
- Plain dashes (-) for bullet points
- Section headers in ALL CAPS
- One blank line between sections
- Dates: Month Year - Month Year (e.g., January 2020 - March 2023)

CANDIDATE INFO:
Name: ${fullName || '[Your Full Name]'}
Email: ${email || '[Your Email]'}
Phone: ${phone || '[Your Phone Number]'}
Location: ${location || '[City, State]'}
LinkedIn: ${linkedin || ''}
Career Goal: ${careerGoal || 'Not specified'}
High School Graduation: ${hsGradYear || 'Not provided'}

TARGET ROLE:
Job Title: ${jobTitle || 'Not specified'}
Company: ${company || 'Not specified'}
Job Description:
${jobDescription || 'Not provided'}

PROFESSIONAL SUMMARY (from user):
${summary || 'Write a compelling 3-sentence summary based ONLY on the background and role provided. Do not invent details.'}

SKILLS:
${skills || 'Infer only from job description keywords and any experience mentioned. Do not fabricate skills.'}

WORK EXPERIENCE:
${experience || 'Not provided — if empty, include a placeholder experience block with [Company Name], [Job Title], [Dates] and note that real details are needed.'}

EDUCATION:
${education || 'Not provided'}

HIGH SCHOOL: ${hsGradYear ? `Graduated ${hsGradYear}` : 'Not provided'}

CERTIFICATIONS:
${certifications || 'None listed'}

PROJECTS:
${projects || 'None listed'}

---
Output the complete resume in this exact clean format:

[CANDIDATE FULL NAME]
[City, State] | [Phone] | [Email] | [LinkedIn if provided]

PROFESSIONAL SUMMARY
[3 compelling, honest sentences tailored to the target role using only real info. Insert ATS keywords naturally.]

SKILLS
[Comma-separated list of relevant skills. Include ATS keywords from the job description that match the user's real background.]

PROFESSIONAL EXPERIENCE

[Job Title] | [Company Name] | [City, State] | [Month Year - Month Year or Present]
- [Strong action verb + real responsibility or achievement]
- [Strong action verb + transferable skill or real task]
- [Strong action verb + result or contribution]
>> This section needs your real details before applying. (only add this line if placeholders were used)

[Repeat for each position]

EDUCATION

[Degree] in [Field of Study]
[School Name] | [Graduation Year]
>> This section needs your real details before applying. (only if placeholders used)

CERTIFICATIONS
[List certifications if provided, or omit section]

PROJECTS
[Project Name]: [Brief description if provided, or omit section]

---

AFTER THE RESUME, add this section on a new line:

---
MISSING INFO CHECKLIST
List every placeholder used as a checklist item, for example:
- [ ] Add your real company name to replace [Company Name]
- [ ] Add your employment dates to replace [Start Date] / [End Date]
- [ ] Add your school name to replace [School Name]
- [ ] Add any certifications if applicable
(Only include items that actually have missing info — skip this section if everything was provided)

---
SUGGESTIONS TO STRENGTHEN YOUR RESUME
List 3-5 specific, actionable suggestions to improve this resume further.
---

Every bullet should show real value. Remove filler words. Professional, clean, and ready to submit — with honest placeholders where needed.`;
}

export function buildSampleResumePrompt(jobTitle, company, jobDescription, template, personalInfo = {}) {
  const { fullName, email, phone, location, linkedin } = personalInfo;
  const hasPersonalInfo = fullName || email || phone || location || linkedin;

  const contactLine = [
    location || '[Realistic City, State]',
    phone || '[Realistic phone format]',
    email || '[Realistic professional email]',
    linkedin || '[LinkedIn URL]',
  ].join(' | ');

  return `You are an expert resume writer and ATS optimization specialist. Create a COMPLETE, realistic-looking example resume for a "${jobTitle}" role${company ? ` at ${company}` : ''} using the "${template?.name || 'ATS-Friendly'}" style.

PURPOSE: This is an AI-generated SAMPLE resume for inspiration only. The experience, roles, and achievements are fictional examples. The user may have provided their real contact info below.

GENERATION RULES:
- Generate realistic, professional-sounding company names, job titles, dates, and achievements
- Match experience closely to the target job description and role requirements
- Create 2-3 plausible previous positions with logical career progression toward "${jobTitle}"
- Include realistic education that fits the role (e.g., relevant degree)
- Generate specific, believable metrics and achievements (e.g., "increased revenue by 23%", "managed team of 8")
- Keep tone professional, confident, and ATS-optimized
- Avoid exaggerated or unrealistic claims — keep it believable and grounded
- Align all skills with the job description keywords
${hasPersonalInfo ? `- Use the provided personal info exactly as given for the contact header` : ''}

FORMATTING RULES:
- NO hashtags, NO pound signs (#), NO asterisks as decoration
- NO emojis, NO special characters
- Plain dashes (-) for bullet points
- Section headers in ALL CAPS
- One blank line between sections
- Dates: Month Year - Month Year (e.g., January 2020 - March 2023)

TARGET ROLE:
Job Title: ${jobTitle}
Company: ${company || 'Not specified'}
Job Description:
${jobDescription || 'Not provided — generate experience typical for this role'}

---
Output the complete sample resume in this exact clean format:

${fullName || '[REALISTIC FULL NAME — e.g. "Alex Morgan" or "Jamie Rivera"]'}
${contactLine}

PROFESSIONAL SUMMARY
[3 compelling, ATS-optimized sentences perfectly tailored to ${jobTitle}. Make it sound polished and experienced.]

SKILLS
[Comma-separated list of 10-14 highly relevant skills and ATS keywords matching the job description]

PROFESSIONAL EXPERIENCE

[Most Recent Job Title] | [Realistic Company Name] | [City, State] | [Month Year - Present]
- [Strong action verb + specific achievement with realistic metric]
- [Strong action verb + responsibility relevant to ${jobTitle}]
- [Strong action verb + team/project contribution]
- [Strong action verb + result or improvement]

[Previous Job Title] | [Different Realistic Company] | [City, State] | [Month Year - Month Year]
- [Strong action verb + achievement]
- [Strong action verb + responsibility]
- [Strong action verb + result]

[Earlier Job Title] | [Another Realistic Company] | [City, State] | [Month Year - Month Year]
- [Strong action verb + achievement]
- [Strong action verb + responsibility]

EDUCATION

[Relevant Degree] in [Relevant Field of Study]
[Realistic University Name] | [Graduation Year]

CERTIFICATIONS
[1-2 realistic, relevant certifications for this role — or omit section if not typical]

---`;
}

export function buildQuickResumePrompt(name, contact, jobTitle, workHistory, skills, education, jobDescription, resumeLength) {
  return buildResumePrompt({
    fullName: name,
    email: contact,
    phone: '',
    location: '',
    linkedin: '',
    summary: '',
    skills,
    experience: workHistory,
    education,
    hsGradYear: '',
    certifications: '',
    projects: '',
    careerGoal: '',
    jobDescription,
    jobTitle,
    company: '',
    resumeLength: resumeLength || 'full',
    quickMode: true,
  }, { name: 'ATS-Friendly' });
}