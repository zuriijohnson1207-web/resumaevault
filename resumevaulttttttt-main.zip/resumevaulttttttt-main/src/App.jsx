import { Toaster } from 'sonner';
import { QueryClientProvider } from '@tanstack/react-query';
import { lazy, Suspense } from 'react';

import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Layout from '@/components/Layout';

// Landing & Auth (critical path)
import Landing from '@/pages/Landing';
import Auth from '@/pages/Auth';
import Dashboard from '@/pages/Dashboard';

// Lazy load all other pages
const JobAnalyzer = lazy(() => import('@/pages/JobAnalyzer'));
const ResumeBuilder = lazy(() => import('@/pages/ResumeBuilder'));
const ResumeLibrary = lazy(() => import('@/pages/ResumeLibrary'));
const CoverLetter = lazy(() => import('@/pages/CoverLetter'));
const FollowUpEmail = lazy(() => import('@/pages/FollowUpEmail'));
const Profile = lazy(() => import('@/pages/Profile'));
const ApplicationTracker = lazy(() => import('@/pages/ApplicationTracker'));
const Analytics = lazy(() => import('@/pages/Analytics'));
const Pricing = lazy(() => import('@/pages/Pricing'));
const Reviews = lazy(() => import('@/pages/Reviews'));
const LiveJobs = lazy(() => import('@/pages/AutoApply'));
const MockInterview = lazy(() => import('@/pages/MockInterview'));
const SalaryNegotiation = lazy(() => import('@/pages/SalaryNegotiation'));
const CareerRoadmap = lazy(() => import('@/pages/CareerRoadmap'));
const PortfolioIdeas = lazy(() => import('@/pages/PortfolioIdeas'));
const AdminControls = lazy(() => import('@/pages/AdminControls'));
const AdminAssistant = lazy(() => import('@/pages/AdminAssistant'));
const CareerBuddy = lazy(() => import('@/pages/CareerBuddy'));

// Fallback loader
const PageLoader = () => (
  <div className="fixed inset-0 flex items-center justify-center bg-background">
    <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
  </div>
);

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
    // Redirect to auth page where they can log in / sign up
    window.location.href = '/auth';
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/auto-apply" element={<Suspense fallback={<PageLoader />}><LiveJobs /></Suspense>} />
        <Route path="/job-analyzer" element={<Suspense fallback={<PageLoader />}><JobAnalyzer /></Suspense>} />
        <Route path="/resume-builder" element={<Suspense fallback={<PageLoader />}><ResumeBuilder /></Suspense>} />
        <Route path="/resume-library" element={<Suspense fallback={<PageLoader />}><ResumeLibrary /></Suspense>} />
        <Route path="/cover-letter" element={<Suspense fallback={<PageLoader />}><CoverLetter /></Suspense>} />
        <Route path="/follow-up-email" element={<Suspense fallback={<PageLoader />}><FollowUpEmail /></Suspense>} />
        <Route path="/profile" element={<Suspense fallback={<PageLoader />}><Profile /></Suspense>} />
        <Route path="/application-tracker" element={<Suspense fallback={<PageLoader />}><ApplicationTracker /></Suspense>} />
        <Route path="/analytics" element={<Suspense fallback={<PageLoader />}><Analytics /></Suspense>} />
        <Route path="/pricing" element={<Suspense fallback={<PageLoader />}><Pricing /></Suspense>} />
        <Route path="/reviews" element={<Suspense fallback={<PageLoader />}><Reviews /></Suspense>} />
        <Route path="/mock-interview" element={<Suspense fallback={<PageLoader />}><MockInterview /></Suspense>} />
        <Route path="/salary-negotiation" element={<Suspense fallback={<PageLoader />}><SalaryNegotiation /></Suspense>} />
        <Route path="/career-roadmap" element={<Suspense fallback={<PageLoader />}><CareerRoadmap /></Suspense>} />
        <Route path="/portfolio-ideas" element={<Suspense fallback={<PageLoader />}><PortfolioIdeas /></Suspense>} />
        <Route path="/admin" element={<Suspense fallback={<PageLoader />}><AdminControls /></Suspense>} />
        <Route path="/admin-assistant" element={<Suspense fallback={<PageLoader />}><AdminAssistant /></Suspense>} />
        <Route path="/career-buddy" element={<Suspense fallback={<PageLoader />}><CareerBuddy /></Suspense>} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <QueryClientProvider client={queryClientInstance}>
      <Router>
        <Routes>
          <Route path="/landing" element={<Landing />} />
          <Route path="/auth" element={<Auth />} />
          <Route
            path="*"
            element={
              <AuthProvider>
                <AuthenticatedApp />
              </AuthProvider>
            }
          />
        </Routes>
      </Router>
      <Toaster
        position="top-right"
        richColors
        closeButton
        duration={5000}
        toastOptions={{
          style: { fontSize: '15px', fontWeight: '500', minHeight: '52px' },
          closeButton: true,
        }}
      />
    </QueryClientProvider>
  )
}

export default App