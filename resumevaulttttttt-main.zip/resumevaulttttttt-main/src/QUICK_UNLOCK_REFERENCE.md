# Quick Unlock Reference

## The System (60 seconds)

```
checkUserAccess() ← Single source of truth for feature access
  ↓
Check: Admin override? → Plan unlimited? → Monthly limit? → Credits? → Locked
  ↓
Return: { canUse: bool, reason: string, creditsNeeded: number }
```

## When Anything Changes (Credits/Plan/Override)

```
Backend updates UserProfile
  ↓
Fires real-time listener
  ↓
Frontend calls refreshAccessMap()
  ↓
UI updates instantly ✅
```

## How to Use

### Check If User Can Use Feature
```js
const access = await checkUserAccess(userEmail, 'resume');
if (access.canUse) {
  // Run feature
  recordFeatureUsage(userEmail, 'resume'); // Deduct credits
} else {
  // Show upgrade modal
}
```

### Wrap Feature Button
```jsx
<FeatureButton feature="resume" onClick={generateResume}>
  Generate Resume
</FeatureButton>
```

### Show All Unlocked Features
```jsx
<FeatureUnlockDisplay />
```

## Backend Sync Functions

### Add Credits
```js
await base44.functions.invoke('addCreditsAndSync', {
  userEmail: 'user@email.com',
  creditsToAdd: 50,
  reason: 'admin_override',
  adminEmail: admin.email,
});
```

### Upgrade Plan
```js
await base44.functions.invoke('upgradeSubscriptionAndSync', {
  userEmail: 'user@email.com',
  newPlan: 'pro',
  reason: 'subscription_upgrade',
  adminEmail: admin.email,
});
```

## Access Reasons (Priority)

1. **admin_override** - Admin unlocked it
2. **plan_unlimited** - Plan includes unlimited
3. **plan_monthly_limit** - Monthly quota available
4. **credit_purchase** - Has credits to spend
5. **temporary_access** - Temporary unlock
6. **admin_lock** - Admin locked it
7. **locked** - Can't use

## Real-Time Sync Listeners

```js
// Profile changes (credits, plan)
base44.entities.UserProfile.subscribe((event) => {
  if (event.data?.created_by === user.email) {
    setProfile(event.data); // Triggers UI update
  }
});

// Override changes
base44.entities.AdminOverride.subscribe((event) => {
  if (event.data?.user_email === user.email) {
    refreshAccessMap(); // Re-check all features
  }
});
```

## Feature Definitions
```js
{
  resume: { label: 'AI Resume', creditCost: 5, free: 2, pro: 80, elite: 150 },
  cover_letter: { label: 'Cover Letter', creditCost: 3, free: 2, pro: Infinity, elite: Infinity },
  job_analysis: { label: 'Job Analysis', creditCost: 2, free: 2, pro: Infinity, elite: Infinity },
  ats_score: { label: 'ATS Score', creditCost: 1, free: 0, pro: Infinity, elite: Infinity },
  advanced_ats_report: { label: 'Advanced ATS Report', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  auto_apply: { label: 'Auto Apply', creditCost: 2, free: 0, pro: 50, elite: 200 },
  // ... more features
}
```

## Tests to Run

```
1. Admin adds credits → features unlock instantly
2. Admin upgrades plan → all plan features unlock
3. User spends credits → balance updates instantly
4. Refresh page → access still correct
5. Mobile + desktop → both sync
6. Remove override → features lock again
```

## Debug: Feature Not Unlocking?

```
1. Check UserProfile.ai_credits in DB ✓
2. Check UserProfile.subscribe() listener ✓
3. Check checkUserAccess() returns true ✓
4. Check FeatureUnlockDisplay rendered ✓
5. Check browser console for errors ✓
```

## Files You Need to Know

- `lib/checkUserAccess.js` - Access check logic
- `functions/addCreditsAndSync.js` - Add credits
- `functions/upgradeSubscriptionAndSync.js` - Upgrade plan
- `components/FeatureUnlockDisplay.jsx` - Show all unlocks
- `components/FeatureButton.jsx` - Wrap buttons
- `pages/Dashboard` - Uses all of above

## One-Liner Checklist

- [ ] Admin adds credits via AdminOverridePanel ✓
- [ ] Backend calls addCreditsAndSync() ✓
- [ ] UserProfile.ai_credits updated ✓
- [ ] Real-time listener fires ✓
- [ ] Dashboard re-renders ✓
- [ ] FeatureUnlockDisplay updates ✓
- [ ] Feature buttons enable ✓
- [ ] No page refresh ✓

## Common Mistakes

❌ Not using created_by filter
❌ Not lowercasing email for filter
❌ Not calling backend sync functions
❌ Assuming frontend updates are enough
❌ Not attaching real-time listeners
❌ Using old checkUserAccess signature

✅ Always use checkUserAccess() as single source
✅ Always call backend sync functions
✅ Always attach real-time listeners
✅ Always filter by created_by (user isolation)
✅ Always lowercase emails for comparison