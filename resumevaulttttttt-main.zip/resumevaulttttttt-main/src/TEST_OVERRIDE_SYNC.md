# Override Sync Test Guide

## Complete Test Flow

### Setup
- Have two browser windows open
- Window A: Admin logged in, at `/admin`
- Window B: User logged in, at `/` (dashboard)

---

## Test 1: Admin Unlocks Feature → User Sees Instantly

1. **Admin (Window A)**:
   - Search for user email
   - Click "Add Override"
   - Select "Unlock Feature"
   - Check "Resume Templates"
   - Click "Apply Override"

2. **Expected (Window B)**:
   - Dashboard updates automatically
   - No page refresh needed
   - Resume templates become available

3. **Verify**:
   - User can access `/resume-builder` without "locked" message
   - Feature gate shows green checkmark

---

## Test 2: Admin Adds Credits → User Can Spend Instantly

1. **Admin (Window A)**:
   - Search for user
   - Click "Add Override"
   - Select "Add Credits"
   - Enter "50"
   - Click "Apply Override"

2. **Expected (Window B)**:
   - Credit balance shows 50 instantly
   - No refresh needed
   - User can use 50-credit-cost features

3. **Verify**:
   - Dashboard credit card shows 50
   - Feature gates for paid features unlock
   - User can click feature buttons

---

## Test 3: User Uses Feature → Credits Deduct Instantly

1. **Setup**: User has 50 credits

2. **User (Window B)**:
   - Click "Build Resume"
   - Click "Generate AI Resume"
   - Wait for generation to complete

3. **Expected**:
   - Credits deduct by 5 (resume cost)
   - Dashboard shows 45 credits
   - Credit history shows "deduct" entry

4. **Verify**:
   - Dashboard credit balance updates
   - CreditHistory has new entry

---

## Test 4: User Runs Out of Credits → Feature Locks

1. **Setup**: User has 3 credits (not enough for resume = 5)

2. **User (Window B)**:
   - Click "Build Resume"
   - Try to generate resume

3. **Expected**:
   - Feature gate shows "locked" message
   - Upgrade/Buy credits buttons show
   - Feature is disabled

4. **Verify**:
   - Gate displays upgrade modal on click
   - Checkout link works

---

## Test 5: Admin Removes Override → Feature Locks Again

1. **Setup**: Feature was unlocked via admin override

2. **Admin (Window A)**:
   - Search user
   - View override logs
   - Click "Remove" on the unlock override

3. **Expected (Window B)**:
   - Feature locks again instantly
   - Dashboard updates
   - Feature gate shows locked

4. **Verify**:
   - No page refresh needed
   - User returns to plan-based access

---

## Test 6: Admin Upgrades Plan → User Sees New Features

1. **Setup**: User on "Free" plan

2. **Admin (Window A)**:
   - Search user
   - "Add Override" → "Upgrade Plan"
   - Select "Pro"
   - Click "Apply"

3. **Expected (Window B)**:
   - Dashboard plan badge changes to "Pro"
   - Premium tools unlock
   - Monthly limits update (80 resumes instead of 2)
   - Mock interview becomes available

4. **Verify**:
   - Plan card shows "Pro"
   - Premium tools section shows unlocked
   - Feature gates reflect Pro limits

---

## Test 7: User Logs Out/Back In → Access Still Works

1. **Setup**: User has active override or admin-adjusted plan

2. **User (Window B)**:
   - Click logout
   - Log back in
   - Go to dashboard

3. **Expected**:
   - Override still active
   - Plan changes still applied
   - Credits still correct
   - No data loss

4. **Verify**:
   - Dashboard shows same overrides
   - Features stay unlocked
   - Credit balance matches

---

## Test 8: Multiple Users → Overrides Don't Cross-Contaminate

1. **Admin (Window A)**:
   - Search User1 email
   - Add 100 credits

2. **Expected**:
   - User1 sees 100 credits
   - User2 still has original balance
   - Overrides don't affect other users

3. **Admin (Window A)**:
   - Search User2 email
   - Add 50 credits

4. **Expected**:
   - User2 sees 50 credits
   - User1 still sees 100 credits

---

## Test 9: Backend Enforcement

1. **Backend function call**:
   - Call `/verifyFeatureAccess` with a locked feature
   - User should NOT be able to use it

2. **Test**:
   - Call with `featureKey: 'mock_interview'` for Free user
   - Should return `{ canUse: false, reason: 'locked' }`

3. **After admin unlocks**:
   - Same call should return `{ canUse: true }`

---

## Test 10: Real-Time Sync Across Browsers

1. **Setup**:
   - User logged in on Desktop
   - User logged in on Mobile (or second browser)

2. **Admin**:
   - Adds 100 credits to the user

3. **Expected**:
   - Both desktop and mobile see 100 credits
   - No refresh needed
   - Real-time cross-device sync

---

## Test 11: Temporary Access

1. **Admin (Window A)**:
   - "Add Override" → "Temporary Access"
   - Select feature "Mock Interview"
   - Days: "7"
   - Apply

2. **Expected (Window B)**:
   - Mock Interview unlocks instantly
   - Dashboard shows "Temporary Access" badge
   - Expires in 7 days

3. **After 7 days**:
   - Feature should lock again (implement date check)

---

## Test 12: Admin Lock Override

1. **Setup**: User has Pro plan with "Auto Apply" included

2. **Admin (Window A)**:
   - "Add Override" → "Lock Feature"
   - Select "Auto Apply"
   - Apply

3. **Expected (Window B)**:
   - Auto Apply locks despite Pro plan
   - Feature gate shows "admin_lock" message
   - User cannot use Auto Apply

---

## Debugging Checklist

- [ ] `AdminOverridePanel` creates entry in `AdminOverride` table
- [ ] Override updates corresponding `UserProfile` fields
- [ ] Profile update triggers `UserProfile.subscribe()` listeners
- [ ] Dashboard re-renders with new values
- [ ] Feature gates call `checkUserAccess()` and get correct result
- [ ] `verifyFeatureAccess` backend function returns correct response
- [ ] CreditHistory logs all transactions
- [ ] Real-time sync works without refresh

## Common Issues

### Dashboard doesn't update
- [ ] Check that `user?.email` matches override `user_email`
- [ ] Confirm subscribe listener is attached
- [ ] Check browser console for errors

### Feature still shows locked
- [ ] Verify override was created (check AdminOverride table)
- [ ] Confirm UserProfile was updated
- [ ] Check that feature key matches exactly (case-sensitive)
- [ ] Clear browser cache

### Credits don't deduct
- [ ] Verify feature was used and `recordFeatureUsage()` was called
- [ ] Check CreditHistory table for entries
- [ ] Verify UserProfile.ai_credits was updated

### Override applies to wrong user
- [ ] Check that userEmail filter is case-insensitive
- [ ] Confirm `created_by` field matches user email
- [ ] Verify `user_email` in AdminOverride is set correctly