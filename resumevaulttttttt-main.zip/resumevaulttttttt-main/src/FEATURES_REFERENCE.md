# Features Reference — What Unlocks Where

## Feature Definitions

All features and their unlock requirements:

```js
FEATURE_DEFINITIONS = {
  // Core Features
  resume: {
    label: 'AI Resume',
    creditCost: 5,
    free: 2,        // Free: 2 per month
    pro: 80,        // Pro: 80 per month
    elite: 150,     // Elite: 150 per month
  },
  job_analysis: {
    label: 'Job Analyzer',
    creditCost: 2,
    free: 2,
    pro: Infinity,
    elite: Infinity,
  },
  cover_letter: {
    label: 'AI Cover Letter',
    creditCost: 3,
    free: 2,
    pro: Infinity,
    elite: Infinity,
  },
  ats_score: {
    label: 'ATS Score',
    creditCost: 1,
    free: 0,        // Free: locked
    pro: Infinity,
    elite: Infinity,
  },
  advanced_ats_report: {
    label: 'Advanced ATS Report',
    creditCost: 3,
    free: 0,        // Free: locked
    pro: Infinity,
    elite: Infinity,
  },
  resume_templates: {
    label: 'Premium Templates',
    creditCost: 0,
    free: 3,        // Free: 3 templates
    pro: Infinity,
    elite: Infinity,
  },
  resume_comparison: {
    label: 'Resume Comparison',
    creditCost: 0,
    free: false,    // Free: locked
    pro: true,
    elite: true,
  },
  auto_apply: {
    label: 'Auto Apply',
    creditCost: 2,
    free: 0,
    pro: 50,        // Pro: 50 per month
    elite: 200,
  },
  pdf_download: {
    label: 'PDF Download',
    creditCost: 0,
    free: true,
    pro: true,
    elite: true,
  },
  word_download: {
    label: 'Word Download',
    creditCost: 0,
    free: false,
    pro: true,
    elite: true,
  },
  library_editing: {
    label: 'Library Editing',
    creditCost: 0,
    free: true,
    pro: true,
    elite: true,
  },
  mock_interview: {
    label: 'Mock Interview',
    creditCost: 10,
    free: 0,
    pro: 20,        // Pro: 20 per month
    elite: Infinity,
  },
  // ... more features
}
```

## Free Plan

**Monthly Limits:**
- AI Resume: 2/month
- Job Analyzer: 2/month
- Cover Letter: 2/month
- Follow-Up Email: 2/month
- Resume Templates: 3 templates

**Locked Features:**
- ATS Score (0/month)
- Advanced ATS Report (0/month)
- Auto Apply (0/month)
- Mock Interview (0/month)
- Salary Negotiation (0/month)
- Career Roadmap (0/month)
- Portfolio Ideas (0/month)
- Word Download

**Available:**
- PDF Download ✓
- Library Editing ✓
- Resume Comparison ✗

## Pro Plan

**Unlimited:**
- Job Analyzer
- Cover Letters
- Follow-Up Emails
- ATS Score
- Advanced ATS Report
- Salary Negotiation
- Career Roadmap
- Portfolio Ideas
- Resume Comparison ✓
- Word Download ✓

**Limited:**
- AI Resume: 80/month
- Auto Apply: 50/month
- Mock Interview: 20/month
- Resume Templates: Unlimited

**Cost:** $29.99/month or 400 credits

## Elite Plan

**Everything Unlimited:**
- AI Resume: 150/month
- Job Analyzer: Unlimited
- Cover Letter: Unlimited
- Auto Apply: 200/month
- ATS Tools: Unlimited
- Mock Interview: Unlimited
- Salary Negotiation: Unlimited
- Career Roadmap: Unlimited
- Portfolio Ideas: Unlimited
- Resume Comparison ✓
- Word Download ✓
- All Templates ✓

**Cost:** $79.99/month or 800 credits

## Credit Costs

```
Feature                         Cost    Free    Pro     Elite
─────────────────────────────────────────────────────────────
AI Resume                       5       2       80      150
Job Analyzer                    2       2       ∞       ∞
AI Cover Letter                 3       2       ∞       ∞
Follow-Up Email                 2       2       ∞       ∞
ATS Score                       1       0       ∞       ∞
Advanced ATS Report             3       0       ∞       ∞
Resume Templates                0       3       ∞       ∞
Resume Comparison               0       ✗       ✓       ✓
Auto Apply                      2       0       50      200
Salary Negotiation              3       0       ∞       ∞
Career Roadmap                  3       0       ∞       ∞
Portfolio Ideas                 3       0       ∞       ∞
Mock Interview                  10      0       20      ∞
PDF Download                    0       ✓       ✓       ✓
Word Download                   0       ✗       ✓       ✓
Library Editing                 0       ✓       ✓       ✓
```

## Access Priority

When checking if user can use a feature, check in this order:

```
1. Admin Override?
   ├─ Feature unlocked by admin? → ALLOW ✓
   └─ Feature locked by admin? → DENY ✗

2. Subscription Plan?
   ├─ Feature = Infinity? → ALLOW ✓ (unlimited)
   ├─ Monthly quota available? → ALLOW ✓
   └─ No quota? → Continue...

3. Credit Balance?
   ├─ credits >= cost? → ALLOW ✓ (will deduct)
   └─ credits < cost? → Continue...

4. Default: DENY ✗ (locked)
```

## Unlock Scenarios

### Scenario 1: Free User with Credits
```
User: Free plan, 0 credits
Action: Admin adds 10 credits
Result: User now has 10 credits

Available:
- Resume (free limit exhausted, but has 5 credits) → CAN USE ✓
- Job Analyzer (free limit: 2, not exhausted) → CAN USE ✓
- ATS Score (free limit: 0, but has 1 credit) → CAN USE ✓
- Auto Apply (free limit: 0, but has 2 credits) → CAN USE ✓
- Mock Interview (needs 10 credits, has 10) → CAN USE ✓

NOT available:
- Mock Interview if used (only 10 credits total, needs 10 each time)
```

### Scenario 2: Pro User
```
User: Pro plan

All of these unlimited:
✓ Job Analyzer
✓ Cover Letters
✓ ATS Tools
✓ Resume Comparison
✓ Word Download

Limited (per month):
✓ 80 Resumes
✓ 50 Auto Applies
✓ 20 Mock Interviews

Free users who upgrade to Pro:
→ All previously locked features unlock instantly
→ No need to buy credits
→ Monthly limits apply
```

### Scenario 3: Admin Override
```
Admin unlocks 'mock_interview' for user

User: Free plan, 0 credits
Without override: Can't use Mock Interview
With override: CAN USE ✓

No credits deducted
No monthly limit applied
Override shown with expiration date
```

## Credit Purchase Mapping

When user buys credits, map to plan:

```
$4.99   → 25 credits
$9.99   → 60 credits
$24.99  → 200 credits
$49.99  → 500 credits

Credits to resumes:
25 credits = 5 resumes (5 credits each)
60 credits = 12 resumes + 1 job analysis
200 credits = 40 resumes
500 credits = 100 resumes or 250 job analyses
```

## Common Unlock Paths

### Path: Free → Pro ($29.99/month)
```
Before:
- Resume: 2/month
- Job Analyzer: 2/month
- ATS Score: LOCKED

After upgrade:
- Resume: 80/month
- Job Analyzer: Unlimited
- ATS Score: Unlimited
- All premium features: UNLOCKED
```

### Path: Free → Buy 100 Credits ($14.99)
```
Before:
- Resume: 2/month, then LOCKED
- Job Analyzer: 2/month, then LOCKED
- ATS Score: LOCKED

After purchase:
- Resume: 2/month + 20 extra (100 ÷ 5)
- Job Analyzer: 2/month + 50 extra (100 ÷ 2)
- ATS Score: 100 uses (100 ÷ 1)
- Credits shown in dashboard
```

### Path: Pro → Elite ($79.99/month)
```
Before:
- Resume: 80/month
- Auto Apply: 50/month
- Mock Interview: 20/month

After upgrade:
- Resume: 150/month (upgraded)
- Auto Apply: 200/month (upgraded)
- Mock Interview: Unlimited
- All features: UNLIMITED
```

## Feature Visibility

### Always Visible
- AI Resume
- Job Analyzer
- Cover Letter
- Library
- Application Tracker

### Visible When Unlocked (Free)
- Resume Templates (3)
- PDF Download

### Hidden Until Unlocked
- ATS Score (needs Pro/credits)
- Advanced ATS Report (needs Pro/credits)
- Salary Negotiation (needs Pro/credits)
- Career Roadmap (needs Pro/credits)
- Portfolio Ideas (needs Pro/credits)
- Auto Apply (needs Pro/credits)
- Mock Interview (needs Pro/credits)
- Word Download (needs Pro/credits)

### Full Feature Matrix

```
Feature                         Free    Pro     Elite
─────────────────────────────────────────────────────────
AI Resume (generation)          2/mo    80/mo   150/mo
Job Analyzer                    2/mo    ∞       ∞
AI Cover Letter                 2/mo    ∞       ∞
Follow-Up Email (generation)    2/mo    ∞       ∞
Resume Templates (count)        3       ∞       ∞
Resume Comparison               ✗       ✓       ✓
Resume Library (storage)        5       ∞       ∞
Resume Library (editing)        ✓       ✓       ✓
Resume Download (PDF)           ✓       ✓       ✓
Resume Download (Word)          ✗       ✓       ✓
ATS Score                       ✗       ✓       ✓
Advanced ATS Report             ✗       ✓       ✓
Job Applications (tracking)     ✓       ✓       ✓
Auto Apply                      ✗       50/mo   200/mo
Mock Interview                  ✗       20/mo   ∞
Salary Negotiation              ✗       ∞       ∞
Career Roadmap                  ✗       ∞       ∞
Portfolio Ideas                 ✗       ∞       ∞
Follow-Up Email (templates)     ✗       ✓       ✓
```

## Notes

- ✓ = Available / Unlimited
- ✗ = Locked / Not available
- Number = Per month limit
- ∞ = Unlimited
- $/mo = Subscription cost
- Credits shown = How many credits when purchased
- *Overrides bypass all limits when applied by admin