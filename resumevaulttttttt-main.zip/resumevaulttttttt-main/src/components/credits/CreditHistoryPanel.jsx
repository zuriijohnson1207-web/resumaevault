import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { History, Zap, Plus, Minus, CreditCard, ShoppingCart, Settings, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const ACTION_CONFIG = {
  deduct: { label: 'Used', icon: Minus, color: 'text-red-400', badgeClass: 'bg-red-500/10 text-red-400 border-red-500/20' },
  add: { label: 'Added', icon: Plus, color: 'text-green-400', badgeClass: 'bg-green-500/10 text-green-400 border-green-500/20' },
  purchase: { label: 'Purchased', icon: ShoppingCart, color: 'text-primary', badgeClass: 'bg-primary/10 text-primary border-primary/20' },
  subscription: { label: 'Subscription', icon: CreditCard, color: 'text-purple-400', badgeClass: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  admin_adjustment: { label: 'Admin Adjustment', icon: Settings, color: 'text-blue-400', badgeClass: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  refund: { label: 'Refund', icon: TrendingUp, color: 'text-green-400', badgeClass: 'bg-green-500/10 text-green-400 border-green-500/20' },
};

const FEATURE_LABELS = {
  resume: 'AI Resume',
  cover_letter: 'Cover Letter',
  job_analysis: 'Job Analysis',
  follow_up_email: 'Follow-Up Email',
  mock_interview: 'Mock Interview',
  auto_apply: 'Auto Apply',
  salary_negotiation: 'Salary Negotiation',
  career_roadmap: 'Career Roadmap',
  portfolio_ideas: 'Portfolio Ideas',
};

function formatDate(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function CreditHistoryPanel({ limit = 20, compact = false }) {
  const { user } = useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.CreditHistory.filter({ user_email: user.email }, '-created_date', limit)
      .then(h => { setHistory(h); setLoading(false); })
      .catch(() => setLoading(false));
  }, [user?.email]);

  if (loading) return (
    <div className="flex items-center justify-center py-8">
      <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (history.length === 0) return (
    <div className="text-center py-8 text-muted-foreground">
      <History className="w-10 h-10 mx-auto mb-2 opacity-30" />
      <p className="text-sm">No credit history yet.</p>
      <p className="text-xs mt-1">Your credit usage and purchases will appear here.</p>
    </div>
  );

  return (
    <div className="space-y-2">
      {history.map((entry) => {
        const cfg = ACTION_CONFIG[entry.action] || ACTION_CONFIG.add;
        const Icon = cfg.icon;
        const featureLabel = FEATURE_LABELS[entry.feature] || entry.feature;
        const isDeduct = entry.action === 'deduct';
        const isPurchase = entry.action === 'purchase' || entry.action === 'subscription';

        return (
          <div key={entry.id} className={`flex items-center gap-3 p-3 rounded-xl border bg-card/50 ${compact ? 'text-xs' : 'text-sm'}`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${cfg.badgeClass.replace('text-', 'bg-').replace('/10', '/20').replace('border-', 'border-0')}`}>
              <Icon className={`w-4 h-4 ${cfg.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-medium text-foreground">
                  {featureLabel && isDeduct ? featureLabel : (entry.notes || cfg.label)}
                </span>
                <Badge className={`text-xs ${cfg.badgeClass}`}>{cfg.label}</Badge>
                {isPurchase && entry.amount_paid_cents > 0 && (
                  <Badge className="text-xs bg-secondary text-secondary-foreground">${(entry.amount_paid_cents / 100).toFixed(2)}</Badge>
                )}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-2 flex-wrap">
                <span>{formatDate(entry.created_date)}</span>
                {entry.source && <span>• {entry.source.replace(/_/g, ' ')}</span>}
                {entry.balance_after !== undefined && entry.balance_after !== null && (
                  <span>• Balance: <strong className="text-foreground">{entry.balance_after} credits</strong></span>
                )}
              </div>
            </div>
            <div className="shrink-0 text-right">
              {entry.credits_spent > 0 && (
                <div className="text-red-400 font-bold">−{entry.credits_spent}</div>
              )}
              {entry.credits_added > 0 && (
                <div className="text-green-400 font-bold">+{entry.credits_added}</div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}