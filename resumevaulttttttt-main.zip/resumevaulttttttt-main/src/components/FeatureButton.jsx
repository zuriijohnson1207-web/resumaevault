import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { checkUserAccess } from '@/lib/checkUserAccess';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import UpgradeModal from '@/components/UpgradeModal';
import { toast } from 'sonner';

/**
 * UNIVERSAL FEATURE BUTTON
 * 
 * Wrap any feature action with this component:
 * <FeatureButton feature="resume" onClick={handleGenerateResume}>
 *   Generate Resume
 * </FeatureButton>
 * 
 * This button:
 * - Checks access before allowing click
 * - Shows upgrade prompt if locked
 * - Visually indicates lock status
 */

export default function FeatureButton({
  feature,
  children,
  onClick,
  disabled = false,
  variant = 'default',
  size = 'default',
  className = '',
  ...props
}) {
  const { user } = useAuth();
  const [access, setAccess] = useState(null);
  const [checking, setChecking] = useState(true);
  const [showUpgrade, setShowUpgrade] = useState(false);

  // Check access on mount and when user changes
  useEffect(() => {
    const checkAccess_ = async () => {
      if (!user?.email || !feature) {
        setAccess({ canUse: false, reason: 'no_user' });
        setChecking(false);
        return;
      }

      try {
        const result = await checkUserAccess(user.email, feature);
        setAccess(result);
      } catch (e) {
        console.error('Feature access check failed:', e);
        setAccess({ canUse: false, reason: 'error' });
      } finally {
        setChecking(false);
      }
    };

    checkAccess_();
  }, [user?.email, feature]);

  // Admins always can use features
  if (user?.role === 'admin') {
    return (
      <Button
        onClick={onClick}
        disabled={disabled || checking}
        variant={variant}
        size={size}
        className={className}
        {...props}
      >
        {children}
      </Button>
    );
  }

  if (checking) {
    return (
      <Button disabled variant={variant} size={size} className={className}>
        {children}
      </Button>
    );
  }

  // Feature is locked
  if (!access?.canUse) {
    return (
      <>
        <UpgradeModal open={showUpgrade} onClose={() => setShowUpgrade(false)} reason="feature_locked" />
        <Button
          onClick={() => {
            toast.error(`Feature locked — click to upgrade`);
            setShowUpgrade(true);
          }}
          disabled={disabled}
          variant="outline"
          size={size}
          className={`gap-2 ${className}`}
          {...props}
        >
          <Lock className="w-4 h-4" />
          {children}
        </Button>
      </>
    );
  }

  // Feature is accessible
  return (
    <Button
      onClick={onClick}
      disabled={disabled}
      variant={variant}
      size={size}
      className={className}
      {...props}
    >
      {children}
    </Button>
  );
}