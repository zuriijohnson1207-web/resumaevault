import { useState } from 'react';
import { HelpCircle, X } from 'lucide-react';

/**
 * HelpTip — "What does this mean?" accessible tooltip/popover
 * Usage: <HelpTip text="Your email is used to contact you about your application." />
 */
export default function HelpTip({ text, label = "What does this mean?" }) {
  const [open, setOpen] = useState(false);

  return (
    <span className="relative inline-flex items-center">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        aria-label={label}
        aria-expanded={open}
        className="ml-1 text-muted-foreground hover:text-primary transition-colors focus:outline-none focus:ring-2 focus:ring-primary rounded-full"
      >
        <HelpCircle className="w-4 h-4" aria-hidden="true" />
      </button>

      {open && (
        <span
          role="tooltip"
          className="absolute left-6 top-0 z-50 w-64 bg-card border border-border rounded-xl shadow-xl p-3 text-sm text-foreground leading-relaxed"
        >
          <span className="flex items-start gap-2">
            <span className="flex-1">{text}</span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close help tip"
              className="shrink-0 w-6 h-6 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground"
            >
              <X className="w-3 h-3" />
            </button>
          </span>
        </span>
      )}
    </span>
  );
}