import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import { checkUserAccess, FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';
import { Lock, Unlock, Zap, Crown, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

/**
 * Real-time feature unlock display
 * Shows which features are unlocked and why
 * Updates instantly when profile/overrides change
 */

const DISPLAY_FEATURES = [
  { key: 'resume', label: 'AI Resume', group: 'Core' },
  { key: 'job_analysis', label: 'Job Analyzer', group: 'Core' },
  { key: 'ats_score', label: 'ATS Score', group: 'Core' },
  { key: 'advanced_ats_report', label: 'Advanced ATS Report', group: 'Core' },
  { key: 'resume_templates', label: 'Premium Templates', group: 'Core' },
  { key: 'resume_comparison', label: 'Resume Comparison', group: 'Core' },
  { key: 'cover_letter', label: 'AI Cover Letter', group: 'Core' },
  { key: 'auto_apply', label: 'Auto Apply', group: 'Advanced' },
  { key: 'pdf_download', label: 'PDF Download', group: 'Output' },
  { key: 'word_download', label: 'Word Download', group: 'Output' },
  { key: 'library_editing', label: 'Library Editing', group: 'Output' },
  { key: 'mock_interview', label: 'Mock Interview', group: 'Advanced' },
];

export default function FeatureUnlockDisplay() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [accessMap, setAccessMap] = useState({});
  const [loading, setLoading] = useState(true);

  // Fetch and check access for all features
  const refreshAccessMap = async () => {
    if (!user?.email) return;

    const newAccessMap = {};
    for (const feature of DISPLAY_FEATURES) {
      try {
        const access = await checkUserAccess(user.email, feature.key);
        newAccessMap[feature.key] = access;
      } catch (e) {
        newAccessMap[feature.key] = { canUse: false, reason: 'error' };
      }
    }
    setAccessMap(newAccessMap);
  };

  // Load profile on mount
  useEffect(() => {
    if (!user?.email) return;

    const loadProfile = async () => {
      try {
        const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
          await refreshAccessMap();
        }
      } catch (e) {
        console.error('Profile load error:', e);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, [user?.email]);

  // Real-time sync: listen to profile changes
  useEffect(() => {
    if (!user?.email) return;

    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      if (event.data?.created_by?.toLowerCase() === user.email.toLowerCase()) {
        setProfile(event.data);
        refreshAccessMap();
      }
    });

    return () => unsubscribe();
  }, [user?.email]);

  // Real-time sync: listen to override changes
  useEffect(() => {
    if (!user?.email) return;

    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email?.toLowerCase() === user.email.toLowerCase()) {
        refreshAccessMap();
      }
    });

    return () => unsubscribe();
  }, [user?.email]);

  if (loading || !profile) {
    return (
      <Card className="border-border">
        <CardContent className="pt-6 text-center text-muted-foreground">
          Loading features...
        </CardContent>
      </Card>
    );
  }

  const plan = profile.subscription_plan || 'free';
  const credits = profile.ai_credits || 0;
  const unlockedCount = Object.values(accessMap).filter(a => a.canUse).length;

  // Group features
  const grouped = {};
  for (const feature of DISPLAY_FEATURES) {
    if (!grouped[feature.group]) grouped[feature.group] = [];
    grouped[feature.group].push(feature);
  }

  return (
    <div className="space-y-4">
      {/* Status Header */}
      <Card className="bg-gradient-to-r from-card to-primary/5 border-primary/30">
        <CardContent className="pt-5">
          <div className="grid grid-cols-3 gap-3">
            <div className="flex flex-col items-center text-center">
              <Crown className="w-5 h-5 text-primary mb-1" />
              <div className="text-lg font-bold capitalize">{plan}</div>
              <div className="text-xs text-muted-foreground">Plan</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <Zap className="w-5 h-5 text-yellow-400 mb-1" />
              <div className="text-lg font-bold">{credits}</div>
              <div className="text-xs text-muted-foreground">Credits</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <Unlock className="w-5 h-5 text-green-400 mb-1" />
              <div className="text-lg font-bold">{unlockedCount}/{DISPLAY_FEATURES.length}</div>
              <div className="text-xs text-muted-foreground">Unlocked</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Features by Group */}
      {Object.entries(grouped).map(([groupName, features]) => (
        <div key={groupName}>
          <h3 className="text-sm font-bold text-muted-foreground uppercase mb-2">{groupName}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {features.map(feature => {
              const access = accessMap[feature.key] || { canUse: false, reason: 'unknown' };
              const isUnlocked = access.canUse;

              return (
                <div
                  key={feature.key}
                  className={`flex items-center gap-2 p-3 rounded-lg border transition-colors ${
                    isUnlocked
                      ? 'border-green-500/30 bg-green-500/5'
                      : 'border-border bg-card/30'
                  }`}
                >
                  {isUnlocked ? (
                    <Unlock className="w-4 h-4 text-green-400 shrink-0" />
                  ) : (
                    <Lock className="w-4 h-4 text-muted-foreground shrink-0" />
                  )}
                  <div className="flex-1">
                    <div className="text-sm font-semibold">{feature.label}</div>
                    <div className="text-xs text-muted-foreground">
                      {isUnlocked ? (
                        <>
                          {access.reason === 'admin_override' && 'Admin Override'}
                          {access.reason === 'plan_unlimited' && `${plan} Plan`}
                          {access.reason === 'credit_purchase' && `${FEATURE_DEFINITIONS[feature.key]?.creditCost || 1} credits`}
                          {access.reason === 'temporary_access' && 'Temporary Access'}
                          {access.reason === 'plan_monthly_limit' && `${plan} Plan`}
                        </>
                      ) : (
                        <>
                          {access.reason === 'admin_lock' && 'Locked by Admin'}
                          {access.reason === 'locked' && `Needs ${FEATURE_DEFINITIONS[feature.key]?.creditCost || 1} credits`}
                        </>
                      )}
                    </div>
                  </div>
                  {isUnlocked && <Badge className="bg-green-600 text-white text-xs">✓</Badge>}
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Debug Info */}
      {import.meta.env.MODE === 'development' && (
        <Card className="border-border/30 bg-card/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs">Debug Info</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground font-mono">
            <div>Email: {user?.email}</div>
            <div>Plan: {plan}</div>
            <div>Credits: {credits}</div>
            <div>Last sync: {new Date().toLocaleTimeString()}</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}