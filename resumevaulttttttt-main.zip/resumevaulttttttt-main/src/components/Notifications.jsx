/**
 * Global notification system using sonner (already installed).
 * Use the `notify` helper anywhere in the app.
 * 
 * Usage:
 *   import { notify } from '@/components/Notifications';
 *   notify.success('Saved!');
 *   notify.error('Something went wrong.');
 *   notify.info('Processing...');
 *   notify.warning('Low credits.');
 */
import { toast } from 'sonner';

export const notify = {
  success: (msg, opts = {}) => toast.success(msg, { duration: 4000, ...opts }),
  error: (msg, opts = {}) => toast.error(msg, { duration: 5000, ...opts }),
  info: (msg, opts = {}) => toast.info(msg, { duration: 4000, ...opts }),
  warning: (msg, opts = {}) => toast.warning(msg, { duration: 4500, ...opts }),
  loading: (msg, opts = {}) => toast.loading(msg, opts),
  dismiss: (id) => toast.dismiss(id),
  promise: (promise, msgs) => toast.promise(promise, msgs),
};