import { useState, useEffect } from 'react';
import { Type, Sun, ZoomIn, ZoomOut, X, Accessibility } from 'lucide-react';

/**
 * Global Accessibility Toolbar
 * Adds: text size controls, high-contrast mode, and a help tip.
 * Preferences are saved to localStorage so they persist across visits.
 */
export default function AccessibilityToolbar() {
  const [open, setOpen] = useState(false);
  const [fontSize, setFontSize] = useState(() => {
    return parseInt(localStorage.getItem('a11y_fontsize') || '100', 10);
  });
  const [highContrast, setHighContrast] = useState(() => {
    return localStorage.getItem('a11y_contrast') === 'true';
  });

  // Apply font size to <html>
  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
    localStorage.setItem('a11y_fontsize', String(fontSize));
  }, [fontSize]);

  // Apply high contrast class to <html>
  useEffect(() => {
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
    localStorage.setItem('a11y_contrast', String(highContrast));
  }, [highContrast]);

  const increaseFontSize = () => setFontSize(f => Math.min(f + 10, 150));
  const decreaseFontSize = () => setFontSize(f => Math.max(f - 10, 80));
  const resetFontSize = () => setFontSize(100);

  return (
    <>
      {/* Floating accessibility button */}
      <button
        onClick={() => setOpen(o => !o)}
        aria-label="Open accessibility options"
        title="Accessibility Options — Change text size and contrast"
        className="fixed top-4 right-4 z-[60] w-10 h-10 bg-secondary border-2 border-border rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary transition-all focus:outline-none focus:ring-2 focus:ring-primary shadow-lg"
      >
        <Accessibility className="w-5 h-5" />
      </button>

      {/* Panel */}
      {open && (
        <div
          role="dialog"
          aria-label="Accessibility Options"
          className="fixed top-16 right-4 z-[60] bg-card border-2 border-border rounded-2xl shadow-2xl p-4 w-72"
        >
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-base text-foreground flex items-center gap-2">
              <Accessibility className="w-4 h-4 text-primary" />
              Accessibility
            </h2>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close accessibility panel"
              className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Text size */}
          <div className="mb-4">
            <p className="text-sm font-semibold text-foreground mb-2 flex items-center gap-1.5">
              <Type className="w-4 h-4 text-primary" /> Text Size
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={decreaseFontSize}
                disabled={fontSize <= 80}
                aria-label="Decrease text size"
                className="flex-1 h-10 rounded-lg border border-border bg-secondary hover:bg-secondary/80 text-foreground font-bold text-lg disabled:opacity-40 transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
              >
                A−
              </button>
              <button
                onClick={resetFontSize}
                aria-label="Reset text size to default"
                className="flex-1 h-10 rounded-lg border border-border bg-secondary hover:bg-secondary/80 text-foreground text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
              >
                Reset ({fontSize}%)
              </button>
              <button
                onClick={increaseFontSize}
                disabled={fontSize >= 150}
                aria-label="Increase text size"
                className="flex-1 h-10 rounded-lg border border-border bg-secondary hover:bg-secondary/80 text-foreground font-bold text-lg disabled:opacity-40 transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
              >
                A+
              </button>
            </div>
          </div>

          {/* High contrast */}
          <div className="mb-3">
            <p className="text-sm font-semibold text-foreground mb-2 flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-primary" /> High Contrast Mode
            </p>
            <button
              onClick={() => setHighContrast(v => !v)}
              aria-pressed={highContrast}
              className={`w-full h-10 rounded-lg border-2 font-semibold text-sm transition-all focus:outline-none focus:ring-2 focus:ring-primary ${
                highContrast
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-border bg-secondary text-foreground hover:border-primary/50'
              }`}
            >
              {highContrast ? '✓ High Contrast ON' : 'Turn On High Contrast'}
            </button>
          </div>

          <p className="text-xs text-muted-foreground text-center leading-relaxed">
            Your preferences are saved automatically.
          </p>
        </div>
      )}
    </>
  );
}