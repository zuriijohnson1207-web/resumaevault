import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Crown, Lock, Zap, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/AuthContext';
import { useUserAccess } from '@/hooks/useUserAccess';
import { checkUserAccess, FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';
import UpgradeModal from '@/components/UpgradeModal';

/**
 * FEATURE GATE — Universal gate for all locked features
 * This component handles ALL feature access logic in one place
 * 
 * @param {string} featureKey - Feature identifier (e.g., 'resume', 'mock_interview')
 * @param {React.ReactNode} children - Content to show if accessible
 * @param {boolean} hasOverride - Override badge display
 */
export default function FeatureGate({ featureKey, children, hasOverride = false }) {
  const { user } = useAuth();
  const { getAccess, loading } = useUserAccess(user?.email);
  const [access, setAccess] = useState(null);
  const [showModal, setShowModal] = useState(false);

  // Check access on mount and when user email changes
  useEffect(() => {
    if (!user?.email) return;

    const checkAccess_ = async () => {
      const result = await getAccess(featureKey);
      setAccess(result);
    };

    checkAccess_();
  }, [user?.email, featureKey, getAccess]);

  // Admins always get access
  if (user?.role === 'admin') {
    return <>{children}</>;
  }

  if (loading || !access) {
    return (
      <div className="rounded-lg border border-border bg-card/50 p-4 flex items-center gap-3">
        <div className="w-4 h-4 border-2 border-muted border-t-primary rounded-full animate-spin" />
        <span className="text-sm text-muted-foreground">Loading access info...</span>
      </div>
    );
  }

  const feature = FEATURE_DEFINITIONS[featureKey];
  if (!feature) {
    return <div className="text-sm text-destructive">Unknown feature: {featureKey}</div>;
  }

  // Show override badge
  if (hasOverride && access.canUse) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2">
          <AlertCircle className="w-3 h-3 text-purple-400 shrink-0" />
          <span className="text-purple-300 font-semibold">Admin Override Active</span>
          <span className="text-muted-foreground">— {feature.label} is unlocked</span>
        </div>
        {children}
      </div>
    );
  }

  // Feature is accessible
  if (access.canUse) {
    if (access.reason === 'credit_purchase') {
      return (
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs bg-primary/10 border border-primary/30 rounded-lg px-3 py-2">
            <Zap className="w-3 h-3 text-primary shrink-0" />
            <span className="text-primary font-semibold">Using {access.creditsNeeded} credits</span>
            <span className="text-muted-foreground">— per use</span>
          </div>
          {children}
        </div>
      );
    }

    if (access.reason === 'temporary_access') {
      return (
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs bg-orange-500/10 border border-orange-500/30 rounded-lg px-3 py-2">
            <Zap className="w-3 h-3 text-orange-400 shrink-0" />
            <span className="text-orange-300 font-semibold">Temporary Access</span>
            <span className="text-muted-foreground">— expires soon</span>
          </div>
          {children}
        </div>
      );
    }

    return <>{children}</>;
  }

  // Feature is LOCKED
  if (access.reason === 'admin_lock') {
    return (
      <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5 text-center">
        <Lock className="w-7 h-7 text-destructive mx-auto mb-2" />
        <h3 className="font-bold text-foreground text-base mb-1">{feature.label} — Locked</h3>
        <p className="text-sm text-muted-foreground">This feature has been locked by an administrator.</p>
      </div>
    );
  }

  // Feature requires plan upgrade OR credits
  return (
    <>
      <UpgradeModal open={showModal} onClose={() => setShowModal(false)} reason="feature_locked" />
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6 text-center">
        <Lock className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-bold text-foreground text-base mb-1">{feature.label}</h3>
        <p className="text-sm text-muted-foreground mb-2">
          Upgrade your plan or buy credits to unlock this feature.
        </p>
        <p className="text-xs text-muted-foreground mb-4">
          Cost: {access.creditsNeeded} credits · Get {feature.label} access
        </p>
        <div className="flex gap-2 justify-center flex-wrap">
          <Button className="bg-primary text-primary-foreground gap-2" onClick={() => setShowModal(true)}>
            <Crown className="w-4 h-4" /> Upgrade Now
          </Button>
          <Link to="/pricing">
            <Button variant="outline" className="gap-2 border-primary/40 text-primary">
              <Zap className="w-4 h-4" /> Buy Credits
            </Button>
          </Link>
        </div>
      </div>
    </>
  );
}