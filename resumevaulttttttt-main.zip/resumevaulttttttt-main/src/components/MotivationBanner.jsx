import { Zap } from 'lucide-react';

const quotes = [
  "Excellence isn't an act, it's a habit. Build the habit with Resumevault.",
  "Beat the ATS in 60 seconds. God-Mode your job hunt.",
  "Your resume isn't just a document—it's your first conversation with a recruiter.",
  "The best time to start was yesterday. The next best time is now.",
];

export default function MotivationBanner({ quote }) {
  const text = quote || quotes[0];
  return (
    <div className="flex items-center gap-2 px-4 py-2 bg-primary/5 border border-primary/20 rounded-lg mb-6 text-sm text-primary italic">
      <Zap className="w-4 h-4 shrink-0" />
      <span>{text}</span>
    </div>
  );
}