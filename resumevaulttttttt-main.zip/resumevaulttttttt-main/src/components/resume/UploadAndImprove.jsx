import { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Upload, Sparkles, Loader2, Copy, Download, FileText, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';

export default function UploadAndImprove() {
  const { toast } = useToast();
  const fileRef = useRef(null);
  const [rawText, setRawText] = useState('');
  const [improved, setImproved] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [fileName, setFileName] = useState('');

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const res = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: 'object',
          properties: { resume_text: { type: 'string' } },
        },
      });
      if (res?.status === 'success') {
        const text = res.output?.resume_text || JSON.stringify(res.output);
        setRawText(text);
        toast({ title: '✅ Resume extracted! Review and click Improve.' });
      } else {
        toast({ title: 'Could not extract text. Paste your resume below instead.', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Upload failed. Please paste your resume text manually.', variant: 'destructive' });
    }
    setUploading(false);
  };

  const improve = async () => {
    if (!rawText.trim()) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert resume writer. Take this raw resume text and rebuild it into a clean, ATS-friendly, professional format.

RAW RESUME:
${rawText}

RULES:
- NO hashtags, NO pound signs, NO asterisks as decoration
- Use plain dashes (-) for bullets
- Section headers in ALL CAPS
- Clean spacing, active voice, strong action verbs
- Add metrics where logical based on context
- Remove fluff, filler words, and redundancy
- Keep all real information — do not add fake data
- ATS-safe formatting throughout

Output the improved, polished resume ready to copy-paste or download.`,
    });
    setImproved(typeof res === 'string' ? res : JSON.stringify(res));
    setLoading(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(improved);
    toast({ title: 'Copied to clipboard!' });
  };

  const downloadTxt = () => {
    const blob = new Blob([improved], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'improved_resume.txt';
    a.click();
  };

  const downloadPDF = () => {
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>Improved Resume</title>
    <style>body{font-family:Arial,sans-serif;font-size:11pt;margin:.75in;color:#111;line-height:1.4}pre{white-space:pre-wrap;font-family:Arial,sans-serif}</style>
    </head><body><pre>${improved.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</pre></body></html>`);
    w.document.close();
    setTimeout(() => { w.print(); w.close(); }, 400);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Upload className="w-4 h-4 text-primary" /> Upload & Improve Your Resume
          </CardTitle>
          <p className="text-xs text-muted-foreground">Upload a PDF or DOCX — AI will extract, clean, and rebuild it</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Upload button */}
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed border-primary/30 rounded-xl p-6 text-center cursor-pointer hover:border-primary/60 hover:bg-primary/5 transition-all"
          >
            <input ref={fileRef} type="file" accept=".pdf,.docx,.doc,.txt" className="hidden" onChange={handleFile} />
            {uploading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
                <p className="text-sm text-muted-foreground">Extracting text from {fileName}...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-primary/50" />
                <p className="text-sm font-medium text-foreground">Click to upload PDF or DOCX</p>
                <p className="text-xs text-muted-foreground">Or paste your resume text below</p>
                {fileName && (
                  <span className="text-xs text-green-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {fileName} uploaded
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Paste area */}
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Your Resume Text</label>
            <Textarea
              value={rawText}
              onChange={e => setRawText(e.target.value)}
              placeholder="Paste your existing resume here, or upload a file above..."
              className="h-40 resize-none font-mono text-xs"
            />
          </div>

          <Button
            onClick={improve}
            disabled={loading || !rawText.trim()}
            className="w-full h-11 gap-2 font-bold"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {loading ? 'Improving Your Resume...' : 'Improve & Rebuild with AI'}
          </Button>
        </CardContent>
      </Card>

      {/* Improved output */}
      {(loading || improved) && (
        <Card className="border-green-500/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="w-4 h-4 text-green-400" /> Improved Resume
              </CardTitle>
              {improved && (
                <div className="flex gap-1.5 flex-wrap">
                  <Button size="sm" variant="outline" onClick={copy} className="gap-1 h-8 text-xs">
                    <Copy className="w-3 h-3" /> Copy
                  </Button>
                  <Button size="sm" variant="outline" onClick={downloadTxt} className="gap-1 h-8 text-xs">
                    <Download className="w-3 h-3" /> TXT
                  </Button>
                  <Button size="sm" variant="outline" onClick={downloadPDF} className="gap-1 h-8 text-xs">
                    <Download className="w-3 h-3" /> PDF
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex flex-col items-center justify-center h-40 gap-3">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
                <p className="text-sm text-muted-foreground">Rebuilding your resume with AI...</p>
              </div>
            ) : (
              <pre className="text-sm text-foreground whitespace-pre-wrap font-sans leading-relaxed max-h-[60vh] overflow-y-auto bg-white/5 rounded-lg p-4 border border-border">
                {improved}
              </pre>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}