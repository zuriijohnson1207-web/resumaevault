import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, CheckCircle2, AlertTriangle, XCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

function ScoreRing({ score }) {
  const color = score >= 75 ? '#22c55e' : score >= 50 ? '#eab308' : '#ef4444';
  const label = score >= 75 ? 'Great' : score >= 50 ? 'Needs Work' : 'Low Match';
  const radius = 36;
  const circ = 2 * Math.PI * radius;
  const dash = (score / 100) * circ;

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width="96" height="96" viewBox="0 0 96 96">
        <circle cx="48" cy="48" r={radius} fill="none" stroke="hsl(var(--border))" strokeWidth="8" />
        <circle
          cx="48" cy="48" r={radius} fill="none"
          stroke={color} strokeWidth="8"
          strokeDasharray={`${dash} ${circ}`}
          strokeLinecap="round"
          transform="rotate(-90 48 48)"
          style={{ transition: 'stroke-dasharray 0.8s ease' }}
        />
        <text x="48" y="48" textAnchor="middle" dominantBaseline="middle" fontSize="18" fontWeight="700" fill={color}>{score}</text>
        <text x="48" y="64" textAnchor="middle" dominantBaseline="middle" fontSize="9" fill="hsl(var(--muted-foreground))">/ 100</text>
      </svg>
      <Badge
        className={`text-xs border ${
          score >= 75 ? 'bg-green-500/20 text-green-400 border-green-500/30' :
          score >= 50 ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
          'bg-red-500/20 text-red-400 border-red-500/30'
        }`}
      >
        {label}
      </Badge>
    </div>
  );
}

export default function ATSAnalysisPanel({ resumeText, jobDescription }) {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    if (!resumeText) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an ATS (Applicant Tracking System) expert. Analyze this resume against the job description and return a detailed ATS analysis.

RESUME:
${resumeText}

JOB DESCRIPTION:
${jobDescription || 'No job description provided — analyze resume quality alone.'}

Return a JSON object with:
- ats_score: number 0-100 (overall ATS compatibility)
- keyword_score: number 0-100 (keyword match percentage)
- missing_keywords: array of strings (important keywords from job description missing in resume)
- matched_keywords: array of strings (keywords found in both)
- suggestions: array of strings (specific improvement tips, max 5)
- formatting_issues: array of strings (any ATS formatting problems found)
- strengths: array of strings (what's working well, max 3)`,
      response_json_schema: {
        type: 'object',
        properties: {
          ats_score: { type: 'number' },
          keyword_score: { type: 'number' },
          missing_keywords: { type: 'array', items: { type: 'string' } },
          matched_keywords: { type: 'array', items: { type: 'string' } },
          suggestions: { type: 'array', items: { type: 'string' } },
          formatting_issues: { type: 'array', items: { type: 'string' } },
          strengths: { type: 'array', items: { type: 'string' } },
        },
      },
    });
    setAnalysis(res);
    setLoading(false);
  };

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> ATS Analysis
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              AI scans your resume like a real ATS system
            </p>
          </div>
          <Button
            size="sm"
            onClick={analyze}
            disabled={loading || !resumeText}
            className="gap-1.5 h-8 text-xs"
          >
            {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            {loading ? 'Analyzing...' : analysis ? 'Re-Analyze' : 'Analyze Resume'}
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* ATS Info Box */}
        <div className="flex gap-2 p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl">
          <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <p className="text-xs text-blue-300 leading-relaxed">
            <strong>What is ATS?</strong> An Applicant Tracking System automatically scans resumes before a human ever reads them. It filters candidates based on keywords and formatting. A score of 75+ means you're likely to pass the filter.
          </p>
        </div>

        {loading && (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm text-muted-foreground">Running ATS scan...</p>
          </div>
        )}

        {analysis && !loading && (
          <div className="space-y-4">
            {/* Score row */}
            <div className="flex gap-4 items-start flex-wrap">
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1 font-medium">ATS Score</p>
                <ScoreRing score={analysis.ats_score ?? 0} />
              </div>
              <div className="text-center">
                <p className="text-xs text-muted-foreground mb-1 font-medium">Keyword Match</p>
                <ScoreRing score={analysis.keyword_score ?? 0} />
              </div>
            </div>

            {/* Strengths */}
            {analysis.strengths?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-green-400 mb-1.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Strengths
                </p>
                <ul className="space-y-1">
                  {analysis.strengths.map((s, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-1.5">
                      <span className="text-green-400 mt-0.5">✓</span> {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Missing Keywords */}
            {analysis.missing_keywords?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-red-400 mb-1.5 flex items-center gap-1">
                  <XCircle className="w-3 h-3" /> Missing Keywords
                </p>
                <div className="flex flex-wrap gap-1">
                  {analysis.missing_keywords.map((kw, i) => (
                    <span key={i} className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full">{kw}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Matched Keywords */}
            {analysis.matched_keywords?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-green-400 mb-1.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Matched Keywords
                </p>
                <div className="flex flex-wrap gap-1">
                  {analysis.matched_keywords.slice(0, 12).map((kw, i) => (
                    <span key={i} className="text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full">{kw}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Suggestions */}
            {analysis.suggestions?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-yellow-400 mb-1.5 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Optimization Tips
                </p>
                <ul className="space-y-1.5">
                  {analysis.suggestions.map((s, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-1.5">
                      <span className="text-yellow-400 mt-0.5">→</span> {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Formatting Issues */}
            {analysis.formatting_issues?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-orange-400 mb-1.5">Formatting Issues</p>
                <ul className="space-y-1">
                  {analysis.formatting_issues.map((s, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-1.5">
                      <span className="text-orange-400 mt-0.5">!</span> {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {!analysis && !loading && (
          <div className="text-center py-6 text-muted-foreground">
            <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Generate a resume first, then click Analyze</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}