import { RESUME_TEMPLATES } from '@/data/resumeTemplates';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function TemplateSelector({ selected, onSelect }) {
  return (
    <div>
      <p className="text-sm font-semibold text-foreground mb-3">Choose a Template Style</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {RESUME_TEMPLATES.map(t => (
          <button
            key={t.id}
            type="button"
            onClick={() => onSelect(t)}
            className={cn(
              'relative rounded-xl border-2 p-3 text-left transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2',
              selected?.id === t.id
                ? 'border-primary bg-primary/10 shadow-lg shadow-primary/20'
                : 'border-border hover:border-primary/50 hover:bg-accent'
            )}
            aria-pressed={selected?.id === t.id}
            aria-label={`Select ${t.name} template`}
          >
            {selected?.id === t.id && (
              <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                <Check className="w-3 h-3 text-primary-foreground" />
              </span>
            )}
            <div className={`w-full h-10 rounded-lg bg-gradient-to-br ${t.preview_color} mb-2 flex items-center justify-center text-xl`}>
              {t.icon}
            </div>
            <p className="text-xs font-semibold text-foreground leading-tight">{t.name}</p>
            <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{t.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}