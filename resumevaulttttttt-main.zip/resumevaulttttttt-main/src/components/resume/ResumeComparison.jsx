import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, GitCompare, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function ResumeComparison({ onGenerateOptimized }) {
  const [resume, setResume] = useState('');
  const [jobDesc, setJobDesc] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);

  const compare = async () => {
    if (!resume.trim() || !jobDesc.trim()) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Compare this resume against the job description. Identify exact gaps and improvements needed.

RESUME:
${resume}

JOB DESCRIPTION:
${jobDesc}

Return JSON with:
- skills_missing: array of strings (skills in JD not in resume)
- skills_matching: array of strings (skills that match)
- keywords_to_add: array of strings (exact keywords to add)
- keywords_to_remove: array of strings (irrelevant or weak words to cut)
- improvements: array of objects with { section: string, issue: string, fix: string }
- overall_gap: string ("Small" | "Moderate" | "Large")
- gap_summary: string (2-3 sentence summary of main gaps)`,
      response_json_schema: {
        type: 'object',
        properties: {
          skills_missing: { type: 'array', items: { type: 'string' } },
          skills_matching: { type: 'array', items: { type: 'string' } },
          keywords_to_add: { type: 'array', items: { type: 'string' } },
          keywords_to_remove: { type: 'array', items: { type: 'string' } },
          improvements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                section: { type: 'string' },
                issue: { type: 'string' },
                fix: { type: 'string' },
              },
            },
          },
          overall_gap: { type: 'string' },
          gap_summary: { type: 'string' },
        },
      },
    });
    setAnalysis(res);
    setLoading(false);
  };

  const gapColor = (g) => {
    if (g === 'Small') return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (g === 'Moderate') return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    return 'bg-red-500/20 text-red-400 border-red-500/30';
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-primary" /> Resume vs Job Description Comparison
          </CardTitle>
          <p className="text-xs text-muted-foreground">Find exactly what's missing and what to improve</p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Your Resume</label>
            <Textarea
              value={resume}
              onChange={e => setResume(e.target.value)}
              placeholder="Paste your current resume here..."
              className="h-32 resize-none font-mono text-xs"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Job Description</label>
            <Textarea
              value={jobDesc}
              onChange={e => setJobDesc(e.target.value)}
              placeholder="Paste the job description here..."
              className="h-32 resize-none text-xs"
            />
          </div>
          <Button
            onClick={compare}
            disabled={loading || !resume.trim() || !jobDesc.trim()}
            className="w-full h-11 gap-2 font-bold"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <GitCompare className="w-4 h-4" />}
            {loading ? 'Analyzing Gap...' : 'Compare & Find Gaps'}
          </Button>
        </CardContent>
      </Card>

      {analysis && !loading && (
        <div className="space-y-3">
          {/* Gap summary */}
          <Card>
            <CardContent className="pt-4 space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold">Overall Gap:</span>
                <Badge className={`border text-xs ${gapColor(analysis.overall_gap)}`}>
                  {analysis.overall_gap}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{analysis.gap_summary}</p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Matching */}
            {analysis.skills_matching?.length > 0 && (
              <Card className="border-green-500/20">
                <CardContent className="pt-4">
                  <p className="text-xs font-semibold text-green-400 mb-2">✓ Skills Matching</p>
                  <div className="flex flex-wrap gap-1">
                    {analysis.skills_matching.map((s, i) => (
                      <span key={i} className="text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full">{s}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Missing */}
            {analysis.skills_missing?.length > 0 && (
              <Card className="border-red-500/20">
                <CardContent className="pt-4">
                  <p className="text-xs font-semibold text-red-400 mb-2">✗ Missing Skills</p>
                  <div className="flex flex-wrap gap-1">
                    {analysis.skills_missing.map((s, i) => (
                      <span key={i} className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full">{s}</span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Keywords */}
          {analysis.keywords_to_add?.length > 0 && (
            <Card className="border-yellow-500/20">
              <CardContent className="pt-4">
                <p className="text-xs font-semibold text-yellow-400 mb-2">+ Keywords to Add</p>
                <div className="flex flex-wrap gap-1">
                  {analysis.keywords_to_add.map((k, i) => (
                    <span key={i} className="text-xs bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-0.5 rounded-full">{k}</span>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Section improvements */}
          {analysis.improvements?.length > 0 && (
            <Card>
              <CardContent className="pt-4 space-y-3">
                <p className="text-xs font-semibold text-foreground">Specific Improvements</p>
                {analysis.improvements.map((imp, i) => (
                  <div key={i} className="border border-border rounded-lg p-3 space-y-1">
                    <p className="text-xs font-semibold text-primary">{imp.section}</p>
                    <p className="text-xs text-red-400">Issue: {imp.issue}</p>
                    <p className="text-xs text-green-400">Fix: {imp.fix}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Button
            onClick={() => onGenerateOptimized?.(resume, jobDesc)}
            className="w-full h-11 gap-2 font-bold shadow-lg shadow-primary/30"
          >
            <Sparkles className="w-4 h-4" />
            Generate New Optimized Resume <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}