import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Zap, Loader2, Copy, Download, FileDown, Save, CheckCircle2,
  AlertCircle, Sparkles, TrendingUp, Target, Info, CreditCard,
  ArrowRight, Lock
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { usePlanLimits, CREDIT_COSTS } from '@/hooks/usePlanLimits';
import { buildQuickResumePrompt } from '@/data/resumeTemplates';
import { toast } from 'sonner';
import UpgradeModal from '@/components/UpgradeModal';

function ATSScorePanel({ resumeText, jobDescription }) {
  const [score, setScore] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const analyze = async () => {
    if (!resumeText || !jobDescription) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an ATS (Applicant Tracking System) expert. Analyze this resume against the job description.

JOB DESCRIPTION:
${jobDescription}

RESUME:
${resumeText}

Return ONLY a JSON object with this exact shape:
{
  "score": <number 0-100>,
  "keyword_match": <number 0-100>,
  "matched_keywords": [<array of strings>],
  "missing_keywords": [<array of strings>],
  "suggestions": [<array of short improvement strings, max 5>],
  "summary": "<one sentence overall assessment>"
}`,
      response_json_schema: {
        type: 'object',
        properties: {
          score: { type: 'number' },
          keyword_match: { type: 'number' },
          matched_keywords: { type: 'array', items: { type: 'string' } },
          missing_keywords: { type: 'array', items: { type: 'string' } },
          suggestions: { type: 'array', items: { type: 'string' } },
          summary: { type: 'string' },
        }
      }
    });
    setResult(res);
    setScore(res.score);
    setLoading(false);
  };

  const scoreColor = score >= 75 ? 'text-green-400' : score >= 50 ? 'text-yellow-400' : 'text-red-400';
  const scoreBg = score >= 75 ? 'bg-green-500/10 border-green-500/30' : score >= 50 ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-red-500/10 border-red-500/30';

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" /> ATS Analysis
          </CardTitle>
          {!result && (
            <Button
              size="sm"
              variant="outline"
              onClick={analyze}
              disabled={loading || !resumeText || !jobDescription}
              className="h-7 text-xs gap-1"
            >
              {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <TrendingUp className="w-3 h-3" />}
              Analyze
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {!resumeText ? (
          <p className="text-xs text-muted-foreground text-center py-4">Generate a resume first to see ATS score</p>
        ) : !jobDescription ? (
          <p className="text-xs text-muted-foreground text-center py-4">Add a job description for ATS analysis</p>
        ) : loading ? (
          <div className="flex flex-col items-center py-6 gap-2">
            <Loader2 className="w-6 h-6 text-primary animate-spin" />
            <p className="text-xs text-muted-foreground">Analyzing ATS match...</p>
          </div>
        ) : result ? (
          <div className="space-y-3">
            {/* Score */}
            <div className={`flex items-center gap-3 p-3 rounded-xl border ${scoreBg}`}>
              <span className={`text-3xl font-black ${scoreColor}`}>{result.score}</span>
              <div>
                <p className={`text-sm font-semibold ${scoreColor}`}>ATS Score / 100</p>
                <p className="text-xs text-muted-foreground">{result.summary}</p>
              </div>
            </div>

            {/* Keyword Match */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Keyword Match</span>
              <span className="font-semibold text-foreground">{result.keyword_match}%</span>
            </div>
            <div className="w-full bg-secondary rounded-full h-1.5">
              <div className="bg-primary rounded-full h-1.5 transition-all" style={{ width: `${result.keyword_match}%` }} />
            </div>

            {/* Matched */}
            {result.matched_keywords?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5 font-medium">Matched Keywords</p>
                <div className="flex flex-wrap gap-1">
                  {result.matched_keywords.slice(0, 10).map((kw, i) => (
                    <Badge key={i} className="bg-green-500/10 text-green-400 border-green-500/20 border text-xs px-1.5 py-0">{kw}</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Missing */}
            {result.missing_keywords?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5 font-medium">Missing Keywords</p>
                <div className="flex flex-wrap gap-1">
                  {result.missing_keywords.slice(0, 10).map((kw, i) => (
                    <Badge key={i} className="bg-red-500/10 text-red-400 border-red-500/20 border text-xs px-1.5 py-0">{kw}</Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Suggestions */}
            {result.suggestions?.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5 font-medium">Improvements</p>
                <ul className="space-y-1">
                  {result.suggestions.map((s, i) => (
                    <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                      <ArrowRight className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <Button size="sm" variant="ghost" onClick={() => { setResult(null); setScore(null); }} className="w-full h-7 text-xs">
              Re-analyze
            </Button>

            {/* ATS Explanation */}
            <div className="flex gap-2 p-2.5 bg-secondary/50 rounded-lg">
              <Info className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                ATS (Applicant Tracking System) software scans resumes before a human sees them. A score above 75 means your resume is likely to pass automated screening.
              </p>
            </div>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-4">Click Analyze to check ATS compatibility</p>
        )}
      </CardContent>
    </Card>
  );
}



export default function QuickResumeMode({ onSaveResume }) {
  const { canUse, incrementUsage, plan, getUsage, profile, isAdmin } = usePlanLimits();
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [workHistory, setWorkHistory] = useState('');
  const [skills, setSkills] = useState('');
  const [education, setEducation] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [resumeLength, setResumeLength] = useState('full');
  const [generated, setGenerated] = useState('');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  const usage = getUsage('resume');
  const creditCost = CREDIT_COSTS.resume;
  const userCredits = profile?.ai_credits || 0;
  const allowed = canUse('resume');

  const parseOutput = (text) => {
    const checklistMatch = text.match(/MISSING INFO CHECKLIST([\s\S]*?)(?:---\s*SUGGESTIONS|$)/i);
    const suggestionsMatch = text.match(/SUGGESTIONS TO STRENGTHEN YOUR RESUME([\s\S]*?)(?:---|$)/i);
    const resumeEnd = text.search(/---\s*\n*MISSING INFO CHECKLIST/i);
    const resumeBody = resumeEnd > 0 ? text.slice(0, resumeEnd).trim() : text;
    const checklist = checklistMatch?.[1]?.trim() || '';
    const suggestions = suggestionsMatch?.[1]?.trim() || '';
    return { resumeBody, checklist, suggestions };
  };

  const generate = async () => {
    if (!allowed) return;
    if (!jobTitle.trim()) {
      toast.error('Please enter the job title you are applying for.');
      return;
    }
    setLoading(true);
    setSaved(false);
    setGenerated('');
    const prompt = buildQuickResumePrompt(name, contact, jobTitle, workHistory, skills, education, jobDescription, resumeLength);
    const res = await base44.integrations.Core.InvokeLLM({ prompt });
    setGenerated(typeof res === 'string' ? res : JSON.stringify(res));
    await incrementUsage('resume');
    setLoading(false);
    toast.success('Resume generated successfully!');
  };

  const { resumeBody, checklist, suggestions } = generated ? parseOutput(generated) : {};

  const copy = () => {
    navigator.clipboard.writeText(resumeBody || generated);
    toast.success('Copied to clipboard!');
  };

  const downloadPDF = () => {
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>Resume</title>
    <style>body{font-family:Arial,sans-serif;font-size:11pt;margin:.75in;color:#111;line-height:1.4}pre{white-space:pre-wrap;font-family:Arial,sans-serif}</style>
    </head><body><pre>${(resumeBody || generated).replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre></body></html>`);
    w.document.close();
    setTimeout(() => { w.print(); w.close(); }, 400);
  };

  const downloadDOCX = () => {
    const content = resumeBody || generated;
    const blob = new Blob([
      `\uFEFF<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body><w:p><w:r><w:t xml:space="preserve">${content.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '</w:t></w:r></w:p><w:p><w:r><w:t xml:space="preserve">')}</w:t></w:r></w:p></w:body>
</w:document>`
    ], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${name || 'resume'}_${jobTitle || 'resume'}.docx`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('DOCX downloaded!');
  };

  const save = async () => {
    await base44.entities.Resume.create({
      title: `${jobTitle} — Quick Resume`,
      job_title: jobTitle,
      content: resumeBody || generated,
      type: 'general',
    });
    setSaved(true);
    toast.success('Saved to your Resume Library!');
    onSaveResume?.();
  };

  const hasPlaceholders = generated && /\[Company Name\]|\[School Name\]|\[Start Date\]|\[End Date\]|\[Certification\]|\[Dates\]|\[Your/i.test(generated);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr_280px] gap-6">
      {/* Left: Input Form */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 p-3 bg-primary/10 border border-primary/30 rounded-xl">
          <Zap className="w-5 h-5 text-primary shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-primary">Quick AI Resume Mode</p>
            <p className="text-xs text-muted-foreground">Minimum input, maximum results — honest AI, no fake info</p>
          </div>
        </div>

        {/* Credit/Usage bar */}
        {!isAdmin && (
          <div className="flex items-center justify-between px-3 py-2 bg-secondary/30 rounded-xl border border-border text-xs">
            <div className="flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-muted-foreground">Cost: <strong className="text-foreground">{creditCost} credits</strong></span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-muted-foreground">
                Used: <strong className={usage.remaining === 0 ? 'text-red-400' : 'text-foreground'}>{usage.used}/{usage.limit === Infinity ? '∞' : usage.limit}</strong>
              </span>
              <span className="text-muted-foreground">
                Credits: <strong className={userCredits < creditCost ? 'text-red-400' : 'text-foreground'}>{userCredits}</strong>
              </span>
            </div>
          </div>
        )}

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Basic Info</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Full Name</label>
              <Input value={name} onChange={e => setName(e.target.value)} placeholder="Jane Smith" className="h-10" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Email & Phone</label>
              <Input value={contact} onChange={e => setContact(e.target.value)} placeholder="jane@email.com | (555) 123-4567" className="h-10" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Job Title You Want *</label>
              <Input value={jobTitle} onChange={e => setJobTitle(e.target.value)} placeholder="e.g. Customer Service Representative" className="h-10" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Your Background</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Basic Work History <span className="text-muted-foreground/60">(optional)</span></label>
              <Textarea
                value={workHistory}
                onChange={e => setWorkHistory(e.target.value)}
                placeholder="e.g. Cashier at a grocery store for 2 years. Helped customers, handled returns, managed cash register.&#10;&#10;Or just: worked retail for 3 years"
                className="h-24 resize-none text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Skills <span className="text-muted-foreground/60">(comma separated, optional)</span></label>
              <Textarea
                value={skills}
                onChange={e => setSkills(e.target.value)}
                placeholder="e.g. Customer service, Microsoft Office, teamwork, cash handling..."
                className="h-20 resize-none text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Education <span className="text-muted-foreground/60">(optional)</span></label>
              <Input
                value={education}
                onChange={e => setEducation(e.target.value)}
                placeholder="e.g. High school diploma 2018, or some college"
                className="h-10"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Job Description <span className="text-primary">(paste for best ATS results)</span></CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={jobDescription}
              onChange={e => setJobDescription(e.target.value)}
              placeholder="Paste the job posting here — AI will add matching ATS keywords naturally without making anything up..."
              className="h-28 resize-none text-sm"
            />
          </CardContent>
        </Card>

        <div>
          <label className="text-xs font-medium text-muted-foreground mb-2 block">Resume Length</label>
          <div className="flex gap-2">
            {[{ val: '1page', label: '1 Page' }, { val: 'full', label: 'Full Resume' }].map(opt => (
              <button
                key={opt.val}
                type="button"
                onClick={() => setResumeLength(opt.val)}
                className={`flex-1 py-2 px-3 rounded-lg border text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary ${resumeLength === opt.val ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/50'}`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <UpgradeModal open={showUpgradeModal} onClose={() => setShowUpgradeModal(false)} reason="free_limit" />

        {allowed ? (
          <Button
            onClick={generate}
            disabled={loading || !jobTitle.trim()}
            className="w-full h-12 text-base font-bold gap-2 shadow-lg shadow-primary/30"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
            {loading ? 'Building Your Resume...' : `Generate Quick Resume (${creditCost} credits)`}
          </Button>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
              <Lock className="w-5 h-5 text-yellow-400 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-yellow-300">Free limit reached</p>
                <p className="text-xs text-yellow-300/80">You've used your 2 free resume generations.</p>
              </div>
            </div>
            <Button className="w-full h-11 font-bold gap-2" onClick={() => setShowUpgradeModal(true)}>
              <Sparkles className="w-4 h-4" /> Upgrade to Keep Building
            </Button>
          </div>
        )}

        {allowed && (
          <p className="text-xs text-muted-foreground text-center">
            AI only uses info you provide. Missing details appear as clearly marked placeholders — never fake data.
          </p>
        )}
      </div>

      {/* Center: Output Panel */}
      <div className="space-y-4">
        <Card className={generated && !loading ? 'border-primary/30' : ''}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <CardTitle className="text-sm flex items-center gap-2">
                Your Resume
                {generated && !loading && (
                  <Badge className="bg-green-500/20 text-green-400 border border-green-500/30 text-xs">
                    <CheckCircle2 className="w-3 h-3 mr-1" />Ready
                  </Badge>
                )}
              </CardTitle>
              {generated && !loading && (
                <div className="flex gap-1.5 flex-wrap">
                  <Button size="sm" variant="outline" onClick={copy} className="gap-1 h-7 text-xs"><Copy className="w-3 h-3" />Copy</Button>
                  <Button size="sm" variant="outline" onClick={downloadPDF} className="gap-1 h-7 text-xs"><FileDown className="w-3 h-3" />PDF</Button>
                  <Button size="sm" variant="outline" onClick={downloadDOCX} className="gap-1 h-7 text-xs"><Download className="w-3 h-3" />DOCX</Button>
                  <Button size="sm" onClick={save} disabled={saved} className="gap-1 h-7 text-xs"><Save className="w-3 h-3" />{saved ? 'Saved ✓' : 'Save'}</Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex flex-col items-center justify-center h-48 gap-3">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
                <p className="text-sm text-muted-foreground">Building your honest, ATS-ready resume...</p>
                <p className="text-xs text-muted-foreground">~15–20 seconds</p>
              </div>
            ) : resumeBody ? (
              <pre className="text-sm text-foreground whitespace-pre-wrap font-sans leading-relaxed max-h-[60vh] overflow-y-auto bg-white/5 rounded-lg p-4 border border-border">
                {resumeBody}
              </pre>
            ) : (
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground text-center gap-2">
                <Zap className="w-10 h-10 opacity-20" />
                <p className="text-sm">Your resume will appear here</p>
                <p className="text-xs">Fill in at least a job title and click Generate</p>
              </div>
            )}
          </CardContent>
        </Card>

        {hasPlaceholders && (
          <div className="flex gap-2 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
            <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-yellow-300 mb-0.5">Add your real details before applying</p>
              <p className="text-xs text-yellow-300/80">Replace all <code className="bg-yellow-500/20 px-1 rounded">[bracketed]</code> placeholders with your actual information before submitting this resume.</p>
            </div>
          </div>
        )}

        {checklist && (
          <Card className="border-yellow-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-yellow-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> Missing Info Checklist
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-xs text-muted-foreground whitespace-pre-wrap leading-relaxed">{checklist}</pre>
            </CardContent>
          </Card>
        )}

        {suggestions && (
          <Card className="border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-primary flex items-center gap-2">
                <Sparkles className="w-4 h-4" /> Smart Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-xs text-muted-foreground whitespace-pre-wrap leading-relaxed">{suggestions}</pre>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Right: ATS Panel */}
      <div className="self-start">
        <ATSScorePanel resumeText={resumeBody || generated} jobDescription={jobDescription} />
      </div>
    </div>
  );
}