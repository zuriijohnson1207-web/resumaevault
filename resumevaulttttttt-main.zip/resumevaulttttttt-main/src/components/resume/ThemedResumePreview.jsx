import { getTemplateById } from '@/data/resumeTemplates';

/**
 * Renders a resume with FULL structural layout changes per template.
 * Not just colors — actual layout, spacing, header style, column structure,
 * section order, bullet style, and visual hierarchy all change per template.
 */
export default function ThemedResumePreview({ content, templateId, className = '' }) {
  const template = getTemplateById(templateId);
  const { theme, layout = 'single' } = template;

  if (!content) return null;

  // ─── Parse content into sections ───────────────────────────────────────────
  const lines = content.split('\n');
  const SECTION_KEYWORDS = [
    'PROFESSIONAL SUMMARY', 'SUMMARY', 'OBJECTIVE', 'PROFILE',
    'SKILLS', 'TECHNICAL SKILLS', 'CORE COMPETENCIES', 'KEY SKILLS',
    'PROFESSIONAL EXPERIENCE', 'WORK EXPERIENCE', 'EXPERIENCE',
    'EMPLOYMENT', 'CAREER HISTORY',
    'EDUCATION', 'ACADEMIC BACKGROUND',
    'CERTIFICATIONS', 'LICENSES', 'CREDENTIALS',
    'PROJECTS', 'KEY PROJECTS', 'PORTFOLIO',
    'AWARDS', 'ACHIEVEMENTS', 'HONORS',
    'VOLUNTEERING', 'VOLUNTEER EXPERIENCE',
    'LANGUAGES', 'PUBLICATIONS', 'REFERENCES',
  ];

  const isSectionHeader = (line) => {
    const upper = line.trim().toUpperCase();
    return SECTION_KEYWORDS.some(k => upper === k || upper.startsWith(k + ':'));
  };

  let headerLines = [];
  let isHeader = true;
  let sections = [];
  let current = null;

  for (const line of lines) {
    if (line.trim() === '---') continue;
    if (isHeader && !isSectionHeader(line)) {
      headerLines.push(line);
      continue;
    }
    if (isSectionHeader(line)) {
      isHeader = false;
      if (current) sections.push(current);
      current = { title: line.trim().toUpperCase(), lines: [] };
    } else {
      if (!current) { isHeader = false; current = { title: '', lines: [] }; }
      current.lines.push(line);
    }
  }
  if (current) sections.push(current);

  const resumeSections = sections.filter(s =>
    !s.title.includes('MISSING INFO') && !s.title.includes('SUGGESTIONS TO STRENGTHEN')
  );

  const isSkillSection = (t) => ['SKILLS', 'TECHNICAL SKILLS', 'CORE COMPETENCIES', 'KEY SKILLS'].some(k => t.includes(k));
  const isSummarySection = (t) => ['SUMMARY', 'PROFESSIONAL SUMMARY', 'OBJECTIVE', 'PROFILE'].some(k => t.includes(k));
  const isExperienceSection = (t) => ['EXPERIENCE', 'EMPLOYMENT', 'CAREER HISTORY'].some(k => t.includes(k));
  const isEducationSection = (t) => t.includes('EDUCATION') || t.includes('ACADEMIC');

  // Separate sidebar sections from main for two-column layouts
  const sidebarSections = resumeSections.filter(s =>
    isSkillSection(s.title) || isEducationSection(s.title) || s.title.includes('CERTIFICATIONS') || s.title.includes('LANGUAGES')
  );
  const mainSections = resumeSections.filter(s =>
    !isSkillSection(s.title) && !isEducationSection(s.title) && !s.title.includes('CERTIFICATIONS') && !s.title.includes('LANGUAGES')
  );

  // ─── Line renderers ─────────────────────────────────────────────────────────
  const renderLine = (line, li, bulletStyle = '▸', theme) => {
    const trimmed = line.trim();
    if (!trimmed) return <div key={li} style={{ height: '5px' }} />;
    if (trimmed.startsWith('>>')) return (
      <p key={li} style={{ fontSize: '10px', color: '#f59e0b', fontStyle: 'italic', margin: '3px 0' }}>{trimmed}</p>
    );
    if (trimmed.startsWith('- [ ]')) return (
      <p key={li} style={{ fontSize: '11px', margin: '2px 0', paddingLeft: '6px' }}>☐ {trimmed.slice(5)}</p>
    );
    if (trimmed.startsWith('- ')) return (
      <div key={li} style={{ display: 'flex', gap: '8px', marginBottom: '3px', paddingLeft: '6px', alignItems: 'flex-start' }}>
        <span style={{ color: theme.accent, flexShrink: 0, marginTop: '1px', fontWeight: 'bold', fontSize: '11px' }}>{bulletStyle}</span>
        <span style={{ fontSize: '11px', lineHeight: '1.55' }}>{trimmed.slice(2)}</span>
      </div>
    );
    if (trimmed.includes('|') && trimmed.split('|').length >= 2) return (
      <p key={li} style={{ fontSize: '12px', fontWeight: '700', margin: '8px 0 2px', color: theme.accent }}>{trimmed}</p>
    );
    return <p key={li} style={{ fontSize: '11px', margin: '2px 0', lineHeight: '1.55' }}>{trimmed}</p>;
  };

  const renderSection = (section, si, overrides = {}) => {
    const {
      bulletStyle = '▸',
      sectionHeaderStyle = {},
      skipBorderBottom = false,
    } = overrides;

    return (
      <div key={si} style={{ marginBottom: '16px' }}>
        {section.title && (
          <div style={{
            color: theme.sectionColor,
            fontWeight: '700',
            fontSize: '10.5px',
            textTransform: 'uppercase',
            letterSpacing: '1.8px',
            borderBottom: skipBorderBottom ? 'none' : `1.5px solid ${theme.borderColor}`,
            paddingBottom: skipBorderBottom ? '0' : '4px',
            marginBottom: '8px',
            ...sectionHeaderStyle,
          }}>
            {section.title}
          </div>
        )}
        {section.lines.map((line, li) => renderLine(line, li, bulletStyle, theme))}
      </div>
    );
  };

  // ─── Header renderers ────────────────────────────────────────────────────────
  const renderHeader = () => {
    const name = headerLines.find(l => l.trim())?.trim() || '';
    const contactLines = headerLines.filter(l => l.trim() && l.trim() !== name);

    const hl = template.layout || 'single';

    if (hl === 'left-sidebar' || hl === 'right-sidebar') {
      // Name only in the sidebar header strip
      return (
        <div style={{
          backgroundColor: theme.headerBg,
          color: theme.headerText,
          padding: '20px 24px',
          marginBottom: '0',
        }}>
          <p style={{ fontWeight: '900', fontSize: '22px', margin: '0 0 4px', letterSpacing: '0.5px', fontFamily: theme.font }}>
            {name}
          </p>
          {contactLines.map((l, i) => (
            <p key={i} style={{ fontSize: '10.5px', margin: '1px 0', opacity: 0.85 }}>{l.trim()}</p>
          ))}
        </div>
      );
    }

    if (hl === 'centered') {
      return (
        <div style={{
          textAlign: 'center',
          backgroundColor: theme.headerBg,
          color: theme.headerText,
          padding: '28px 32px',
          marginBottom: '20px',
          borderBottom: `3px solid ${theme.accent}`,
        }}>
          <p style={{ fontWeight: '900', fontSize: '26px', margin: '0 0 6px', letterSpacing: '2px', textTransform: 'uppercase' }}>
            {name}
          </p>
          {contactLines.map((l, i) => (
            <p key={i} style={{ fontSize: '11px', margin: '2px 0', opacity: 0.85 }}>{l.trim()}</p>
          ))}
        </div>
      );
    }

    if (hl === 'minimal-line') {
      return (
        <div style={{ padding: '0 0 16px 0', borderBottom: `2px solid ${theme.accent}`, marginBottom: '18px' }}>
          <p style={{ fontWeight: '800', fontSize: '24px', margin: '0 0 4px', color: theme.text, letterSpacing: '0.5px' }}>
            {name}
          </p>
          {contactLines.map((l, i) => (
            <p key={i} style={{ fontSize: '10.5px', margin: '1px 0', color: theme.sectionColor }}>{l.trim()}</p>
          ))}
        </div>
      );
    }

    if (hl === 'bold-accent') {
      return (
        <div style={{
          backgroundColor: theme.headerBg,
          color: theme.headerText,
          padding: '24px 28px',
          marginBottom: '0',
          borderLeft: `6px solid ${theme.accent}`,
        }}>
          <p style={{ fontWeight: '900', fontSize: '22px', margin: '0 0 6px', letterSpacing: '1px' }}>{name}</p>
          {contactLines.map((l, i) => (
            <p key={i} style={{ fontSize: '10.5px', margin: '1px 0', opacity: 0.85 }}>{l.trim()}</p>
          ))}
        </div>
      );
    }

    // Default: top banner
    return (
      <div style={{
        backgroundColor: theme.headerBg,
        color: theme.headerText,
        padding: '20px 24px',
        marginBottom: '20px',
        borderRadius: theme.headerBg === theme.bg ? '0' : '6px',
        borderBottom: theme.headerBg === theme.bg ? `2px solid ${theme.accent}` : 'none',
      }}>
        <p style={{ fontWeight: '800', fontSize: '20px', margin: '0 0 4px', letterSpacing: '0.5px' }}>{name}</p>
        {contactLines.map((l, i) => (
          <p key={i} style={{ fontSize: '10.5px', margin: '1px 0', opacity: theme.headerBg === theme.bg ? 0.7 : 0.85 }}>{l.trim()}</p>
        ))}
      </div>
    );
  };

  // ─── Layout renderers ─────────────────────────────────────────────────────
  const containerStyle = {
    backgroundColor: theme.bg,
    color: theme.text,
    fontFamily: theme.font,
    minHeight: '400px',
    borderRadius: '8px',
    overflow: 'hidden',
  };

  const tLayout = template.layout || 'single';

  // Two-column sidebar layout
  if (tLayout === 'left-sidebar' || tLayout === 'right-sidebar') {
    const sidebarBg = theme.sidebarBg || theme.headerBg;
    const sidebarText = theme.sidebarText || theme.headerText;

    const sidebar = (
      <div style={{
        width: '200px',
        minWidth: '200px',
        backgroundColor: sidebarBg,
        color: sidebarText,
        padding: '20px 16px',
      }}>
        {sidebarSections.map((s, si) => (
          <div key={si} style={{ marginBottom: '18px' }}>
            <div style={{
              fontWeight: '700', fontSize: '10px', textTransform: 'uppercase',
              letterSpacing: '1.5px', color: theme.accent, borderBottom: `1px solid ${theme.accent}40`,
              paddingBottom: '4px', marginBottom: '8px',
            }}>
              {s.title}
            </div>
            {s.lines.map((line, li) => {
              const t = line.trim();
              if (!t) return <div key={li} style={{ height: '4px' }} />;
              if (t.startsWith('- ')) return (
                <div key={li} style={{ fontSize: '10.5px', margin: '3px 0', paddingLeft: '4px', display: 'flex', gap: '6px', alignItems: 'flex-start' }}>
                  <span style={{ color: theme.accent, flexShrink: 0, fontWeight: 'bold' }}>•</span>
                  <span style={{ lineHeight: '1.5' }}>{t.slice(2)}</span>
                </div>
              );
              if (t.startsWith('>>')) return null;
              return <p key={li} style={{ fontSize: '10.5px', margin: '2px 0', lineHeight: '1.5' }}>{t}</p>;
            })}
          </div>
        ))}
      </div>
    );

    const main = (
      <div style={{ flex: 1, padding: '20px 20px' }}>
        {mainSections.map((s, si) => renderSection(s, si, { bulletStyle: '▸' }))}
      </div>
    );

    return (
      <div className={className} style={containerStyle}>
        {renderHeader()}
        <div style={{ display: 'flex', flexDirection: tLayout === 'right-sidebar' ? 'row-reverse' : 'row', minHeight: '300px' }}>
          {sidebar}
          {main}
        </div>
      </div>
    );
  }

  // Centered / elegant layout
  if (tLayout === 'centered') {
    return (
      <div className={className} style={{ ...containerStyle, padding: '0' }}>
        {renderHeader()}
        <div style={{ padding: '20px 32px' }}>
          {resumeSections.map((s, si) => renderSection(s, si, {
            bulletStyle: '◆',
            sectionHeaderStyle: { textAlign: 'center', borderBottom: 'none', borderTop: `1px solid ${theme.borderColor}`, paddingTop: '8px', paddingBottom: '4px' },
          }))}
        </div>
      </div>
    );
  }

  // Minimal-line layout
  if (tLayout === 'minimal-line') {
    return (
      <div className={className} style={{ ...containerStyle, padding: '28px 32px' }}>
        {renderHeader()}
        {resumeSections.map((s, si) => renderSection(s, si, {
          bulletStyle: '–',
          sectionHeaderStyle: { fontSize: '10px', letterSpacing: '2px', color: theme.sectionColor, borderBottom: 'none', paddingBottom: '2px' },
        }))}
      </div>
    );
  }

  // Bold-accent (left border stripe) layout
  if (tLayout === 'bold-accent') {
    return (
      <div className={className} style={{ ...containerStyle, padding: '0' }}>
        {renderHeader()}
        <div style={{ padding: '20px 24px' }}>
          {resumeSections.map((s, si) => renderSection(s, si, {
            bulletStyle: '●',
            sectionHeaderStyle: {
              borderLeft: `4px solid ${theme.accent}`,
              paddingLeft: '8px',
              borderBottom: 'none',
              fontSize: '11px',
            },
          }))}
        </div>
      </div>
    );
  }

  // Default single-column layout
  return (
    <div className={className} style={{ ...containerStyle, padding: '0' }}>
      {renderHeader()}
      <div style={{ padding: '12px 28px 28px' }}>
        {resumeSections.map((s, si) => renderSection(s, si))}
      </div>
    </div>
  );
}