import { useState } from 'react';
import { Sparkles, Briefcase, ArrowRight, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function SuggestedJobs({ profile, onGenerateForJob }) {
  const [jobs, setJobs] = useState(null);
  const [loading, setLoading] = useState(false);

  const getSuggestions = async () => {
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Based on this candidate profile, suggest 6 job titles they are well-qualified for:

Skills: ${profile?.skills || 'not specified'}
Experience: ${JSON.stringify(profile?.experience || [])}
Education: ${JSON.stringify(profile?.education || [])}
Summary: ${profile?.professional_summary || 'not written'}

For each job title return:
- title: the job title
- why: 1 sentence why they are a great fit
- skills_to_highlight: 2-3 key skills to emphasize
- avg_salary: estimated salary range (US)
- demand: "High" | "Medium" | "Growing"

Be realistic and specific. Match their actual background.`,
      response_json_schema: {
        type: 'object',
        properties: {
          jobs: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                why: { type: 'string' },
                skills_to_highlight: { type: 'array', items: { type: 'string' } },
                avg_salary: { type: 'string' },
                demand: { type: 'string' },
              },
            },
          },
        },
      },
    });
    setJobs(res?.jobs || []);
    setLoading(false);
  };

  const demandColor = (d) => {
    if (d === 'High') return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (d === 'Growing') return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-foreground">AI Job Suggestions</h3>
          <p className="text-xs text-muted-foreground">Jobs you may qualify for based on your background</p>
        </div>
        <Button onClick={getSuggestions} disabled={loading} size="sm" className="gap-2 shrink-0">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          {loading ? 'Analyzing...' : jobs ? 'Refresh' : 'Get Suggestions'}
        </Button>
      </div>

      {jobs === null && !loading && (
        <div className="rounded-xl border-2 border-dashed border-border p-8 text-center">
          <Briefcase className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-50" />
          <p className="text-sm text-muted-foreground">Click "Get Suggestions" to see jobs matched to your profile</p>
        </div>
      )}

      {jobs && jobs.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {jobs.map((job, i) => (
            <Card key={i} className="border-border hover:border-primary/40 transition-colors">
              <CardContent className="pt-4 pb-4 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <h4 className="font-semibold text-sm text-foreground leading-tight">{job.title}</h4>
                  <Badge className={`text-xs border shrink-0 ${demandColor(job.demand)}`}>{job.demand}</Badge>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{job.why}</p>
                {job.avg_salary && (
                  <p className="text-xs font-medium text-primary">{job.avg_salary}</p>
                )}
                {job.skills_to_highlight?.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {job.skills_to_highlight.map((s, si) => (
                      <span key={si} className="text-xs bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full">{s}</span>
                    ))}
                  </div>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full gap-1 text-xs h-8 border-primary/30 text-primary hover:bg-primary/10"
                  onClick={() => onGenerateForJob(job.title)}
                >
                  Generate Resume for This <ArrowRight className="w-3 h-3" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}