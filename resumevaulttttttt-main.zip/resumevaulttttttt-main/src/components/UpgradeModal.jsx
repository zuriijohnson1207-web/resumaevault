import { useState } from 'react';
import { X, Sparkles, CreditCard, Zap, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';

/**
 * Global upgrade modal. Accepts:
 *   open: boolean
 *   onClose: () => void
 *   reason: 'free_limit' | 'no_credits' | 'locked_template' | 'ats_report' | 'auto_apply' | 'cover_letter' | 'comparison'
 */

const COPY = {
  free_limit: {
    headline: "You've used your free resumes 🎯",
    message: "Upgrade now to keep building job-winning resumes, unlock premium templates, and get stronger ATS scores.",
    cta: "Don't let a weak resume block your bag.",
  },
  no_credits: {
    headline: "You're out of credits ⚡",
    message: "Buy more credits or upgrade your plan to keep going. You're so close — don't stop now.",
    cta: "Upgrade and keep applying like the main character.",
  },
  locked_template: {
    headline: "Premium Template Locked 🔒",
    message: "This premium template is locked. Upgrade to unlock better designs that get you noticed.",
    cta: "Stop sending basic resumes. Build one that actually matches the job.",
  },
  ats_report: {
    headline: "Unlock the Full ATS Report 📊",
    message: "Unlock the full ATS report to see your keyword match score, missing keywords, and improvement suggestions.",
    cta: "Your resume should not be getting ignored. Let's fix that.",
  },
  auto_apply: {
    headline: "Auto-Apply is a Premium Feature 🚀",
    message: "This feature is premium. Upgrade to apply smarter — let AI handle the applications while you prep for interviews.",
    cta: "Upgrade and apply like the main character.",
  },
  cover_letter: {
    headline: "Unlock AI Cover Letters ✉️",
    message: "Unlock AI cover letters that match your resume perfectly and are tailored to the job description.",
    cta: "Stop sending generic cover letters. Let AI write them for you.",
  },
  comparison: {
    headline: "Resume Comparison is Premium 🔍",
    message: "See exactly how your resume stacks up against the job description with side-by-side AI analysis.",
    cta: "You used your free features — now let's get serious.",
  },
};

export default function UpgradeModal({ open, onClose, reason = 'free_limit' }) {
  const [loadingKey, setLoadingKey] = useState(null);

  if (!open) return null;

  const copy = COPY[reason] || COPY.free_limit;

  const checkout = async (productKey) => {
    setLoadingKey(productKey);
    const res = await base44.functions.invoke('createCheckout', { product_key: productKey });
    if (res.data?.url) {
      window.location.href = res.data.url;
    } else {
      setLoadingKey(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-md p-6 z-10"
        onClick={e => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Icon */}
        <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center mx-auto mb-4">
          <Lock className="w-7 h-7 text-primary" />
        </div>

        {/* Copy */}
        <h2 className="text-xl font-bold text-foreground text-center mb-2">{copy.headline}</h2>
        <p className="text-sm text-muted-foreground text-center mb-1">{copy.message}</p>
        <p className="text-xs text-primary text-center italic mb-5">"{copy.cta}"</p>

        {/* Upgrade buttons */}
        <div className="space-y-2.5 mb-4">
          <Button
            className="w-full h-11 font-bold gap-2 shadow-lg shadow-primary/30"
            onClick={() => checkout('pro_monthly')}
            disabled={loadingKey === 'pro_monthly'}
          >
            {loadingKey === 'pro_monthly' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Upgrade to Pro — $29.99/mo
          </Button>
          <Button
            variant="outline"
            className="w-full h-11 font-semibold gap-2 border-primary/40 text-primary hover:bg-primary/10"
            onClick={() => checkout('credits_150')}
            disabled={loadingKey === 'credits_150'}
          >
            {loadingKey === 'credits_150' ? <Loader2 className="w-4 h-4 animate-spin" /> : <CreditCard className="w-4 h-4" />}
            Buy 150 Credits — $24.99
          </Button>
          <Button
            variant="ghost"
            className="w-full h-10 gap-2 text-muted-foreground hover:text-foreground"
            onClick={() => checkout('credits_50')}
            disabled={loadingKey === 'credits_50'}
          >
            {loadingKey === 'credits_50' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            Buy 50 Credits — $9.99
          </Button>
        </div>

        {/* View all plans */}
        <Link to="/pricing" onClick={onClose}>
          <p className="text-xs text-center text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2 cursor-pointer">
            View all plans & pricing →
          </p>
        </Link>

        {/* Maybe later */}
        <button
          onClick={onClose}
          className="block w-full text-center text-xs text-muted-foreground/60 hover:text-muted-foreground mt-3 transition-colors"
        >
          Maybe later
        </button>
      </div>
    </div>
  );
}