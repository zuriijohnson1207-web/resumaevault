import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { checkUserAccess, FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle2, Zap } from 'lucide-react';
import { toast } from 'sonner';

/**
 * DEVELOPMENT ONLY: Test unlock system
 * Tests all critical flows and shows results
 */

export default function UnlockSystemTester() {
  const { user } = useAuth();
  const [results, setResults] = useState([]);
  const [running, setRunning] = useState(false);

  const addLog = (name, success, message) => {
    setResults(prev => [...prev, { name, success, message, time: new Date().toLocaleTimeString() }]);
  };

  const testCreditUnlock = async () => {
    try {
      addLog('Test: Check Credits', null, 'Checking if credits were added...');

      // Get current profile
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      const profile = profiles[0];
      const credits = profile?.ai_credits || 0;

      if (credits > 0) {
        addLog('Test: Check Credits', true, `${credits} credits available`);
        
        // Check resume access
        const access = await checkUserAccess(user.email, 'resume');
        addLog('Test: Resume Access', access.canUse, `Reason: ${access.reason}`);
      } else {
        addLog('Test: Check Credits', false, 'No credits found');
      }
    } catch (e) {
      addLog('Test: Check Credits', false, e.message);
    }
  };

  const testSubscriptionUnlock = async () => {
    try {
      addLog('Test: Upgrade Plan', null, 'Running...');

      // Get current profile
      const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
      const profile = profiles[0];
      const oldPlan = profile.subscription_plan || 'free';

      // Call backend to upgrade
      const response = await base44.functions.invoke('upgradeSubscriptionAndSync', {
        userEmail: user.email,
        newPlan: oldPlan === 'free' ? 'pro' : 'free',
        reason: 'test_upgrade',
        adminEmail: user.email,
      });

      if (response.data?.success) {
        addLog('Test: Upgrade Plan', true, `${response.data.oldPlan} → ${response.data.newPlan}`);
        
        // Check multiple features
        const features = ['resume', 'job_analysis', 'mock_interview'];
        for (const feature of features) {
          const access = await checkUserAccess(user.email, feature);
          addLog(`Test: ${feature} After Upgrade`, access.canUse, `Reason: ${access.reason}`);
        }
      } else {
        addLog('Test: Upgrade Plan', false, response.data?.error || 'Unknown error');
      }
    } catch (e) {
      addLog('Test: Upgrade Plan', false, e.message);
    }
  };

  const testFeatureAccess = async () => {
    try {
      addLog('Test: All Features Access', null, 'Checking...');

      const features = Object.keys(FEATURE_DEFINITIONS);
      let unlocked = 0;
      let locked = 0;

      for (const feature of features.slice(0, 5)) {
        const access = await checkUserAccess(user.email, feature);
        if (access.canUse) unlocked++;
        else locked++;
      }

      addLog('Test: All Features Access', true, `${unlocked} unlocked, ${locked} locked`);
    } catch (e) {
      addLog('Test: All Features Access', false, e.message);
    }
  };

  const testSyncState = async () => {
    try {
      addLog('Test: Sync State', null, 'Running...');

      const response = await base44.functions.invoke('syncUnlockState', {});
      
      if (response.data?.success) {
        const { profile } = response.data;
        addLog('Test: Sync State', true, `Plan: ${profile.plan}, Credits: ${profile.credits}`);
      } else {
        addLog('Test: Sync State', false, response.data?.error || 'Unknown error');
      }
    } catch (e) {
      addLog('Test: Sync State', false, e.message);
    }
  };

  const runAllTests = async () => {
    setRunning(true);
    setResults([]);

    await testCreditUnlock();
    await new Promise(r => setTimeout(r, 500));

    await testSubscriptionUnlock();
    await new Promise(r => setTimeout(r, 500));

    await testFeatureAccess();
    await new Promise(r => setTimeout(r, 500));

    await testSyncState();

    setRunning(false);
    toast.success('All tests completed!');
  };

  return (
    <Card className="border-primary/30 bg-primary/5">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Zap className="w-4 h-4 text-primary" />
          Unlock System Tester
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-2">
          <Button onClick={testCreditUnlock} disabled={running} variant="outline" size="sm">
            Test Credits
          </Button>
          <Button onClick={testSubscriptionUnlock} disabled={running} variant="outline" size="sm">
            Test Plan
          </Button>
          <Button onClick={testFeatureAccess} disabled={running} variant="outline" size="sm">
            Test Features
          </Button>
          <Button onClick={testSyncState} disabled={running} variant="outline" size="sm">
            Test Sync
          </Button>
        </div>

        <Button onClick={runAllTests} disabled={running} className="w-full bg-primary text-primary-foreground">
          {running ? 'Running Tests...' : 'Run All Tests'}
        </Button>

        {results.length > 0 && (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {results.map((r, i) => (
              <div key={i} className="flex items-start gap-2 p-2 bg-card rounded-lg text-sm">
                {r.success === null ? (
                  <div className="w-4 h-4 rounded-full bg-yellow-500/50 shrink-0 mt-0.5" />
                ) : r.success ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.message}</div>
                  <div className="text-xs text-muted-foreground/50">{r.time}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="text-xs text-muted-foreground p-2 bg-card rounded-lg border border-border">
          <div className="font-semibold mb-1">User: {user?.email}</div>
          <div>Tests detect auto-added credits and validate access</div>
        </div>
      </CardContent>
    </Card>
  );
}