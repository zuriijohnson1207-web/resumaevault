import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

const DashboardStatsCard = React.memo(({ icon: Icon, label, value, color = 'text-primary' }) => {
  return (
    <Card className="border-border bg-card">
      <CardContent className="pt-6 flex flex-col items-center justify-center h-full">
        <Icon className={`w-6 h-6 ${color} mb-2`} />
        <div className="text-3xl font-bold">{value}</div>
        <div className="text-muted-foreground text-sm">{label}</div>
      </CardContent>
    </Card>
  );
});

DashboardStatsCard.displayName = 'DashboardStatsCard';

export default DashboardStatsCard;