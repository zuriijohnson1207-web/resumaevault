import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { AlertCircle, Zap, Star } from 'lucide-react';

export default function OverrideBadges({ userEmail }) {
  const [overrides, setOverrides] = useState([]);

  useEffect(() => {
    if (!userEmail) return;

    const loadOverrides = async () => {
      try {
        const active = await base44.entities.AdminOverride.filter({
          user_email: userEmail,
          is_active: true,
        });
        setOverrides(active);
      } catch (e) {
        console.error('Failed to load overrides:', e);
      }
    };

    loadOverrides();

    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email === userEmail && event.data?.is_active) {
        if (event.type === 'create' || event.type === 'update') {
          setOverrides(prev => {
            const filtered = prev.filter(o => o.id !== event.data.id);
            return [...filtered, event.data];
          });
        }
      }
    });

    return unsubscribe;
  }, [userEmail]);

  if (overrides.length === 0) return null;

  return (
    <div className="space-y-2 p-4 bg-purple-500/10 border border-purple-500/20 rounded-xl">
      <div className="flex items-center gap-2 text-sm font-bold text-purple-400">
        <Zap className="w-4 h-4" />
        Active Admin Overrides
      </div>
      <div className="space-y-1">
        {overrides.map(o => (
          <div key={o.id} className="flex items-center gap-2 text-sm">
            <Badge className="bg-purple-500/30 text-purple-300 text-xs">
              {o.override_type.replace(/_/g, ' ')}
            </Badge>
            {o.temporary_until && (
              <span className="text-xs text-muted-foreground">
                Expires {format(new Date(o.temporary_until), 'MMM d')}
              </span>
            )}
            {o.plan_granted && (
              <Badge className="bg-primary/20 text-primary text-xs">
                {o.plan_granted} plan
              </Badge>
            )}
            {o.credits_amount && (
              <Badge className="bg-yellow-500/20 text-yellow-300 text-xs">
                +{o.credits_amount} credits
              </Badge>
            )}
            {o.reason && (
              <span className="text-xs text-muted-foreground italic">
                ({o.reason})
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}