import { Link } from 'react-router-dom';
import { FileText, Upload, BookOpen, MessageCircle, CheckCircle2, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const STEPS = [
  { num: 1, title: 'Add your information', desc: 'Fill in your name, skills, and work history so AI can build your resume.' },
  { num: 2, title: 'Paste the job description', desc: 'Copy and paste the job posting so AI tailors your resume to that job.' },
  { num: 3, title: 'Choose a resume style', desc: 'Pick a template that fits your field — modern, classic, creative, and more.' },
  { num: 4, title: 'Generate your resume', desc: 'Click the big button and AI writes your resume in about 20 seconds.' },
  { num: 5, title: 'Check your ATS score', desc: 'See how well your resume matches the job. Fix any gaps shown.' },
  { num: 6, title: 'Download as PDF or Word', desc: 'Save your resume and apply for the job right away.' },
];

export default function GetStartedGuide({ onAskZu }) {
  return (
    <Card className="mb-6 border-primary/30 bg-gradient-to-br from-card to-primary/5">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-xl">
          🚀 How to Get Started
        </CardTitle>
        <p className="text-sm text-muted-foreground">Follow these 6 simple steps to create your first resume. <span className="text-primary font-semibold">Not sure where to start? Click "Ask ZU" below!</span></p>
      </CardHeader>
      <CardContent>
        {/* Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
          {STEPS.map((step, i) => (
            <div key={step.num} className="flex items-start gap-3 p-3 rounded-xl bg-secondary/40 border border-border">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm shrink-0">
                {step.num}
              </div>
              <div>
                <p className="font-bold text-sm text-foreground leading-tight">{step.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Action buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Link to="/resume-builder">
            <Button className="w-full h-13 text-base font-bold gap-2 shadow-lg shadow-primary/20 py-3">
              <FileText className="w-5 h-5" />
              Start My Resume
            </Button>
          </Link>
          <Link to="/resume-builder?tab=upload">
            <Button variant="outline" className="w-full h-13 text-base font-bold gap-2 py-3 border-primary/40 hover:border-primary">
              <Upload className="w-5 h-5" />
              Upload Old Resume
            </Button>
          </Link>
          <Link to="/resume-library">
            <Button variant="outline" className="w-full h-13 text-base font-bold gap-2 py-3">
              <BookOpen className="w-5 h-5" />
              View My Resume Library
            </Button>
          </Link>
          <button onClick={onAskZu}
            className="w-full h-13 flex items-center justify-center gap-2 py-3 rounded-lg border border-primary/40 bg-primary/10 hover:bg-primary/20 text-primary font-bold text-base transition-all">
            <span className="text-lg">✨</span>
            Ask ZU for Help
          </button>
        </div>

        <p className="text-xs text-muted-foreground text-center mt-4">
          💡 Not sure which button to click? Click <span className="text-primary font-semibold">Ask ZU for Help</span> and type your question — ZU will guide you step by step.
        </p>
      </CardContent>
    </Card>
  );
}