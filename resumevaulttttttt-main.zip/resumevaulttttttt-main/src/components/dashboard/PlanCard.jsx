import React from 'react';
import { Crown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const PlanCard = React.memo(({ plan, credits }) => {
  const getPlanColor = (p) => {
    if (p === 'elite') return 'from-card to-purple-500/5 border-purple-500/30';
    if (p === 'pro') return 'from-card to-primary/5 border-primary/30';
    return 'from-card to-card border-border';
  };

  const getPlanBadgeClass = (p) => {
    if (p === 'elite') return 'bg-purple-600 text-white';
    if (p === 'pro') return 'bg-primary text-primary-foreground';
    return 'bg-secondary text-white';
  };

  const planDescriptions = {
    free: 'Upgrade for unlimited AI power — 80 resumes, cover letters & premium tools.',
    pro: 'You have full Pro access. Consider Elite for unlimited everything.',
    elite: '🎉 You have full Elite access — enjoy all features!',
  };

  return (
    <Card className={`mb-6 border-primary/30 bg-gradient-to-r ${getPlanColor(plan)}`}>
      <CardContent className="pt-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-primary" />
            <span className="font-bold text-white text-base">Your Plan</span>
          </div>
          <Badge className={`capitalize font-bold text-sm px-3 py-1 ${getPlanBadgeClass(plan)}`}>
            {plan}
          </Badge>
        </div>
        <div className="text-sm text-white font-medium mb-1">
          {plan === 'free' && '✓ 2 AI resumes/mo  ✓ 2 cover letters/mo  ✓ 2 job analyses/mo'}
          {plan === 'pro' && '✓ 80 AI resumes/mo  ✓ Unlimited cover letters  ✓ 20 mock interviews  ✓ 50 auto-applies/mo'}
          {plan === 'elite' && '✓ 150 AI resumes/mo  ✓ Unlimited everything  ✓ Career coaching  ✓ 200 auto-applies/mo'}
        </div>
        <p className="text-xs text-white/70 mb-3">{planDescriptions[plan]}</p>
        {plan !== 'elite' && (
          <Link to="/pricing">
            <Button className={`w-full font-bold ${plan === 'pro' ? 'bg-purple-600 hover:bg-purple-700 text-white' : 'bg-primary text-primary-foreground'}`}>
              {plan === 'free' ? '↗ Upgrade to Pro — $29.99/mo' : '↗ Upgrade to Elite — $79.99/mo'}
            </Button>
          </Link>
        )}
      </CardContent>
    </Card>
  );
});

PlanCard.displayName = 'PlanCard';

export default PlanCard;