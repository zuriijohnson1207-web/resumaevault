import { useRealTimeAccess } from '@/hooks/useRealTimeAccess';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Lock, Zap, Crown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { FEATURE_DEFINITIONS } from '@/lib/checkUserAccess';

/**
 * Real-time feature gate with instant unlocking
 * Automatically shows/hides content based on access
 * Updates instantly when credits/subscription changes
 */
export default function RealTimeFeatureGate({ 
  feature, 
  children, 
  fallback = null,
  showMessage = true 
}) {
  const { user } = useAuth();
  const { access, loading } = useRealTimeAccess(feature);
  const featureDef = FEATURE_DEFINITIONS[feature];

  if (loading) {
    return fallback || (
      <div className="p-4 text-center text-muted-foreground text-sm">
        Loading access...
      </div>
    );
  }

  if (!access.canUse) {
    if (!showMessage) return null;

    const messages = {
      admin_lock: 'This feature is currently locked by an admin.',
      locked: `Requires ${featureDef?.creditCost || 0} credits.`,
      plan_monthly_limit: 'Monthly limit reached. Upgrade to use more.',
      error: 'Error checking access. Try again.',
    };

    return (
      <div className="p-4 bg-secondary/30 border border-border rounded-lg text-center space-y-3">
        <div className="flex items-center justify-center gap-2 text-muted-foreground">
          <Lock className="w-4 h-4" />
          <span className="text-sm font-medium">{messages[access.reason] || 'Feature locked'}</span>
        </div>
        <div className="flex gap-2 justify-center flex-wrap">
          <Link to="/pricing">
            <Button size="sm" className="gap-1">
              <Crown className="w-3 h-3" /> Upgrade Plan
            </Button>
          </Link>
          {access.creditsNeeded > 0 && (
            <Link to="/profile?tab=account">
              <Button size="sm" variant="outline" className="gap-1">
                <Zap className="w-3 h-3" /> Buy {access.creditsNeeded} Credits
              </Button>
            </Link>
          )}
        </div>
      </div>
    );
  }

  // Feature is unlocked
  return children;
}