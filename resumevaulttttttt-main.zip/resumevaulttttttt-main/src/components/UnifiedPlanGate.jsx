import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Crown, Lock, Zap, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUnifiedAccess, UNIFIED_FEATURES } from '@/hooks/useUnifiedAccess';
import { useAuth } from '@/lib/AuthContext';
import UpgradeModal from '@/components/UpgradeModal';

/**
 * UNIFIED PLAN GATE — Single source of truth for feature access
 * Replaces PlanGate.jsx — this version uses checkAccess() for all features
 */
export default function UnifiedPlanGate({ feature, children, hasOverride = false }) {
  const { user } = useAuth();
  const { profile, checkAccess, getUsageInfo, loading } = useUnifiedAccess();
  const [showModal, setShowModal] = useState(false);

  // Admins always get full access
  if (user?.role === 'admin') return <>{children}</>;

  if (loading) {
    return (
      <div className="rounded-lg border border-border bg-card/50 p-4 flex items-center gap-3">
        <div className="w-4 h-4 border-2 border-muted border-t-primary rounded-full animate-spin" />
        <span className="text-sm text-muted-foreground">Loading access info...</span>
      </div>
    );
  }

  // Show override badge
  if (hasOverride) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2">
          <AlertCircle className="w-3 h-3 text-purple-400 shrink-0" />
          <span className="text-purple-300 font-semibold">Admin Override Active</span>
          <span className="text-muted-foreground">— this feature is unlocked by admin</span>
        </div>
        {children}
      </div>
    );
  }

  const access = checkAccess(feature);
  const usage = getUsageInfo(feature);
  const featureDef = UNIFIED_FEATURES[feature];

  if (!featureDef) {
    return <div className="text-sm text-destructive">Unknown feature: {feature}</div>;
  }

  // Feature is accessible — show usage info if applicable
  if (access.canUse) {
    if (access.reason === 'credit_purchase') {
      return (
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs bg-primary/10 border border-primary/30 rounded-lg px-3 py-2">
            <Zap className="w-3 h-3 text-primary shrink-0" />
            <span className="text-primary font-semibold">Using {access.creditsNeeded} credits</span>
            <span className="text-muted-foreground">— {profile?.ai_credits || 0} available</span>
          </div>
          {children}
        </div>
      );
    }

    if (access.reason === 'temporary_access') {
      return (
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs bg-orange-500/10 border border-orange-500/30 rounded-lg px-3 py-2">
            <Zap className="w-3 h-3 text-orange-400 shrink-0" />
            <span className="text-orange-300 font-semibold">Temporary Access</span>
            <span className="text-muted-foreground">— expires soon</span>
          </div>
          {children}
        </div>
      );
    }

    // Plan-based access — show usage
    if (usage.limit !== Infinity && usage.limit > 0) {
      return (
        <div>
          <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
            <Zap className="w-3 h-3 text-primary" />
            <span>{usage.remaining} of {usage.limit} uses remaining this month</span>
          </div>
          {children}
        </div>
      );
    }

    return <>{children}</>;
  }

  // Feature is LOCKED
  if (access.reason === 'admin_lock') {
    return (
      <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5 text-center">
        <Lock className="w-7 h-7 text-destructive mx-auto mb-2" />
        <h3 className="font-bold text-foreground text-base mb-1">{featureDef.label} — Locked</h3>
        <p className="text-sm text-muted-foreground mb-3">This feature has been locked by an administrator.</p>
      </div>
    );
  }

  // Feature requires plan upgrade OR credits
  return (
    <>
      <UpgradeModal open={showModal} onClose={() => setShowModal(false)} reason="feature_locked" />
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6 text-center">
        <Lock className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-bold text-foreground text-base mb-1">{featureDef.label}</h3>
        <p className="text-sm text-muted-foreground mb-2">
          {access.reason === 'no_profile'
            ? 'Complete your profile to unlock features.'
            : `Upgrade your plan or buy ${access.creditsNeeded} credits to use this feature.`}
        </p>
        <p className="text-xs text-muted-foreground mb-4">
          Cost: {access.creditsNeeded} credits · You have {profile?.ai_credits || 0} credits
        </p>
        <div className="flex gap-2 justify-center flex-wrap">
          <Button className="bg-primary text-primary-foreground gap-2" onClick={() => setShowModal(true)}>
            <Crown className="w-4 h-4" /> Upgrade Now
          </Button>
          <Link to="/pricing">
            <Button variant="outline" className="gap-2 border-primary/40 text-primary">
              <Zap className="w-4 h-4" /> Buy Credits
            </Button>
          </Link>
        </div>
      </div>
    </>
  );
}