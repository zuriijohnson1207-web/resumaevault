import { useState, useEffect } from 'react';
import { X, Send, RefreshCw, ChevronDown, MessageCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import DraggableFloat from '@/components/DraggableFloat';
import { cn } from '@/lib/utils';

const STORAGE_POS = 'ai_float_pos';

const QUICK_PROMPTS = [
  { label: '📄 Resume Help', msg: 'Help me write a better resume' },
  { label: '🔍 Job Description', msg: 'How do I analyze a job description?' },
  { label: '🎯 ATS Score', msg: 'What is an ATS score and how do I improve it?' },
  { label: '🎨 Templates', msg: 'Which resume template should I choose?' },
  { label: '💳 Account/Payment', msg: 'How do credits and plans work?' },
  { label: '🚀 Get Started', msg: 'How do I get started building my resume?' },
];

export default function FloatingAIAssistant() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [profileName, setProfileName] = useState(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.UserProfile.filter({ created_by: user.email }).then(p => {
      if (p[0]?.full_name) setProfileName(p[0].full_name);
    }).catch(() => {});
  }, [user?.email]);

  // Listen for external "open ZU" events (e.g. from dashboard guide)
  useEffect(() => {
    const handler = () => handleOpen();
    window.addEventListener('open-zu-chat', handler);
    return () => window.removeEventListener('open-zu-chat', handler);
  }, []);

  const firstName = profileName?.split(' ')[0] || 'friend';

  const greet = async () => {
    if (initialized) return;
    setInitialized(true);
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are ZU, a warm and helpful AI career coach for ResumeVault. Greet ${firstName} in 2 short, friendly sentences. Tell them they can ask about resumes, job descriptions, ATS scores, templates, or account help. Be upbeat and welcoming. No more than 3 sentences total.`,
    });
    setMessages([{ role: 'assistant', text: res || `Hey ${firstName}! 👋 I'm ZU — ask me anything about resumes, job searching, or ATS scores!` }]);
    setLoading(false);
  };

  const handleOpen = () => {
    setOpen(true);
    setMinimized(false);
    greet();
  };

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', text: msg }]);
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are ZU, a warm and helpful AI career coach for ResumeVault. The user's name is ${firstName}. Help with: resumes, job descriptions, ATS scores, resume templates, account/payment questions, or general career advice. Keep answers short and friendly (2-4 sentences). User said: "${msg}"`,
    });
    setMessages(m => [...m, { role: 'assistant', text: res || "I'm here to help! 💪" }]);
    setLoading(false);
  };

  const reset = () => { setMessages([]); setInitialized(false); greet(); };

  return (
    <DraggableFloat storageKey={STORAGE_POS} defaultPos={{ x: 16, y: 100 }}>
      <div className="select-none">
        {/* Closed state — pill trigger button */}
        {!open && (
          <button
            data-drag-handle
            onClick={handleOpen}
            aria-label="Open ZU AI Assistant chat"
            title="Chat with ZU — drag to move"
            className={cn(
              'flex items-center gap-2 px-4 py-2.5 rounded-full shadow-xl border border-primary/40',
              'bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-bold text-sm',
              'hover:shadow-primary/40 active:scale-95 transition-all cursor-grab active:cursor-grabbing'
            )}
          >
            <span className="text-base">✨</span>
            <span className="hidden sm:inline">Ask ZU</span>
            <span className="sm:hidden text-xs">ZU</span>
          </button>
        )}

        {/* Open state — chat panel */}
        {open && (
          <div className="w-80 max-w-[calc(100vw-2rem)] bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col">
            {/* Header — also acts as drag handle */}
            <div
              data-drag-handle
              className="bg-gradient-to-r from-primary to-primary/80 px-4 py-3 flex items-center justify-between shrink-0 cursor-grab active:cursor-grabbing"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
                  <span className="text-sm">✨</span>
                </div>
                <div>
                  <p className="font-bold text-primary-foreground text-sm leading-tight">ZU — Career Bestie</p>
                  <p className="text-primary-foreground/70 text-xs">Drag me anywhere · ask me anything</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={reset} aria-label="New conversation"
                  className="text-primary-foreground/60 hover:text-primary-foreground transition-colors" title="Start over">
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => setMinimized(v => !v)} aria-label={minimized ? 'Expand chat' : 'Minimize chat'}
                  className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-primary-foreground transition-colors">
                  <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', !minimized && 'rotate-180')} />
                </button>
                <button onClick={() => setOpen(false)} aria-label="Close chat"
                  className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-primary-foreground transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {!minimized && (
              <>
                {/* Quick prompts */}
                {messages.length <= 1 && (
                  <div className="px-3 pt-3 pb-1 border-b border-border bg-secondary/20">
                    <p className="text-xs text-muted-foreground mb-2 font-semibold">Quick questions:</p>
                    <div className="flex flex-wrap gap-1.5 pb-2">
                      {QUICK_PROMPTS.map(q => (
                        <button key={q.label} onClick={() => send(q.msg)}
                          disabled={loading}
                          className="text-xs px-2.5 py-1.5 rounded-full bg-secondary hover:bg-primary hover:text-primary-foreground border border-border hover:border-primary transition-all font-medium disabled:opacity-50">
                          {q.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Messages */}
                <div className="flex-1 p-3 space-y-2.5 overflow-y-auto max-h-64 min-h-[6rem]">
                  {messages.length === 0 && !loading && (
                    <p className="text-xs text-muted-foreground text-center py-4">
                      Pick a topic above or type your question below 👇
                    </p>
                  )}
                  {messages.map((m, i) => (
                    <div key={i} className={cn(
                      'text-xs rounded-xl px-3 py-2.5 max-w-[90%] leading-relaxed',
                      m.role === 'user'
                        ? 'bg-primary text-primary-foreground ml-auto rounded-br-sm'
                        : 'bg-secondary text-foreground rounded-bl-sm'
                    )}>
                      {m.text}
                    </div>
                  ))}
                  {loading && (
                    <div className="bg-secondary rounded-xl rounded-bl-sm px-3 py-2.5 w-16">
                      <div className="flex gap-1">
                        {[0, 150, 300].map(d => (
                          <div key={d} className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: `${d}ms` }} />
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Input */}
                <div className="p-2.5 border-t border-border flex gap-2 shrink-0 bg-card/50">
                  <input
                    className="flex-1 text-sm bg-input border border-border rounded-xl px-3 py-2.5 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                    placeholder="Ask ZU anything..."
                    aria-label="Type your message to ZU"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && send()}
                  />
                  <button onClick={() => send()} disabled={loading || !input.trim()}
                    aria-label="Send message"
                    className="w-10 h-10 bg-primary hover:bg-primary/90 disabled:opacity-40 text-primary-foreground rounded-xl flex items-center justify-center transition-all shrink-0">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </DraggableFloat>
  );
}