import { Link } from 'react-router-dom';
import { Zap, Crown } from 'lucide-react';
import { usePlanLimits, PLAN_LIMITS, FEATURE_LABELS } from '@/hooks/usePlanLimits';

export default function CreditBar() {
  const { profile, plan, getUsage, loading } = usePlanLimits();

  if (loading || !profile) return null;

  const credits = profile?.ai_credits ?? 0;
  const isEmpty = credits === 0;
  const isLow = credits > 0 && credits < 20;

  const features = ['resume', 'cover_letter', 'mock_interview', 'auto_apply'];
  const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;

  const planLabel = plan === 'elite' ? '⭐ Elite' : plan === 'pro' ? '✦ Pro' : 'Free';
  const planColor = plan === 'elite' ? 'text-purple-400' : plan === 'pro' ? 'text-primary' : 'text-muted-foreground';

  return (
    <div className="mx-3 mb-3 rounded-xl border border-border/50 bg-background/40 backdrop-blur-sm px-3 py-2.5 space-y-2">
      {/* Top row: credits + plan + buy link */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Zap className={`w-3.5 h-3.5 ${isEmpty ? 'text-red-400' : isLow ? 'text-yellow-400' : 'text-primary'}`} />
          <span className="text-sm font-semibold text-white">
            {credits}
            <span className="text-xs font-normal text-muted-foreground ml-1">credits</span>
          </span>
          <span className={`text-xs font-medium ${planColor} ml-1`}>{planLabel}</span>
        </div>
        <Link
          to="/pricing"
          className={`text-xs font-semibold px-2 py-0.5 rounded-full transition-colors ${
            isEmpty
              ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
              : 'bg-primary/15 text-primary hover:bg-primary/25'
          }`}
        >
          {isEmpty ? '⚠ Buy Credits' : isLow ? '+ Top Up' : '+ Credits'}
        </Link>
      </div>

      {/* Usage bars — compact */}
      <div className="space-y-1.5">
        {features.map(f => {
          const { used, limit } = getUsage(f);
          if (limit === 0) return null;
          const pct = limit === Infinity ? 0 : Math.min(100, (used / limit) * 100);
          const label = FEATURE_LABELS[f];
          return (
            <div key={f} className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground w-20 truncate shrink-0">{label}</span>
              <div className="flex-1 h-1 rounded-full bg-white/10 overflow-hidden">
                {limit !== Infinity && (
                  <div
                    className={`h-full rounded-full transition-all ${pct >= 100 ? 'bg-red-500' : pct >= 75 ? 'bg-yellow-500' : 'bg-primary'}`}
                    style={{ width: `${pct}%` }}
                  />
                )}
              </div>
              <span className="text-xs text-muted-foreground shrink-0 w-10 text-right">
                {limit === Infinity ? `${used}` : `${used}/${limit}`}
              </span>
            </div>
          );
        })}
      </div>

      {/* Upgrade nudge for free users only */}
      {plan === 'free' && (
        <Link to="/pricing" className="flex items-center gap-1.5 text-xs text-primary/80 hover:text-primary transition-colors">
          <Crown className="w-3 h-3 shrink-0" />
          <span>Upgrade for more uses →</span>
        </Link>
      )}
    </div>
  );
}