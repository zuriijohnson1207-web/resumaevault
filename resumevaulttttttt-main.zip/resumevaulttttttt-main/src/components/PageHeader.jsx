export default function PageHeader({ icon: Icon, title, subtitle, color = "text-primary" }) {
  return (
    <div className="flex items-center gap-4 mb-6">
      {Icon && (
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-primary/10 shrink-0`} aria-hidden="true">
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      )}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground leading-tight">{title}</h1>
        {subtitle && <p className="text-muted-foreground text-sm md:text-base mt-0.5">{subtitle}</p>}
      </div>
    </div>
  );
}