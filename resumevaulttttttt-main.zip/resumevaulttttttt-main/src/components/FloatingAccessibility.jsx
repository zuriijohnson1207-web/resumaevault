import { useState, useEffect } from 'react';
import { X, Type, Sun, Eye, Volume2, Zap, HelpCircle, ChevronDown } from 'lucide-react';
import DraggableFloat from '@/components/DraggableFloat';
import { cn } from '@/lib/utils';

const STORAGE_POS = 'a11y_float_pos';
const STORAGE_FONT = 'a11y_font_scale';
const STORAGE_HC = 'a11y_high_contrast';
const STORAGE_MOTION = 'a11y_reduce_motion';

export default function FloatingAccessibility() {
  const [open, setOpen] = useState(false);
  const [fontSize, setFontSize] = useState(() => {
    try { return parseFloat(localStorage.getItem(STORAGE_FONT)) || 100; } catch { return 100; }
  });
  const [highContrast, setHighContrast] = useState(() => {
    try { return localStorage.getItem(STORAGE_HC) === 'true'; } catch { return false; }
  });
  const [reduceMotion, setReduceMotion] = useState(() => {
    try { return localStorage.getItem(STORAGE_MOTION) === 'true'; } catch { return false; }
  });
  const [helpMode, setHelpMode] = useState(false);
  const [reading, setReading] = useState(false);

  // Apply settings to DOM
  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
    localStorage.setItem(STORAGE_FONT, fontSize);
  }, [fontSize]);

  useEffect(() => {
    document.documentElement.classList.toggle('high-contrast', highContrast);
    localStorage.setItem(STORAGE_HC, highContrast);
  }, [highContrast]);

  useEffect(() => {
    document.documentElement.classList.toggle('reduce-motion', reduceMotion);
    localStorage.setItem(STORAGE_MOTION, reduceMotion);
    if (reduceMotion) {
      const style = document.getElementById('reduce-motion-style') || document.createElement('style');
      style.id = 'reduce-motion-style';
      style.textContent = `*, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }`;
      document.head.appendChild(style);
    } else {
      document.getElementById('reduce-motion-style')?.remove();
    }
  }, [reduceMotion]);

  useEffect(() => {
    if (helpMode) {
      document.body.setAttribute('data-help-mode', 'true');
    } else {
      document.body.removeAttribute('data-help-mode');
    }
  }, [helpMode]);

  const readPage = () => {
    if (reading) {
      window.speechSynthesis.cancel();
      setReading(false);
      return;
    }
    const text = document.getElementById('main-content')?.innerText || document.body.innerText;
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 3000));
    utterance.rate = 0.9;
    utterance.onend = () => setReading(false);
    window.speechSynthesis.speak(utterance);
    setReading(true);
  };

  const btnBase = 'flex items-center gap-2 w-full px-3 py-2.5 rounded-lg text-sm font-semibold transition-all text-left';
  const active = 'bg-primary text-primary-foreground';
  const inactive = 'bg-secondary/50 text-foreground hover:bg-secondary';

  return (
    <DraggableFloat storageKey={STORAGE_POS} defaultPos={{ x: 16, y: 260 }}>
      <div className="select-none">
        {/* Drag handle / trigger button */}
        <button
          data-drag-handle
          onClick={() => setOpen(o => !o)}
          aria-label="Accessibility options"
          title="Accessibility Tools — drag to move"
          className={cn(
            'flex items-center gap-2 px-3 py-2.5 rounded-2xl shadow-xl border border-border',
            'bg-card text-foreground font-bold text-sm',
            'hover:border-primary/60 transition-all active:scale-95',
            'cursor-grab active:cursor-grabbing'
          )}
        >
          <span className="text-base">♿</span>
          <span className="hidden sm:inline text-xs">Accessibility</span>
          <ChevronDown className={cn('w-3 h-3 transition-transform', open && 'rotate-180')} />
        </button>

        {/* Panel */}
        {open && (
          <div className="mt-2 w-64 bg-card border border-border rounded-2xl shadow-2xl overflow-hidden">
            {/* Header */}
            <div
              data-drag-handle
              className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-primary/20 to-primary/5 border-b border-border cursor-grab active:cursor-grabbing"
            >
              <div className="flex items-center gap-2">
                <span className="text-base">♿</span>
                <span className="font-bold text-sm text-foreground">Accessibility</span>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close accessibility panel"
                className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-3 space-y-1.5">
              {/* Font size */}
              <div className="flex items-center gap-1.5 mb-2">
                <Type className="w-4 h-4 text-primary shrink-0" />
                <span className="text-xs font-semibold text-muted-foreground flex-1">Text Size</span>
                <div className="flex gap-1">
                  <button onClick={() => setFontSize(f => Math.max(80, f - 10))}
                    aria-label="Make text smaller"
                    className="w-8 h-8 rounded-lg bg-secondary hover:bg-secondary/70 font-bold text-lg flex items-center justify-center">A</button>
                  <button onClick={() => setFontSize(100)}
                    aria-label="Reset text size"
                    className="px-2 h-8 rounded-lg bg-secondary hover:bg-secondary/70 text-xs font-semibold">{fontSize}%</button>
                  <button onClick={() => setFontSize(f => Math.min(150, f + 10))}
                    aria-label="Make text bigger"
                    className="w-8 h-8 rounded-lg bg-secondary hover:bg-secondary/70 font-bold text-xl flex items-center justify-center">A</button>
                </div>
              </div>

              {/* High contrast */}
              <button onClick={() => setHighContrast(v => !v)}
                className={cn(btnBase, highContrast ? active : inactive)}
                aria-pressed={highContrast}>
                <Sun className="w-4 h-4 shrink-0" />
                High Contrast Mode
                {highContrast && <span className="ml-auto text-xs">ON</span>}
              </button>

              {/* Reduce motion */}
              <button onClick={() => setReduceMotion(v => !v)}
                className={cn(btnBase, reduceMotion ? active : inactive)}
                aria-pressed={reduceMotion}>
                <Zap className="w-4 h-4 shrink-0" />
                Reduce Motion
                {reduceMotion && <span className="ml-auto text-xs">ON</span>}
              </button>

              {/* Read instructions */}
              <button onClick={readPage}
                className={cn(btnBase, reading ? active : inactive)}
                aria-label={reading ? 'Stop reading page aloud' : 'Read page instructions aloud'}>
                <Volume2 className="w-4 h-4 shrink-0" />
                {reading ? 'Stop Reading' : 'Read Page Aloud'}
              </button>

              {/* Help mode */}
              <button onClick={() => setHelpMode(v => !v)}
                className={cn(btnBase, helpMode ? active : inactive)}
                aria-pressed={helpMode}>
                <HelpCircle className="w-4 h-4 shrink-0" />
                Help Mode
                {helpMode && <span className="ml-auto text-xs">ON</span>}
              </button>

              {helpMode && (
                <div className="mt-2 p-3 bg-primary/10 border border-primary/30 rounded-xl text-xs text-primary leading-relaxed">
                  💡 <strong>Help Mode is ON.</strong> Hover over buttons and icons to see what they do. Labels will appear everywhere.
                </div>
              )}

              <div className="pt-2 border-t border-border">
                <p className="text-xs text-muted-foreground text-center">Drag the ♿ button to move this panel</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </DraggableFloat>
  );
}