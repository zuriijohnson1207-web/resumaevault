import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Bot, RefreshCw } from 'lucide-react';

export default function ZUGreeting({ user, profile }) {
  const [greeting, setGreeting] = useState('');
  const [loading, setLoading] = useState(false);

  // Only use the name the user explicitly set in their profile — never fall back to auth name
  const firstName = profile?.full_name?.split(' ')[0] || null;
  const jobTitle = profile?.experience?.[0]?.job_title || null;

  const fetchGreeting = async () => {
    setLoading(true);
    const context = jobTitle ? `They are a ${jobTitle} looking for their next role.` : 'They are actively job searching.';
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are ZU, a spunky, positive AI career coach for ResumevaultGodAI. Write a short personalized greeting for ${firstName}. ${context} Give them 2 energetic, motivating sentences about their job search. Be warm, punchy, and encouraging. No more than 2-3 sentences total. Don't use hashtags. Address them only as "${firstName}".`,
    });
    setGreeting(res || `Hey ${firstName}! You're one application away from changing everything — let's make today count! 💪`);
    setLoading(false);
  };

  // Only generate greeting once we have the user's actual name from their profile
  useEffect(() => {
    if (firstName) fetchGreeting();
  }, [firstName]);

  if (!greeting && !loading) return null;

  return (
    <div className="bg-gradient-to-r from-primary/10 to-secondary border border-primary/20 rounded-xl px-4 py-4 mb-6 flex items-start gap-3">
      <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
        <Bot className="w-5 h-5 text-primary-foreground" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-bold text-primary uppercase tracking-wider">ZU — Your AI Career Bestie</span>
        </div>
        {loading ? (
          <div className="flex gap-1 items-center">
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        ) : (
          <p className="text-sm text-white leading-relaxed">{greeting}</p>
        )}
      </div>
      {!loading && (
        <button onClick={fetchGreeting} className="text-muted-foreground hover:text-primary transition-colors mt-1" title="Get a new message">
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
}