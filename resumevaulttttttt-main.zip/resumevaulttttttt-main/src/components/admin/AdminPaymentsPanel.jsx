import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { CreditCard, RefreshCw, CheckCircle2, XCircle, History, TrendingUp, DollarSign, Zap, Plus, Minus, Save } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function formatMoney(cents) {
  if (!cents) return '$0.00';
  return `$${(cents / 100).toFixed(2)}`;
}

export default function AdminPaymentsPanel({ profiles }) {
  const { toast } = useToast();
  const [payments, setPayments] = useState([]);
  const [creditHistory, setCreditHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('payments');
  const [adjusting, setAdjusting] = useState(null);
  const [adjustDelta, setAdjustDelta] = useState(0);
  const [adjustNote, setAdjustNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [filterEmail, setFilterEmail] = useState('');

  const load = async () => {
    setLoading(true);
    const [p, h] = await Promise.all([
      base44.entities.PaymentRecord.list('-created_date', 100),
      base44.entities.CreditHistory.list('-created_date', 200),
    ]);
    setPayments(p);
    setCreditHistory(h);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const totalRevenue = payments.filter(p => p.status === 'succeeded').reduce((s, p) => s + (p.amount_cents || 0), 0);
  const failedPayments = payments.filter(p => p.status === 'failed');
  const oneTimePayments = payments.filter(p => p.payment_type === 'one_time' && p.status === 'succeeded');
  const subscriptionPayments = payments.filter(p => p.payment_type === 'subscription' && p.status === 'succeeded');

  const adjustCredits = async (profileId, userEmail) => {
    if (!adjustDelta) { toast({ title: 'Enter a credit amount first.' }); return; }
    setSaving(true);
    const res = await base44.functions.invoke('adminCreditAdjust', {
      profile_id: profileId,
      credits_delta: Number(adjustDelta),
      notes: adjustNote || undefined,
      user_email: userEmail,
    });
    if (res.data?.success) {
      toast({ title: `✅ Credits adjusted! New balance: ${res.data.new_credits}` });
      setAdjusting(null);
      setAdjustDelta(0);
      setAdjustNote('');
      load();
    } else {
      toast({ title: `Error: ${res.data?.error || 'Failed'}`, variant: 'destructive' });
    }
    setSaving(false);
  };

  const filteredPayments = filterEmail
    ? payments.filter(p => p.user_email?.toLowerCase().includes(filterEmail.toLowerCase()))
    : payments;
  const filteredHistory = filterEmail
    ? creditHistory.filter(h => h.user_email?.toLowerCase().includes(filterEmail.toLowerCase()))
    : creditHistory;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardContent className="pt-4 pb-3 text-center">
            <div className="text-2xl font-bold text-green-400">{formatMoney(totalRevenue)}</div>
            <div className="text-xs text-muted-foreground">Total Revenue</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3 text-center">
            <div className="text-2xl font-bold text-primary">{subscriptionPayments.length}</div>
            <div className="text-xs text-muted-foreground">Subscriptions</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3 text-center">
            <div className="text-2xl font-bold text-blue-400">{oneTimePayments.length}</div>
            <div className="text-xs text-muted-foreground">Credit Purchases</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3 text-center">
            <div className="text-2xl font-bold text-red-400">{failedPayments.length}</div>
            <div className="text-xs text-muted-foreground">Failed Payments</div>
          </CardContent>
        </Card>
      </div>

      {/* Failed Payments Alert */}
      {failedPayments.length > 0 && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <XCircle className="w-4 h-4 text-red-400" />
            <span className="text-sm font-semibold text-red-400">{failedPayments.length} Failed Payment{failedPayments.length > 1 ? 's' : ''}</span>
          </div>
          <div className="space-y-1">
            {failedPayments.slice(0, 3).map(p => (
              <div key={p.id} className="text-xs text-red-300">• {p.user_email} — {formatMoney(p.amount_cents)} — {formatDate(p.created_date)}</div>
            ))}
          </div>
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-2">
        <Input
          placeholder="Filter by email..."
          value={filterEmail}
          onChange={e => setFilterEmail(e.target.value)}
          className="h-8 text-sm max-w-xs"
        />
        <Button size="sm" variant="outline" onClick={load} className="gap-1 h-8">
          <RefreshCw className="w-3 h-3" /> Refresh
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary/30 rounded-xl p-1">
        {[
          { id: 'payments', label: 'Payment History', icon: CreditCard },
          { id: 'credits', label: 'Credit History', icon: History },
          { id: 'adjust', label: 'Adjust Credits', icon: Zap },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${tab === t.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <t.icon className="w-3.5 h-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {/* Payment History */}
          {tab === 'payments' && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2"><CreditCard className="w-4 h-4" /> Payment Records ({filteredPayments.length})</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {filteredPayments.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No payment records yet.</p>}
                  {filteredPayments.map(p => (
                    <div key={p.id} className="flex items-center gap-3 px-4 py-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${p.status === 'succeeded' ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                        {p.status === 'succeeded' ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium truncate">{p.user_email}</span>
                          <Badge className={`text-xs ${p.status === 'succeeded' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>{p.status}</Badge>
                          <Badge className="text-xs bg-secondary text-secondary-foreground">{p.payment_type === 'subscription' ? '📅 Sub' : '💳 One-time'}</Badge>
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {p.product_name || p.product_key} · {formatDate(p.created_date)}
                          {p.credits_granted > 0 && <span className="text-primary"> · +{p.credits_granted} credits</span>}
                          {p.plan_granted && <span className="text-purple-400"> · {p.plan_granted} plan</span>}
                        </div>
                      </div>
                      <div className="text-sm font-bold text-foreground shrink-0">{formatMoney(p.amount_cents)}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Credit History */}
          {tab === 'credits' && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2"><History className="w-4 h-4" /> Credit History ({filteredHistory.length})</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {filteredHistory.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No credit history yet.</p>}
                  {filteredHistory.map(h => (
                    <div key={h.id} className="flex items-center gap-3 px-4 py-2.5">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${h.credits_added > 0 ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                        {h.credits_added > 0 ? <Plus className="w-3.5 h-3.5 text-green-400" /> : <Minus className="w-3.5 h-3.5 text-red-400" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{h.user_email}</div>
                        <div className="text-xs text-muted-foreground">
                          {h.notes || h.action} · {formatDate(h.created_date)}
                          {h.balance_after !== undefined && <span> · Balance: {h.balance_after}</span>}
                        </div>
                      </div>
                      <div className="shrink-0 text-right">
                        {h.credits_spent > 0 && <div className="text-xs font-bold text-red-400">−{h.credits_spent}</div>}
                        {h.credits_added > 0 && <div className="text-xs font-bold text-green-400">+{h.credits_added}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Adjust Credits */}
          {tab === 'adjust' && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">Manually add or remove credits from any user account. All adjustments are logged.</p>
              {profiles.map(profile => (
                <Card key={profile.id} className="border-border">
                  <CardContent className="pt-3 pb-3">
                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm">{profile.full_name || profile.email || profile.created_by}</div>
                        <div className="text-xs text-muted-foreground">{profile.email || profile.created_by} · {profile.subscription_plan || 'free'} · <strong className="text-primary">{profile.ai_credits ?? 0} credits</strong></div>
                      </div>
                      {adjusting === profile.id ? (
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="flex items-center gap-1">
                            <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setAdjustDelta(d => d - 10)}><Minus className="w-3 h-3" /></Button>
                            <Input type="number" value={adjustDelta} onChange={e => setAdjustDelta(Number(e.target.value))} className="h-7 w-20 text-sm text-center" />
                            <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setAdjustDelta(d => d + 10)}><Plus className="w-3 h-3" /></Button>
                          </div>
                          <Input placeholder="Note..." value={adjustNote} onChange={e => setAdjustNote(e.target.value)} className="h-7 text-xs w-32" />
                          <Button size="sm" onClick={() => adjustCredits(profile.id, profile.email || profile.created_by)} disabled={saving} className="h-7 text-xs gap-1">
                            <Save className="w-3 h-3" />{saving ? 'Saving...' : 'Save'}
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => { setAdjusting(null); setAdjustDelta(0); }} className="h-7 text-xs">Cancel</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => { setAdjusting(profile.id); setAdjustDelta(0); setAdjustNote(''); }} className="gap-1 h-8 text-xs border-primary/30 text-primary">
                          <Zap className="w-3 h-3" /> Adjust Credits
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}