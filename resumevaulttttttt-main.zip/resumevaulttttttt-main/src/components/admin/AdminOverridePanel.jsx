import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const FEATURE_OPTIONS = [
  'resume_generation',
  'cover_letter',
  'job_analysis',
  'ats_score',
  'advanced_ats_report',
  'resume_templates',
  'resume_comparison',
  'auto_apply',
  'library_editing',
  'pdf_download',
  'word_download',
  'mock_interview',
  'salary_negotiation',
  'career_roadmap',
  'portfolio_ideas',
];

export default function AdminOverridePanel({ userEmail, currentPlan, currentCredits, adminEmail }) {
  const [overrideType, setOverrideType] = useState('credit_add');
  const [creditsAmount, setCreditsAmount] = useState('');
  const [planLevel, setPlanLevel] = useState('');
  const [selectedFeatures, setSelectedFeatures] = useState([]);
  const [tempDays, setTempDays] = useState('7');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [overrides, setOverrides] = useState([]);
  const [showForm, setShowForm] = useState(false);

  const handleAddOverride = async () => {
    if (!userEmail) {
      toast.error('User email required');
      return;
    }

    let newValue = '';
    let previousValue = '';

    if (overrideType === 'credit_add' || overrideType === 'credit_remove') {
      if (!creditsAmount) {
        toast.error('Credits amount required');
        return;
      }
      previousValue = `${currentCredits} credits`;
      const newAmount = overrideType === 'credit_add' 
        ? currentCredits + parseInt(creditsAmount)
        : Math.max(0, currentCredits - parseInt(creditsAmount));
      newValue = `${newAmount} credits`;
    }

    if (overrideType === 'plan_upgrade' || overrideType === 'plan_downgrade') {
      if (!planLevel) {
        toast.error('Plan level required');
        return;
      }
      previousValue = currentPlan;
      newValue = planLevel;
    }

    if (overrideType === 'feature_unlock' || overrideType === 'feature_lock') {
      if (selectedFeatures.length === 0) {
        toast.error('Select at least one feature');
        return;
      }
    }

    if (overrideType === 'temporary_access') {
      if (selectedFeatures.length === 0) {
        toast.error('Select at least one feature');
        return;
      }
      if (!tempDays) {
        toast.error('Days required');
        return;
      }
    }

    try {
      setLoading(true);

      const override = {
        user_email: userEmail,
        admin_email: adminEmail,
        override_type: overrideType,
        reason: reason || 'Admin override',
        previous_value: previousValue,
        new_value: newValue,
        is_active: true,
      };

      if (creditsAmount) override.credits_amount = parseInt(creditsAmount);
      if (planLevel) override.plan_granted = planLevel;
      if (selectedFeatures.length > 0) override.features_affected = selectedFeatures;
      
      if (overrideType === 'temporary_access') {
        const expiry = new Date();
        expiry.setDate(expiry.getDate() + parseInt(tempDays));
        override.temporary_until = expiry.toISOString();
      }

      // Create override entry (triggers real-time sync)
      await base44.entities.AdminOverride.create(override);

      // IMMEDIATELY apply changes to UserProfile to trigger real-time sync
      const profiles = await base44.entities.UserProfile.filter({ created_by: userEmail });
      if (profiles.length > 0) {
        const profileId = profiles[0].id;
        const updateData = {};

        // Update credits
        if (overrideType === 'credit_add' || overrideType === 'credit_remove' || overrideType === 'credit_reset') {
          let newCredits = currentCredits;
          if (overrideType === 'credit_add') newCredits += parseInt(creditsAmount);
          if (overrideType === 'credit_remove') newCredits = Math.max(0, currentCredits - parseInt(creditsAmount));
          if (overrideType === 'credit_reset') newCredits = 0;
          updateData.ai_credits = newCredits;

          // Log admin credit adjustment
          await base44.entities.CreditHistory.create({
            user_email: userEmail,
            action: 'admin_adjustment',
            credits_spent: overrideType === 'credit_remove' ? parseInt(creditsAmount) : 0,
            credits_added: overrideType === 'credit_add' ? parseInt(creditsAmount) : 0,
            balance_after: newCredits,
            source: 'admin_override',
            notes: `Admin override: ${overrideType}. Reason: ${reason}`,
          }).catch(() => {});
        }

        // Update plan
        if (overrideType === 'plan_upgrade' || overrideType === 'plan_downgrade') {
          updateData.subscription_plan = planLevel;
        }

        // Update profile (triggers real-time sync to user)
        if (Object.keys(updateData).length > 0) {
          await base44.entities.UserProfile.update(profileId, updateData);
        }
      }

      toast.success(`✅ Override applied! User will see changes instantly.`);
      setCreditsAmount('');
      setPlanLevel('');
      setSelectedFeatures([]);
      setReason('');
      setShowForm(false);
    } catch (e) {
      console.error('Override error:', e);
      toast.error('Failed to apply override');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveOverride = async (overrideId) => {
    try {
      setLoading(true);
      await base44.entities.AdminOverride.update(overrideId, { is_active: false });
      toast.success('Override removed');
    } catch (e) {
      console.error('Remove override error:', e);
      toast.error('Failed to remove override');
    } finally {
      setLoading(false);
    }
  };

  const toggleFeature = (feature) => {
    setSelectedFeatures(prev =>
      prev.includes(feature) ? prev.filter(f => f !== feature) : [...prev, feature]
    );
  };

  return (
    <div className="space-y-4">
      {!showForm ? (
        <Button onClick={() => setShowForm(true)} className="bg-primary text-primary-foreground">
          <Plus className="w-4 h-4 mr-2" /> Add Override
        </Button>
      ) : (
        <Card className="border-primary/30">
          <CardHeader>
            <CardTitle className="text-base">Apply Override to {userEmail}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase">Override Type</label>
              <Select value={overrideType} onValueChange={setOverrideType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="credit_add">Add Credits</SelectItem>
                  <SelectItem value="credit_remove">Remove Credits</SelectItem>
                  <SelectItem value="credit_reset">Reset Credits to 0</SelectItem>
                  <SelectItem value="plan_upgrade">Upgrade Plan</SelectItem>
                  <SelectItem value="plan_downgrade">Downgrade Plan</SelectItem>
                  <SelectItem value="feature_unlock">Unlock Feature</SelectItem>
                  <SelectItem value="feature_lock">Lock Feature</SelectItem>
                  <SelectItem value="temporary_access">Temporary Access (Days)</SelectItem>
                  <SelectItem value="override_cancel">Cancel Override</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(overrideType === 'credit_add' || overrideType === 'credit_remove') && (
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase">Credits Amount</label>
                <Input
                  type="number"
                  value={creditsAmount}
                  onChange={(e) => setCreditsAmount(e.target.value)}
                  placeholder="0"
                  min="0"
                />
              </div>
            )}

            {(overrideType === 'plan_upgrade' || overrideType === 'plan_downgrade') && (
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase">Plan Level</label>
                <Select value={planLevel} onValueChange={setPlanLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select plan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="free">Free</SelectItem>
                    <SelectItem value="pro">Pro</SelectItem>
                    <SelectItem value="elite">Elite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {(overrideType === 'feature_unlock' || overrideType === 'feature_lock' || overrideType === 'temporary_access') && (
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">
                  Features
                </label>
                <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-card rounded-lg border border-border">
                  {FEATURE_OPTIONS.map(feature => (
                    <label key={feature} className="flex items-center gap-2 cursor-pointer text-sm">
                      <input
                        type="checkbox"
                        checked={selectedFeatures.includes(feature)}
                        onChange={() => toggleFeature(feature)}
                        className="w-4 h-4"
                      />
                      {feature.replace(/_/g, ' ')}
                    </label>
                  ))}
                </div>
              </div>
            )}

            {overrideType === 'temporary_access' && (
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase">Days</label>
                <Input
                  type="number"
                  value={tempDays}
                  onChange={(e) => setTempDays(e.target.value)}
                  placeholder="7"
                  min="1"
                />
              </div>
            )}

            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase">Reason/Note</label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Why is this override being applied?"
                className="text-sm"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleAddOverride}
                disabled={loading}
                className="bg-primary text-primary-foreground flex-1"
              >
                {loading ? 'Applying...' : 'Apply Override'}
              </Button>
              <Button
                onClick={() => setShowForm(false)}
                variant="outline"
                disabled={loading}
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}