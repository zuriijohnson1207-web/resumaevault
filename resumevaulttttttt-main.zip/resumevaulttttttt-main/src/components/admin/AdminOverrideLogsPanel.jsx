import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Trash2, Clock, User, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

const OVERRIDE_LABELS = {
  credit_add: '➕ Added Credits',
  credit_remove: '➖ Removed Credits',
  credit_reset: '🔄 Reset Credits',
  plan_upgrade: '⬆️ Plan Upgraded',
  plan_downgrade: '⬇️ Plan Downgraded',
  feature_unlock: '🔓 Feature Unlocked',
  feature_lock: '🔒 Feature Locked',
  temporary_access: '⏰ Temporary Access',
  subscription_extend: '📅 Subscription Extended',
  override_cancel: '❌ Override Canceled',
};

export default function AdminOverrideLogsPanel({ userEmail }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) return;

    const loadLogs = async () => {
      try {
        setLoading(true);
        const allLogs = await base44.entities.AdminOverride.filter(
          { user_email: userEmail },
          '-created_date',
          100
        );
        setLogs(allLogs);
      } catch (e) {
        console.error('Failed to load override logs:', e);
      } finally {
        setLoading(false);
      }
    };

    loadLogs();

    const unsubscribe = base44.entities.AdminOverride.subscribe((event) => {
      if (event.data?.user_email === userEmail) {
        if (event.type === 'create') {
          setLogs(prev => [event.data, ...prev]);
        } else if (event.type === 'update') {
          setLogs(prev => prev.map(l => l.id === event.data.id ? event.data : l));
        }
      }
    });

    return unsubscribe;
  }, [userEmail]);

  const handleRemoveLog = async (logId) => {
    try {
      await base44.entities.AdminOverride.delete(logId);
      setLogs(prev => prev.filter(l => l.id !== logId));
      toast.success('Log deleted');
    } catch (e) {
      toast.error('Failed to delete log');
    }
  };

  if (loading) return <div className="text-sm text-muted-foreground">Loading override logs...</div>;

  return (
    <div className="space-y-3">
      <h3 className="font-bold text-sm uppercase text-muted-foreground">Override Logs</h3>
      {logs.length === 0 ? (
        <div className="text-xs text-muted-foreground py-4 text-center">No overrides applied yet</div>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {logs.map(log => (
            <div
              key={log.id}
              className="bg-card border border-border rounded-lg p-3 text-xs space-y-1"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 flex-1">
                  <Badge variant="outline" className="whitespace-nowrap">
                    {OVERRIDE_LABELS[log.override_type] || log.override_type}
                  </Badge>
                  {log.is_active && (
                    <Badge className="bg-green-500/20 text-green-300 whitespace-nowrap">Active</Badge>
                  )}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => handleRemoveLog(log.id)}
                  className="h-6 w-6 text-destructive hover:text-destructive/80"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>

              <div className="text-muted-foreground space-y-0.5">
                {log.previous_value && log.new_value && (
                  <div>
                    {log.previous_value} → <span className="text-primary font-semibold">{log.new_value}</span>
                  </div>
                )}

                {log.features_affected?.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {log.features_affected.map(f => (
                      <Badge key={f} variant="secondary" className="text-xs py-0">
                        {f.replace(/_/g, ' ')}
                      </Badge>
                    ))}
                  </div>
                )}

                {log.temporary_until && (
                  <div className="flex items-center gap-1 text-orange-400">
                    <Clock className="w-3 h-3" />
                    Until {format(new Date(log.temporary_until), 'MMM d, yyyy')}
                  </div>
                )}

                <div className="flex items-center gap-1">
                  <User className="w-3 h-3 text-muted-foreground" />
                  <span className="text-muted-foreground">{log.admin_email}</span>
                </div>

                <div className="text-muted-foreground text-xs">
                  {format(new Date(log.created_date), 'PPp')}
                </div>

                {log.reason && (
                  <div className="bg-secondary/50 rounded px-2 py-1 italic text-muted-foreground">
                    "{log.reason}"
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}