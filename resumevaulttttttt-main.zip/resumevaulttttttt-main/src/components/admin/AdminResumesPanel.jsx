import { useState } from 'react';
import { FileText, ChevronDown, ChevronUp, Copy, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

export default function AdminResumesPanel({ resumes, users, onRefresh }) {
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(null);

  const remove = async (id) => {
    if (!confirm('Delete this resume?')) return;
    await base44.entities.Resume.delete(id);
    toast({ title: 'Resume deleted.' });
    onRefresh();
  };

  const getUserEmail = (resume) => resume.created_by || '—';

  if (!resumes?.length) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-muted-foreground">
          <FileText className="w-10 h-10 opacity-30 mx-auto mb-2" />
          <p className="text-sm">No resumes found.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-sm">
          <FileText className="w-4 h-4 text-primary" /> All User Resumes
          <Badge className="bg-secondary text-secondary-foreground text-xs">{resumes.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {resumes.map(r => (
            <div key={r.id} className="border border-border rounded-xl overflow-hidden">
              <div
                className="flex items-center gap-3 p-3 cursor-pointer hover:bg-secondary/20 transition-colors"
                onClick={() => setExpanded(expanded === r.id ? null : r.id)}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{r.title}</p>
                  <p className="text-xs text-muted-foreground">{getUserEmail(r)} · {r.created_date ? new Date(r.created_date).toLocaleDateString() : '—'}</p>
                </div>
                <Badge className="bg-secondary text-xs shrink-0">{r.type || 'tailored'}</Badge>
                {expanded === r.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
              </div>
              {expanded === r.id && r.content && (
                <div className="border-t border-border bg-background/30 p-3 space-y-2">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(r.content)} className="gap-1 h-7 text-xs">
                      <Copy className="w-3 h-3" /> Copy
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => remove(r.id)} className="gap-1 h-7 text-xs border-destructive/40 text-destructive hover:bg-destructive/10">
                      <Trash2 className="w-3 h-3" /> Delete
                    </Button>
                  </div>
                  <pre className="text-xs text-foreground/80 whitespace-pre-wrap max-h-48 overflow-y-auto bg-secondary/20 rounded-lg p-3">{r.content}</pre>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}