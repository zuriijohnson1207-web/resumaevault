import { useState } from 'react';
import { Copy, Check, Code2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Renders a fenced code block from markdown with syntax highlighting and copy button.
 * Parses ```lang\ncode``` patterns.
 */
export default function CodeBlock({ language, code, filename }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const displayName = filename || language || 'code';

  return (
    <div className="my-3 rounded-xl border border-border overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-secondary/50 border-b border-border">
        <div className="flex items-center gap-2">
          <Code2 className="w-3.5 h-3.5 text-primary" />
          <span className="text-xs font-mono text-muted-foreground">{displayName}</span>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={copy}
          className="h-6 px-2 gap-1 text-xs"
        >
          {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
          {copied ? 'Copied!' : 'Copy'}
        </Button>
      </div>
      {/* Code */}
      <pre className="p-4 overflow-x-auto text-xs leading-relaxed bg-background/80 text-foreground font-mono whitespace-pre">
        {code}
      </pre>
    </div>
  );
}