import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ToggleLeft, ToggleRight, Settings } from 'lucide-react';

const FEATURES = [
  { key: 'resume_builder', label: 'Resume Builder', desc: 'AI resume generation' },
  { key: 'cover_letter', label: 'Cover Letter', desc: 'AI cover letter generation' },
  { key: 'auto_apply', label: 'Auto Apply', desc: 'Job search & auto-apply' },
  { key: 'mock_interview', label: 'Mock Interview', desc: 'AI interview coaching' },
  { key: 'salary_negotiation', label: 'Salary Negotiation', desc: 'Negotiation scripts' },
  { key: 'career_roadmap', label: 'Career Roadmap', desc: 'Career planning tool' },
  { key: 'portfolio_ideas', label: 'Portfolio Ideas', desc: 'Project idea generator' },
  { key: 'career_buddy', label: 'ZU Career Bestie', desc: 'AI chat companion' },
  { key: 'job_analyzer', label: 'Job Analyzer', desc: 'Job description analysis' },
  { key: 'follow_up_email', label: 'Follow-Up Email', desc: 'AI email generator' },
];

export default function AdminFeatureToggles() {
  const [features, setFeatures] = useState(() => {
    const saved = localStorage.getItem('admin_feature_toggles');
    if (saved) return JSON.parse(saved);
    return Object.fromEntries(FEATURES.map(f => [f.key, true]));
  });

  const toggle = (key) => {
    const updated = { ...features, [key]: !features[key] };
    setFeatures(updated);
    localStorage.setItem('admin_feature_toggles', JSON.stringify(updated));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-sm">
          <Settings className="w-4 h-4 text-primary" /> Feature Toggles
          <span className="text-xs text-muted-foreground font-normal">(stored locally)</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {FEATURES.map(f => (
            <button
              key={f.key}
              type="button"
              onClick={() => toggle(f.key)}
              className={`flex items-center justify-between gap-3 p-3 rounded-xl border transition-all text-left focus:outline-none focus:ring-2 focus:ring-primary ${
                features[f.key]
                  ? 'border-green-500/40 bg-green-500/5'
                  : 'border-border bg-secondary/20 opacity-60'
              }`}
              aria-label={`${features[f.key] ? 'Disable' : 'Enable'} ${f.label}`}
            >
              <div>
                <p className="text-sm font-medium text-foreground">{f.label}</p>
                <p className="text-xs text-muted-foreground">{f.desc}</p>
              </div>
              {features[f.key]
                ? <ToggleRight className="w-5 h-5 text-green-400 shrink-0" />
                : <ToggleLeft className="w-5 h-5 text-muted-foreground shrink-0" />
              }
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}