import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Crown, Lock, Zap, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PLAN_LIMITS, FEATURE_LABELS, CREDIT_COSTS } from '@/hooks/usePlanLimits';
import { useAuth } from '@/lib/AuthContext';
import UpgradeModal from '@/components/UpgradeModal';

/**
 * Wraps a feature and shows an upgrade wall if the user can't use it.
 * Credits act as a universal unlock — if user has enough credits for
 * a "locked" feature, they can still use it (credits will be deducted).
 * Admins bypass all gates entirely.
 */
export default function PlanGate({ feature, canUse, plan, getUsage, profile, children, hasOverride = false }) {
  const { user } = useAuth();
  const [showModal, setShowModal] = useState(false);
  // Admins always get full access — no gates, no credit deductions
  if (user?.role === 'admin') return <>{children}</>;
  
  // Show override badge if feature is unlocked via admin override
  if (hasOverride) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs bg-purple-500/10 border border-purple-500/30 rounded-lg px-3 py-2">
          <AlertCircle className="w-3 h-3 text-purple-400 shrink-0" />
          <span className="text-purple-300 font-semibold">Admin Override Active</span>
          <span className="text-muted-foreground">— this feature is unlocked by admin</span>
        </div>
        {children}
      </div>
    );
  }
  const { used, limit, remaining } = getUsage(feature);
  const label = FEATURE_LABELS[feature] || feature;
  const creditCost = CREDIT_COSTS[feature] || 1;
  const userCredits = profile?.ai_credits || 0;
  const canPayWithCredits = userCredits >= creditCost;

  // Feature blocked by plan BUT user has credits to unlock it
  if (limit === 0 && canPayWithCredits) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs bg-primary/10 border border-primary/30 rounded-lg px-3 py-2">
          <Zap className="w-3 h-3 text-primary shrink-0" />
          <span className="text-primary font-semibold">Using {creditCost} credits</span>
          <span className="text-muted-foreground">— {label} unlocked via credits ({userCredits} remaining)</span>
        </div>
        {children}
      </div>
    );
  }

  // Feature completely blocked for this plan AND no credits
  if (limit === 0 && !canPayWithCredits) {
    const requiredPlan = PLAN_LIMITS.pro[feature] > 0 ? 'Pro' : 'Elite';
    return (
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6 text-center">
        <Lock className="w-8 h-8 text-primary mx-auto mb-2" />
        <h3 className="font-bold text-white text-base mb-1">{label} — {requiredPlan} Feature</h3>
        <p className="text-sm text-white/70 mb-2">
          Upgrade to {requiredPlan} to unlock {label}, or buy AI credits to use it pay-as-you-go.
        </p>
        <p className="text-xs text-muted-foreground mb-4">Cost: {creditCost} credits per use · You have {userCredits} credits</p>
        <div className="flex gap-2 justify-center flex-wrap">
          <Link to="/pricing">
            <Button className="bg-primary text-primary-foreground gap-2">
              <Crown className="w-4 h-4" /> Upgrade to {requiredPlan}
            </Button>
          </Link>
          <Link to="/pricing">
            <Button variant="outline" className="gap-2 border-primary/40 text-primary">
              <Zap className="w-4 h-4" /> Buy Credits
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Monthly limit reached but has credits to continue
  if (!canUse && canPayWithCredits) {
    return (
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs bg-yellow-500/10 border border-yellow-500/30 rounded-lg px-3 py-2">
          <Zap className="w-3 h-3 text-yellow-400 shrink-0" />
          <span className="text-yellow-400 font-semibold">Monthly limit reached</span>
          <span className="text-muted-foreground">— continuing with credits ({creditCost} per use, {userCredits} remaining)</span>
        </div>
        {children}
      </div>
    );
  }

  // Monthly limit reached and no credits
  if (!canUse && !canPayWithCredits) {
    const reason = plan === 'free' ? 'free_limit' : 'no_credits';
    return (
      <>
        <UpgradeModal open={showModal} onClose={() => setShowModal(false)} reason={reason} />
        <div className="rounded-xl border border-yellow-500/30 bg-yellow-500/5 p-5 text-center">
          <Zap className="w-7 h-7 text-yellow-400 mx-auto mb-2" />
          <h3 className="font-bold text-foreground text-base mb-1">
            {plan === 'free' ? "You've used your free resumes" : 'Monthly Limit Reached'}
          </h3>
          <p className="text-sm text-muted-foreground mb-1">
            {plan === 'free'
              ? 'Upgrade to keep building job-winning resumes and unlock premium features.'
              : `You've used ${used}/${limit} ${label}s this month on the ${plan} plan.`}
          </p>
          <p className="text-xs text-muted-foreground mb-4">Buy credits to keep going ({creditCost} credits per use)</p>
          <div className="flex gap-2 justify-center flex-wrap">
            <Button className="bg-primary text-primary-foreground gap-2" onClick={() => setShowModal(true)}>
              <Crown className="w-4 h-4" /> Upgrade Now
            </Button>
            <Link to="/pricing">
              <Button variant="outline" className="gap-2 border-primary/40 text-primary">
                <Zap className="w-4 h-4" /> View Plans
              </Button>
            </Link>
          </div>
        </div>
      </>
    );
  }

  // All good — show usage indicator + children
  return (
    <div>
      {limit !== Infinity && (
        <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
          <Zap className="w-3 h-3 text-primary" />
          <span>{remaining} {label} use{remaining !== 1 ? 's' : ''} remaining this month</span>
          <span className="text-muted-foreground/50">({plan} plan)</span>
        </div>
      )}
      {children}
    </div>
  );
}