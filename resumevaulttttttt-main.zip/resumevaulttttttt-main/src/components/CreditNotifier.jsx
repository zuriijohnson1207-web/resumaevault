import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { usePlanLimits } from '@/hooks/usePlanLimits';

export default function CreditNotifier() {
  const { profile, loading, isAdmin } = usePlanLimits();
  const notifiedRef = useRef({ low: false, empty: false });

  useEffect(() => {
    if (loading || !profile || isAdmin) return;
    const credits = profile?.ai_credits ?? 0;

    if (credits === 0 && !notifiedRef.current.empty) {
      notifiedRef.current.empty = true;
      toast.warning('⚠️ Out of AI Credits', {
        description: 'You have no credits left. Top up on the Pricing page to keep using AI features like resume generation, cover letters, and job analysis.',
        duration: 10000,
        action: {
          label: 'Buy Credits →',
          onClick: () => window.location.href = '/pricing',
        },
      });
    } else if (credits > 0 && credits <= 15 && !notifiedRef.current.low) {
      notifiedRef.current.low = true;
      toast.warning(`⚡ Low Credits: ${credits} remaining`, {
        description: `You have ${credits} credits left. Each AI action (resume, cover letter, job analysis) uses a few credits. Top up to avoid interruptions.`,
        duration: 8000,
        action: {
          label: 'Add Credits →',
          onClick: () => window.location.href = '/pricing',
        },
      });
    }
  }, [profile?.ai_credits, loading]);

  return null;
}