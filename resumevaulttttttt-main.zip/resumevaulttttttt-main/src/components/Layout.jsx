import { useState, useEffect, lazy, Suspense } from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  LayoutDashboard, Search, FileText, BookOpen, Mail, Settings,
  BarChart2, Tag, Star, ChevronLeft, ChevronRight, Zap,
  Mic, DollarSign, Map, Lightbulb, Send, Crown, Shield, Bot, Heart, LogOut, Menu, X, User
} from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { cn } from '@/lib/utils';
import Footer from '@/components/Footer';
import CreditBar from '@/components/CreditBar';

// Lazy load floating UI elements — not critical for first paint
const FloatingCreditsButton = lazy(() => import('@/components/FloatingCreditsButton'));
const CreditNotifier = lazy(() => import('@/components/CreditNotifier'));
const FloatingAccessibility = lazy(() => import('@/components/FloatingAccessibility'));
const FloatingAIAssistant = lazy(() => import('@/components/FloatingAIAssistant'));

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
  { label: 'Auto Apply', icon: Send, path: '/auto-apply' },
  { label: 'Job Analyzer', icon: Search, path: '/job-analyzer' },
  { label: 'Resume Builder', icon: FileText, path: '/resume-builder' },
  { label: 'Resume Library', icon: BookOpen, path: '/resume-library' },
  { label: 'Cover Letter', icon: Mail, path: '/cover-letter' },
  { label: 'Follow-Up Email', icon: Send, path: '/follow-up-email' },
  { label: 'Settings', icon: Settings, path: '/profile' },
  { label: 'Application Tracker', icon: Tag, path: '/application-tracker' },
  { label: 'Analytics', icon: BarChart2, path: '/analytics' },
  { label: 'Pricing', icon: Crown, path: '/pricing' },
  { label: 'Reviews', icon: Star, path: '/reviews' },
  { label: 'ZU — Career Bestie', icon: Heart, path: '/career-buddy' },
];

const premiumItems = [
  { label: 'Interview Coach', icon: Mic, path: '/mock-interview' },
  { label: 'Salary Negotiation', icon: DollarSign, path: '/salary-negotiation' },
  { label: 'Career Roadmap', icon: Map, path: '/career-roadmap' },
  { label: 'Portfolio Ideas', icon: Lightbulb, path: '/portfolio-ideas' },
];

function SidebarContents({ collapsed, onNavClick }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [profileName, setProfileName] = useState(null);

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.UserProfile.filter({ created_by: user.email }).then(p => {
      if (p[0]?.full_name) setProfileName(p[0].full_name);
    }).catch(() => {});
  }, [user?.email]);

  return (
    <>
      {/* Logo */}
      <div className="flex items-center gap-2 p-4 border-b border-sidebar-border shrink-0">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 text-primary-foreground" />
        </div>
        {!collapsed && (
          <div>
            <div className="font-bold text-sm text-foreground leading-tight">Resumevault</div>
            <div className="text-xs text-primary font-semibold">GOD-MODE JOB HUNT</div>
          </div>
        )}
      </div>

      {/* Tagline */}
      {!collapsed && (
        <div className="px-3 py-2 border-b border-sidebar-border shrink-0">
          <p className="text-xs text-muted-foreground leading-tight">
            ⚡ Beat the ATS in 60 seconds & God-Mode your job hunt.
          </p>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={onNavClick}
              aria-current={active ? 'page' : undefined}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-primary",
                active ? "bg-primary text-primary-foreground font-bold" : "text-white hover:bg-sidebar-accent font-medium"
              )}
              title={collapsed ? item.label : undefined}
            >
              <item.icon className="w-5 h-5 shrink-0" aria-hidden="true" />
              {!collapsed && <span>{item.label}</span>}
              {!collapsed && active && <ChevronRight className="w-3 h-3 ml-auto" aria-hidden="true" />}
            </Link>
          );
        })}

        {/* Premium section */}
        {!collapsed && (
          <div className="pt-3 pb-1">
            <div className="flex items-center gap-1 px-3 py-1">
              <Zap className="w-3 h-3 text-primary" />
              <span className="text-xs font-semibold text-primary uppercase tracking-wider">Premium</span>
            </div>
          </div>
        )}
        {collapsed && <div className="my-1 border-t border-sidebar-border" />}

        {premiumItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={onNavClick}
              aria-current={active ? 'page' : undefined}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-primary",
                active ? "bg-primary text-primary-foreground font-bold" : "text-white hover:bg-sidebar-accent font-medium"
              )}
              title={collapsed ? item.label : undefined}
            >
              <item.icon className="w-5 h-5 shrink-0" aria-hidden="true" />
              {!collapsed && (
                <>
                  <span>{item.label}</span>
                  <Zap className="w-3 h-3 ml-auto text-primary" aria-hidden="true" />
                </>
              )}
            </Link>
          );
        })}

        {/* Admin section */}
        {user?.role === 'admin' && (
          <>
            {!collapsed && (
              <div className="pt-3 pb-1">
                <div className="flex items-center gap-1 px-3 py-1">
                  <Shield className="w-3 h-3 text-red-400" />
                  <span className="text-xs font-semibold text-red-400 uppercase tracking-wider">Admin</span>
                </div>
              </div>
            )}
            {[
              { label: 'Admin Controls', icon: Shield, path: '/admin' },
              { label: 'AI Assistant', icon: Bot, path: '/admin-assistant' },
            ].map(item => {
              const active = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={onNavClick}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors font-medium ${active ? 'bg-red-500/30 text-red-200 font-bold' : 'text-red-300 hover:bg-red-500/10'}`}
                  title={collapsed ? item.label : undefined}
                >
                  <item.icon className="w-4 h-4 shrink-0" />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              );
            })}
          </>
        )}
      </nav>

      {/* Credit bar */}
      {!collapsed && <CreditBar />}

      {/* User info + logout */}
      <div className="border-t border-sidebar-border shrink-0">
        {!collapsed && user && (
          <div className="px-3 py-2">
            <p className="text-xs text-white font-semibold truncate">{profileName || user.email}</p>
            <p className="text-xs text-muted-foreground truncate">{user.email}</p>
          </div>
        )}
        <button
          onClick={() => logout()}
          aria-label="Log out of your account"
          className="flex items-center justify-center gap-2 w-full px-3 py-3.5 text-sm font-bold text-destructive bg-destructive/15 hover:bg-destructive/25 transition-colors focus:outline-none focus:ring-2 focus:ring-destructive rounded-lg mx-3 my-2"
        >
          <LogOut className="w-5 h-5 shrink-0" aria-hidden="true" />
          {!collapsed && <span>Log Out</span>}
        </button>
      </div>
    </>
  );
}

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { logout } = useAuth();

  return (
    <div className="flex min-h-screen bg-background">
      {/* Skip to main content — for keyboard/screen reader users */}
      <a href="#main-content" className="skip-link">Skip to main content</a>

      {/* Desktop sidebar */}
      <aside className={cn(
        "hidden md:flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300 shrink-0",
        collapsed ? "w-16" : "w-56"
      )}>
        <SidebarContents collapsed={collapsed} onNavClick={undefined} />
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center p-3 border-t border-sidebar-border text-muted-foreground hover:text-foreground transition-colors shrink-0"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </aside>

      {/* Mobile drawer overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="relative z-10 flex flex-col w-72 max-w-[85vw] bg-sidebar border-r border-sidebar-border h-full overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-sidebar-border shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
                  <Zap className="w-4 h-4 text-primary-foreground" />
                </div>
                <div>
                  <div className="font-bold text-sm text-foreground">Resumevault</div>
                  <div className="text-xs text-primary font-semibold">GOD-MODE</div>
                </div>
              </div>
              <button
                onClick={() => setMobileOpen(false)}
                aria-label="Close menu"
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <SidebarContents collapsed={false} onNavClick={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">

        {/* Mobile top bar */}
        <header className="md:hidden flex items-center justify-between px-4 py-4 bg-sidebar border-b border-sidebar-border shrink-0">
          <button
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation menu"
            className="w-11 h-11 rounded-xl bg-secondary/50 flex items-center justify-center text-white hover:bg-secondary transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <Menu className="w-6 h-6" aria-hidden="true" />
          </button>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            <span className="font-bold text-base text-white">Resumevault</span>
          </div>
          <Link to="/pricing" className="text-sm text-primary font-bold px-3 py-2 rounded-lg bg-primary/10">Credits</Link>
        </header>

        <main id="main-content" className="flex-1 overflow-auto flex flex-col" tabIndex={-1}>
          <div className="flex-1 pb-20 md:pb-0">
            <Outlet />
          </div>
          <Footer />
        </main>
      </div>

      {/* Mobile bottom nav — large touch targets for accessibility */}
      <nav
        aria-label="Main navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-sidebar border-t border-sidebar-border flex items-stretch safe-area-inset-bottom"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        {[
          { label: 'Home', icon: LayoutDashboard, path: '/' },
          { label: 'Resume', icon: FileText, path: '/resume-builder' },
          { label: 'Library', icon: BookOpen, path: '/resume-library' },
          { label: 'Credits', icon: Crown, path: '/pricing' },
          { label: 'Profile', icon: User, path: '/profile' },
        ].map(item => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              aria-current={active ? 'page' : undefined}
              aria-label={item.label}
              className={cn(
                "flex-1 flex flex-col items-center justify-center py-3 gap-1 transition-colors focus:outline-none focus:ring-2 focus:ring-primary min-w-0",
                active ? "text-primary" : "text-muted-foreground"
              )}
            >
              <item.icon className="w-6 h-6 shrink-0" aria-hidden="true" />
              <span className="font-semibold text-[10px] leading-none">{item.label}</span>
            </Link>
          );
        })}
        {/* Mobile Logout Button */}
        <button
          onClick={logout}
          aria-label="Log out of your account"
          className="flex-1 flex flex-col items-center justify-center py-3 gap-1 transition-colors focus:outline-none focus:ring-2 focus:ring-destructive text-destructive hover:bg-destructive/10 min-w-0"
        >
          <LogOut className="w-6 h-6 shrink-0" aria-hidden="true" />
          <span className="font-semibold text-[10px] leading-none">Logout</span>
        </button>
      </nav>

      {/* Floating UI — lazy load after main content renders */}
      <Suspense fallback={null}>
        <FloatingCreditsButton />
        <CreditNotifier />
        <FloatingAIAssistant />
        <FloatingAccessibility />
      </Suspense>
    </div>
  );
}