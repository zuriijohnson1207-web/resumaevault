import { Link } from 'react-router-dom';
import { Zap, Mail, Twitter, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-border bg-card/50 mt-auto">
      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-white">ResumeVaultGodAI</span>
            </div>
            <p className="text-sm text-white/70 leading-relaxed">
              Beat the ATS in 60 seconds. AI-powered resumes, cover letters, and career tools to land your dream job faster.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="mailto:support@resumevaultgod.com" className="text-muted-foreground hover:text-primary transition-colors" title="Email us">
                <Mail className="w-4 h-4" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-colors" title="Twitter">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-primary transition-colors" title="LinkedIn">
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Product */}
          <div>
            <h4 className="font-bold text-white text-sm mb-3 uppercase tracking-wider">Product</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/resume-builder" className="text-white/70 hover:text-primary transition-colors">Resume Builder</Link></li>
              <li><Link to="/cover-letter" className="text-white/70 hover:text-primary transition-colors">Cover Letter AI</Link></li>
              <li><Link to="/job-analyzer" className="text-white/70 hover:text-primary transition-colors">Job Analyzer</Link></li>
              <li><Link to="/mock-interview" className="text-white/70 hover:text-primary transition-colors">Mock Interview</Link></li>
              <li><Link to="/auto-apply" className="text-white/70 hover:text-primary transition-colors">Auto Apply</Link></li>
              <li><Link to="/salary-negotiation" className="text-white/70 hover:text-primary transition-colors">Salary Negotiation</Link></li>
              <li><Link to="/career-roadmap" className="text-white/70 hover:text-primary transition-colors">Career Roadmap</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-bold text-white text-sm mb-3 uppercase tracking-wider">Support</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="mailto:support@resumevaultgod.com" className="text-white/70 hover:text-primary transition-colors">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="mailto:support@resumevaultgod.com?subject=Help Request" className="text-white/70 hover:text-primary transition-colors">
                  Help Center
                </a>
              </li>
              <li>
                <button
                  onClick={() => window.dispatchEvent(new CustomEvent('open-zu-chat'))}
                  className="text-white/70 hover:text-primary transition-colors text-left"
                >
                  Chat with ZU (AI)
                </button>
              </li>
              <li><Link to="/pricing" className="text-white/70 hover:text-primary transition-colors">Billing & Plans</Link></li>
              <li><Link to="/reviews" className="text-white/70 hover:text-primary transition-colors">Reviews</Link></li>
            </ul>
          </div>

          {/* FAQ */}
          <div>
            <h4 className="font-bold text-white text-sm mb-3 uppercase tracking-wider">FAQ</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <p className="text-white font-medium text-xs">What is ATS optimization?</p>
                <p className="text-white/60 text-xs">Our AI tailors your resume to pass Applicant Tracking Systems used by 99% of Fortune 500s.</p>
              </li>
              <li>
                <p className="text-white font-medium text-xs">Can I cancel anytime?</p>
                <p className="text-white/60 text-xs">Yes — cancel your subscription anytime with no penalties.</p>
              </li>
              <li>
                <p className="text-white font-medium text-xs">Do credits expire?</p>
                <p className="text-white/60 text-xs">No! Your purchased credits never expire.</p>
              </li>
              <li>
                <p className="text-white font-medium text-xs">Is there a free plan?</p>
                <p className="text-white/60 text-xs">Yes — start free with 2 AI tasks/month. Upgrade anytime.</p>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-white/50">© {new Date().getFullYear()} ResumeVaultGodAI. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-white/50">
            <a href="mailto:support@resumevaultgod.com?subject=Privacy Policy" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="mailto:support@resumevaultgod.com?subject=Terms of Service" className="hover:text-primary transition-colors">Terms of Service</a>
            <a href="mailto:support@resumevaultgod.com?subject=Cookie Policy" className="hover:text-primary transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}