import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';
import { usePlanLimits } from '@/hooks/usePlanLimits';

export default function FloatingCreditsButton() {
  const { profile, loading, isAdmin } = usePlanLimits();

  if (loading || isAdmin) return null;

  const credits = profile?.ai_credits ?? 0;
  const isEmpty = credits === 0;
  const isLow = credits > 0 && credits <= 15;

  return (
    <Link
      to="/pricing"
      className={`fixed top-3 right-4 z-30 md:right-5 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold shadow-lg transition-all hover:scale-105 focus:outline-none focus:ring-2 focus:ring-primary ${
        isEmpty
          ? 'bg-red-500 text-white animate-pulse'
          : isLow
          ? 'bg-yellow-500 text-black'
          : 'bg-primary text-primary-foreground'
      }`}
      aria-label={`${credits} AI credits — click to add more`}
      title={
        isEmpty
          ? 'You have no AI credits left. Click to buy more and continue using AI features.'
          : isLow
          ? `You only have ${credits} credits left — running low! Click to top up.`
          : `You have ${credits} AI credits. Each AI action (resume, cover letter, etc.) uses a set number of credits. Click to buy more.`
      }
    >
      <Zap className="w-3 h-3" />
      {isEmpty ? '⚠ Buy Credits' : `${credits} credits`}
    </Link>
  );
}