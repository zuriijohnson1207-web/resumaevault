import { useRef, useEffect, useState } from 'react';

/**
 * DraggableFloat — wraps any content in a draggable, position-remembered container.
 * storageKey: localStorage key for persisting position.
 * defaultPos: { x, y } default screen position (from bottom-right in px).
 */
export default function DraggableFloat({ children, storageKey, defaultPos = { x: 16, y: 160 }, className = '' }) {
  const ref = useRef(null);
  const dragging = useRef(false);
  const offset = useRef({ x: 0, y: 0 });

  const clamp = (pos) => {
    const el = ref.current;
    if (!el) return pos;
    const W = window.innerWidth;
    const H = window.innerHeight;
    const w = el.offsetWidth || 60;
    const h = el.offsetHeight || 60;
    return {
      x: Math.max(0, Math.min(W - w, pos.x)),
      y: Math.max(0, Math.min(H - h, pos.y)),
    };
  };

  const getSaved = () => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) return JSON.parse(raw);
    } catch {}
    return null;
  };

  // Convert "bottom-right" default into absolute coords on first load
  const getInitial = () => {
    const saved = getSaved();
    if (saved) return saved;
    return {
      x: window.innerWidth - defaultPos.x - 80,
      y: window.innerHeight - defaultPos.y,
    };
  };

  const [pos, setPos] = useState(() => getInitial());

  // Re-clamp on window resize
  useEffect(() => {
    const onResize = () => {
      setPos(p => {
        const clamped = clamp(p);
        localStorage.setItem(storageKey, JSON.stringify(clamped));
        return clamped;
      });
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [storageKey]);

  // ── Pointer (mouse + touch) drag handling ──────────────────────────────────
  const onPointerDown = (e) => {
    // Only drag on the handle (first child element with data-drag-handle)
    if (!e.target.closest('[data-drag-handle]')) return;
    dragging.current = true;
    const rect = ref.current.getBoundingClientRect();
    offset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
    ref.current.setPointerCapture(e.pointerId);
    e.preventDefault();
  };

  const onPointerMove = (e) => {
    if (!dragging.current) return;
    const newPos = clamp({
      x: e.clientX - offset.current.x,
      y: e.clientY - offset.current.y,
    });
    setPos(newPos);
  };

  const onPointerUp = (e) => {
    if (!dragging.current) return;
    dragging.current = false;
    setPos(p => {
      localStorage.setItem(storageKey, JSON.stringify(p));
      return p;
    });
  };

  return (
    <div
      ref={ref}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      style={{ position: 'fixed', left: pos.x, top: pos.y, zIndex: 9000, touchAction: 'none' }}
      className={className}
    >
      {children}
    </div>
  );
}