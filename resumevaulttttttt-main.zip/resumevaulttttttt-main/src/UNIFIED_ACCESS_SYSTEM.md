# Unified Access System — Real-Time Sync Architecture

## Overview
This document describes the **single source of truth** for feature access, replacing the broken dual-hook system (`usePlanLimits` + `useFeatureAccess`).

## Problem Solved
The previous system had:
- ❌ Two separate hooks with conflicting feature definitions
- ❌ Different feature keys (resume vs resume_generation)
- ❌ Manual refresh required to see updates
- ❌ Profile lookups by wrong field (`email` instead of `created_by`)
- ❌ No centralized access logic

## Solution: useUnifiedAccess Hook

### Single Feature Definition
All features defined in one place with consistent keys:
```javascript
export const UNIFIED_FEATURES = {
  resume: { label: 'AI Resume', creditCost: 5, free: 2, pro: 80, elite: 150 },
  cover_letter: { label: 'Cover Letter', creditCost: 3, free: 2, pro: Infinity, elite: Infinity },
  // ... all 10+ features
};
```

### Central Access Check Function
```javascript
const access = checkAccess(featureKey);
// Returns: { canUse, reason, creditsNeeded }
// Reasons: 'admin', 'admin_override', 'temporary_access', 
//          'plan_unlimited', 'plan_monthly_limit', 'credit_purchase', 'locked'
```

### Real-Time Sync
- ✅ Listens to UserProfile updates → UI refreshes instantly
- ✅ Listens to AdminOverride changes → Access updates live
- ✅ Profile lookups use `created_by` (correct field)
- ✅ No manual refresh needed

## Access Priority (Highest Wins)
1. **Admin user** → Always full access
2. **Admin override (unlock)** → Feature forced unlocked
3. **Temporary access** → Expiring override (with date check)
4. **Subscription plan** → Unlimited or monthly limit
5. **Credit purchase** → User can afford feature cost
6. **Locked** → No access

## Migration Path

### Step 1: Replace usePlanLimits with useUnifiedAccess
```javascript
// OLD
import { usePlanLimits } from '@/hooks/usePlanLimits';
const { canUse, profile, plan } = usePlanLimits();

// NEW
import { useUnifiedAccess } from '@/hooks/useUnifiedAccess';
const { checkAccess, profile, getUsageInfo } = useUnifiedAccess();
```

### Step 2: Use checkAccess() everywhere
```javascript
// OLD
const limit = PLAN_LIMITS[plan][feature];
const used = usageCounts[feature] || 0;
const canUse = used < limit || credits >= cost;

// NEW
const access = checkAccess('resume');
if (!access.canUse) {
  // Show upgrade modal
}
```

### Step 3: Replace PlanGate with UnifiedPlanGate
```javascript
// OLD
import PlanGate from '@/components/PlanGate';
<PlanGate feature="resume" canUse={true} plan={plan} />

// NEW
import UnifiedPlanGate from '@/components/UnifiedPlanGate';
<UnifiedPlanGate feature="resume">
  <YourComponent />
</UnifiedPlanGate>
```

## Files in New System

### Core
- `hooks/useUnifiedAccess.js` — Single hook for all access checking
- `components/UnifiedPlanGate.jsx` — Single gate component (replaces PlanGate)
- `UNIFIED_ACCESS_SYSTEM.md` — This file

### Keep (Updated)
- `components/admin/AdminOverridePanel` — Now uses `created_by` lookup
- `pages/Dashboard` — Already has real-time sync
- `pages/AdminControls` — Already uses AdminOverride entity

### Deprecate (Optional)
- `hooks/usePlanLimits.js` — Keep for now, stop using
- `hooks/useFeatureAccess.js` — Keep for now, stop using
- `components/PlanGate.jsx` — Keep for now, don't import

## Testing Real-Time Sync

### Test 1: Admin adds credits
1. Admin goes to `/admin`
2. Searches user email
3. Clicks "Add Override"
4. Selects "Add Credits" → enters "50"
5. Clicks "Apply Override"
✅ Expected: User's dashboard credit balance updates instantly (no refresh)

### Test 2: Admin unlocks feature
1. Admin selects user
2. "Add Override" → "Unlock Feature"
3. Checks "Mock Interview"
4. Applies override
✅ Expected: User's feature gate unlocks instantly

### Test 3: User buys credits
1. User goes to `/pricing`
2. Selects "Buy 100 Credits"
3. Completes Stripe payment
4. Redirected back to dashboard
✅ Expected: Credit balance updates instantly

### Test 4: Admin removes override
1. Admin goes to user's profile
2. Views override logs
3. Clicks "Remove" on an override
✅ Expected: User's access returns to plan-based limits instantly

### Test 5: Feature usage deduction
1. User has 5 credits
2. Uses a 5-credit feature (resume)
3. Feature deducts credits
✅ Expected: Dashboard shows 0 credits, trying to use another paid feature shows locked

### Test 6: Profile refresh still works
1. User has active override
2. User logs out
3. User logs back in
✅ Expected: Override still shows in dashboard

### Test 7: Mobile sync
1. User on desktop sees dashboard with 0 credits
2. Admin on mobile adds 50 credits
3. Desktop dashboard updates
✅ Expected: Real-time cross-device sync works

## API Reference

### checkAccess(featureKey)
```javascript
const { canUse, reason, creditsNeeded } = checkAccess('resume');

if (!canUse) {
  // Show gate based on reason
  if (reason === 'credit_purchase') {
    // Show "needs 5 credits" message
  } else if (reason === 'locked') {
    // Show "upgrade to Pro" message
  }
}
```

Returns:
- `canUse: boolean` — Can user access this feature?
- `reason: string` — Why (admin, admin_override, plan_unlimited, credit_purchase, locked, etc.)
- `creditsNeeded: number` — Credits needed to unlock (if credit_purchase)

### getUsageInfo(featureKey)
```javascript
const { used, limit, remaining } = getUsageInfo('resume');
// { used: 1, limit: 80, remaining: 79 }
```

### useFeature(featureKey)
```javascript
// Call AFTER user successfully uses a feature (e.g., resume generated)
const result = await useFeature('resume');
// Increments usage count
// Deducts credits if credit-based
// Logs to CreditHistory
```

## Feature Key Reference
All features use lowercase snake_case keys:
- `resume` — AI Resume generation
- `cover_letter` — Cover letter generation
- `job_analysis` — Job posting analysis
- `follow_up_email` — Follow-up email writing
- `mock_interview` — Mock interview practice
- `auto_apply` — Auto-apply to jobs
- `salary_negotiation` — Salary negotiation scripts
- `career_roadmap` — Career roadmap builder
- `portfolio_ideas` — Portfolio project ideas
- `ats_score` — ATS score calculation
- `advanced_ats_report` — Detailed ATS report
- `resume_templates` — Custom resume templates
- `resume_comparison` — Resume comparison tool
- `library_editing` — Edit saved resumes
- `pdf_download` — Export resume as PDF
- `word_download` — Export resume as Word

## Stripe Webhook Integration
When Stripe sends payment success:
1. Webhook handler receives event
2. Creates/updates CreditHistory entry
3. Updates UserProfile.ai_credits
4. UserProfile update triggers real-time sync
5. useUnifiedAccess subscription fires
6. UI updates automatically ✅

No manual refresh needed — system is event-driven.

## Admin Override Types
All 11 override types work with unified system:
- `credit_add` — Add N credits
- `credit_remove` — Remove N credits
- `credit_reset` — Reset to 0
- `plan_upgrade` — Change to Pro/Elite
- `plan_downgrade` — Change to Free/Pro
- `feature_unlock` — Unlock specific features
- `feature_lock` — Lock specific features
- `temporary_access` — Grant N days access (auto-expires)
- `subscription_extend` — Extend subscription end date
- `override_cancel` — Cancel/deactivate override
- `give_free_credits` — Marketing promo

## Database Sync
These tables stay connected:
- `UserProfile` — subscription_plan, ai_credits, usage_counts
- `AdminOverride` — user overrides (auto-synced)
- `CreditHistory` — credit transaction log
- `PaymentRecord` — Stripe transactions
- `Application` — Job applications (separate, doesn't affect access)

Updates to any table trigger real-time updates via:
```javascript
base44.entities.UserProfile.subscribe((event) => {
  // UI updates automatically
});
```

## Common Issues & Fixes

### Issue: Profile not updating after admin changes
**Cause:** Lookup using `email` instead of `created_by`
**Fix:** Use `created_by: userEmail` in all profile filters

### Issue: Old PlanGate still showing locked features
**Cause:** Old hook looking at wrong feature keys
**Fix:** Replace PlanGate import with UnifiedPlanGate

### Issue: Credits not deducting after feature use
**Cause:** useFeature() never called
**Fix:** Call `useFeature(featureKey)` after feature succeeds

### Issue: Override doesn't appear in dashboard
**Cause:** AdminOverride create() succeeds but UserProfile not updated
**Fix:** AdminOverridePanel already does this — check that both creates complete

### Issue: User sees stale data after refresh
**Cause:** Browser cache
**Fix:** Use query invalidation in react-query (if needed)

## Next Steps
1. ✅ Deploy useUnifiedAccess hook
2. ✅ Deploy UnifiedPlanGate component
3. 🔄 Migrate feature pages to use UnifiedPlanGate
4. 🔄 Migrate API calls to use checkAccess()
5. ✅ Test all 7 scenarios above
6. 🔄 Remove old hooks (after migration complete)
7. 📊 Monitor real-time sync in production