# Complete Unlock System Integration Guide

## What's New

A complete, bulletproof credit + subscription + override unlock system with **instant real-time sync**.

When credits are added, subscriptions change, or overrides are applied:
- ✅ Features unlock INSTANTLY (no refresh)
- ✅ Dashboard updates immediately
- ✅ All buttons sync across devices
- ✅ No delayed unlocks or stale state

## Core System

### 1. Central Access Check
**File:** `lib/checkUserAccess.js`

Single source of truth. Used everywhere.

```js
import { checkUserAccess } from '@/lib/checkUserAccess';

const access = await checkUserAccess(userEmail, 'resume');
// Returns: { canUse: true, reason: 'plan_unlimited', creditsNeeded: 0 }
```

### 2. Backend Sync Functions

#### `addCreditsAndSync.js`
Call when admin adds credits or user purchases.

```js
const response = await base44.functions.invoke('addCreditsAndSync', {
  userEmail: 'user@email.com',
  creditsToAdd: 50,
  reason: 'admin_override',
  adminEmail: 'admin@email.com',
});
```

**Triggers:**
- Update `UserProfile.ai_credits`
- Log `CreditHistory`
- Fire `UserProfile.subscribe()` listener
- Frontend sees changes instantly

#### `upgradeSubscriptionAndSync.js`
Call when admin upgrades plan or user subscribes.

```js
const response = await base44.functions.invoke('upgradeSubscriptionAndSync', {
  userEmail: 'user@email.com',
  newPlan: 'pro',
  reason: 'subscription_upgrade',
  adminEmail: 'admin@email.com',
});
```

**Triggers:**
- Update `UserProfile.subscription_plan`
- Reset `usage_counts`
- Log `CreditHistory`
- Fire `UserProfile.subscribe()` listener
- All plan features unlock instantly

#### `syncUnlockState.js`
Call to verify current unlock state (debugging/verification).

```js
const response = await base44.functions.invoke('syncUnlockState', {});
// Returns: { profile, overrides, unlocked, ... }
```

### 3. Frontend Components

#### `FeatureUnlockDisplay.jsx`
Shows all unlocked features with real-time sync.

```jsx
import FeatureUnlockDisplay from '@/components/FeatureUnlockDisplay';

<FeatureUnlockDisplay />
```

Features:
- Lists all 10+ features
- Shows unlock reason
- Updates when profile changes
- Updates when overrides change
- No refresh needed

#### `FeatureButton.jsx`
Wraps any feature action button.

```jsx
import FeatureButton from '@/components/FeatureButton';

<FeatureButton feature="resume" onClick={handleGenerateResume}>
  Generate Resume
</FeatureButton>
```

Features:
- Checks access before allowing click
- Shows lock icon if blocked
- Opens upgrade modal if needed
- Works with credits and subscriptions

#### `UnlockSystemTester.jsx`
Development only — test unlock flows.

```jsx
import UnlockSystemTester from '@/components/UnlockSystemTester';

{process.env.NODE_ENV === 'development' && <UnlockSystemTester />}
```

## Integration Points

### Admin Panel
```jsx
// AdminOverridePanel already integrated
// When admin adds credits or upgrades plan:
// 1. Creates AdminOverride record
// 2. Calls backend sync functions
// 3. Updates UserProfile directly
// 4. Triggers real-time listeners
// 5. Frontend updates instantly
```

### Dashboard
```jsx
// Dashboard already shows:
// - Current plan
// - Credit balance
// - FeatureUnlockDisplay (all unlocked features)
// - Real-time sync listeners
```

### Feature Pages
```jsx
// For any feature page (Resume Builder, Job Analyzer, etc.):

import FeatureButton from '@/components/FeatureButton';

<FeatureButton feature="resume" onClick={handleGenerateResume}>
  Generate AI Resume
</FeatureButton>
```

## Usage Examples

### Example 1: Admin Adds Credits
```jsx
// In AdminOverridePanel:
const handleAddCredits = async () => {
  const response = await base44.functions.invoke('addCreditsAndSync', {
    userEmail: 'user@email.com',
    creditsToAdd: 50,
    reason: 'admin_override',
    adminEmail: admin.email,
  });

  if (response.data?.success) {
    // Frontend listeners automatically update
    toast.success('Credits added! Features unlocking...');
  }
};
```

### Example 2: Check Feature Access
```jsx
// Before running feature:
const access = await checkUserAccess(user.email, 'resume');

if (access.canUse) {
  // Generate resume, deduct credits
  const result = await recordFeatureUsage(user.email, 'resume');
  // Dashboard updates automatically
} else {
  // Show upgrade modal
  setShowUpgrade(true);
}
```

### Example 3: Real-Time Subscription Unlock
```jsx
// When user subscribes via Stripe:
const response = await base44.functions.invoke('upgradeSubscriptionAndSync', {
  userEmail: stripeCustomerEmail,
  newPlan: 'pro',
  reason: 'stripe_subscription',
});

// Frontend Dashboard:
// 1. UserProfile listener fires
// 2. setProfile() called
// 3. FeatureUnlockDisplay re-renders
// 4. All Pro features show as unlocked
// 5. No refresh needed
```

## Real-Time Sync Flow

### When Admin Adds Credits:
```
1. Admin clicks "Add Credits"
2. AdminOverridePanel calls addCreditsAndSync()
3. Backend updates UserProfile.ai_credits
4. Database event fires: UserProfile updated
5. Frontend listener catches event:
   base44.entities.UserProfile.subscribe((event) => {
     if (event.data?.created_by === user.email) {
       setProfile(event.data); // Re-render!
     }
   });
6. FeatureUnlockDisplay calls refreshAccessMap()
7. All features re-check access via checkUserAccess()
8. UI updates instantly (credit-based features unlock)
9. Dashboard shows new credit balance
10. No refresh needed ✅
```

## Key Files

```
lib/checkUserAccess.js              ← Central access engine
functions/addCreditsAndSync.js      ← Credit updates
functions/upgradeSubscriptionAndSync.js  ← Plan updates
functions/syncUnlockState.js        ← Verify state
components/FeatureUnlockDisplay.jsx ← Shows all unlocks
components/FeatureButton.jsx        ← Wraps feature actions
components/UnlockSystemTester.jsx   ← Dev testing
pages/Dashboard                     ← Main dashboard
components/admin/AdminOverridePanel ← Admin controls
```

## Testing Checklist

- [ ] Admin adds credits → features unlock instantly
- [ ] Admin upgrades plan → all plan features unlock instantly
- [ ] User buys credits → features unlock instantly
- [ ] User spends credits → balance updates instantly
- [ ] Admin removes override → features lock again
- [ ] Mobile + desktop → both sync correctly
- [ ] Refresh page → access still correct
- [ ] Log out/in → state preserved
- [ ] Multiple overrides → all apply correctly
- [ ] Credits hit 0 → credit features lock

## Debugging

### Features not unlocking?
1. Check `UserProfile.ai_credits` updated in DB
2. Check `UserProfile.subscribe()` listener attached
3. Check `checkUserAccess()` returns `canUse: true`
4. Check `FeatureUnlockDisplay.refreshAccessMap()` called

### Credits not showing?
1. Check `setProfile()` called with new data
2. Check `created_by` matches user email
3. Check Dashboard listening to correct email

### Overrides not applying?
1. Check `AdminOverride` record created
2. Check `user_email` is lowercase
3. Check `is_active: true`
4. Check `features_affected` array populated

## Security

- ✅ Backend enforces access via `checkUserAccess()`
- ✅ Frontend is UI convenience only — backend validates
- ✅ Admin role checked on backend (`user.role === 'admin'`)
- ✅ User isolation via `created_by` and `user_email` filters
- ✅ Overrides logged to `CreditHistory` for audit trail

## Performance

- ✅ No N+1 queries (filter once, use profile)
- ✅ Real-time listeners are efficient
- ✅ Access checks cached in component state
- ✅ No unnecessary re-renders
- ✅ Lightweight JSON updates only

## Next Steps

1. **Test the system** — Run `UnlockSystemTester` in dashboard
2. **Verify sync** — Open two browser windows, make changes
3. **Integration** — Wrap feature buttons with `FeatureButton`
4. **Monitoring** — Check `CreditHistory` logs for accuracy
5. **Production** — Remove `UnlockSystemTester` before deploy

## Support

If features aren't unlocking:
1. Check browser console for errors
2. Check backend logs in Function editor
3. Verify UserProfile has correct `ai_credits` and `subscription_plan`
4. Test with `UnlockSystemTester` component
5. Check `REAL_TIME_UNLOCK_SYSTEM.md` for detailed architecture