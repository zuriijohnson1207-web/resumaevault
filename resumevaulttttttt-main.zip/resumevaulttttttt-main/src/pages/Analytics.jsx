import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { BarChart2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import PageHeader from '@/components/PageHeader';

const STATUS_COLORS = {
  saved: '#6b7280',
  applied: '#3b82f6',
  interviewing: '#f59e0b',
  offer: '#10b981',
  rejected: '#ef4444',
};

export default function Analytics() {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    base44.entities.Application.list().then(setApplications);
  }, []);

  const statusCounts = Object.keys(STATUS_COLORS).map(s => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    value: applications.filter(a => a.status === s).length,
    color: STATUS_COLORS[s],
  })).filter(s => s.value > 0);

  // Applications by month
  const byMonth = {};
  applications.forEach(a => {
    if (a.applied_date) {
      const month = a.applied_date.slice(0, 7);
      byMonth[month] = (byMonth[month] || 0) + 1;
    }
  });
  const monthData = Object.entries(byMonth).sort().slice(-6).map(([m, c]) => ({ month: m.slice(5), count: c }));

  const successRate = applications.length > 0
    ? Math.round((applications.filter(a => a.status === 'offer').length / applications.length) * 100)
    : 0;

  const responseRate = applications.length > 0
    ? Math.round((applications.filter(a => ['interviewing', 'offer'].includes(a.status)).length / applications.length) * 100)
    : 0;

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader icon={BarChart2} title="Analytics" subtitle="Track your job search performance" />

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Applications', value: applications.length, color: 'text-foreground' },
          { label: 'Response Rate', value: `${responseRate}%`, color: 'text-blue-400' },
          { label: 'Interview Rate', value: `${Math.round((applications.filter(a=>a.status==='interviewing').length / Math.max(applications.length,1))*100)}%`, color: 'text-yellow-400' },
          { label: 'Offer Rate', value: `${successRate}%`, color: 'text-green-400' },
        ].map(k => (
          <Card key={k.label}>
            <CardContent className="pt-4 pb-4 text-center">
              <div className={`text-3xl font-bold ${k.color}`}>{k.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{k.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Status breakdown */}
        <Card>
          <CardHeader><CardTitle className="text-base">Applications by Status</CardTitle></CardHeader>
          <CardContent>
            {statusCounts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No data yet</p>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusCounts} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({name, value}) => `${name}: ${value}`}>
                    {statusCounts.map((s, i) => <Cell key={i} fill={s.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Monthly trend */}
        <Card>
          <CardHeader><CardTitle className="text-base">Applications per Month</CardTitle></CardHeader>
          <CardContent>
            {monthData.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">Add applications with dates to see trends</p>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={monthData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                  <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', color: 'hsl(var(--foreground))' }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top companies */}
      <Card>
        <CardHeader><CardTitle className="text-base">Applications by Company</CardTitle></CardHeader>
        <CardContent>
          {applications.length === 0 ? (
            <p className="text-sm text-muted-foreground">No applications yet.</p>
          ) : (
            <div className="space-y-2">
              {Object.entries(applications.reduce((acc, a) => { acc[a.company] = (acc[a.company] || 0) + 1; return acc; }, {}))
                .sort((a, b) => b[1] - a[1]).slice(0, 8).map(([company, count]) => (
                  <div key={company} className="flex items-center gap-3">
                    <span className="text-sm w-32 truncate">{company}</span>
                    <div className="flex-1 bg-secondary rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: `${(count / applications.length) * 100}%` }} />
                    </div>
                    <span className="text-xs text-muted-foreground w-6 text-right">{count}</span>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}