import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Shield, RefreshCw, Users, Trash2, Save, ChevronDown, ChevronUp, UserCog, CloudUpload, Download, Mail, Phone, MapPin, Briefcase, GraduationCap, Star, Plus, Minus, ExternalLink, FileText, Send, Settings, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/lib/AuthContext';
import PageHeader from '@/components/PageHeader';
import { useToast } from '@/components/ui/use-toast';
import AdminFeatureToggles from '@/components/admin/AdminFeatureToggles';
import AdminResumesPanel from '@/components/admin/AdminResumesPanel';
import AdminPaymentsPanel from '@/components/admin/AdminPaymentsPanel';
import AdminOverridePanel from '@/components/admin/AdminOverridePanel';
import AdminOverrideLogsPanel from '@/components/admin/AdminOverrideLogsPanel';

export default function AdminControls() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [users, setUsers] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [applications, setApplications] = useState([]);
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncingStripe, setSyncingStripe] = useState(false);
  const [importingStripe, setImportingStripe] = useState(false);
  const [expandedUser, setExpandedUser] = useState(null);
  const [adminTab, setAdminTab] = useState('users');
  const [editCredits, setEditCredits] = useState({});
  const [editPlan, setEditPlan] = useState({});
  const [editRole, setEditRole] = useState({});
  const [inviting, setInviting] = useState({});

  const load = async () => {
    setLoading(true);
    const [u, p, a, r] = await Promise.all([
      base44.entities.User.list(),
      base44.entities.UserProfile.list(),
      base44.entities.Application.list(),
      base44.entities.Resume.list(),
    ]);
    setUsers(u);
    setProfiles(p);
    setApplications(a);
    setResumes(r);
    // init edit state
    const credits = {};
    const plans = {};
    const roles = {};
    p.forEach(pr => {
      credits[pr.id] = pr.ai_credits ?? 0;
      plans[pr.id] = pr.subscription_plan ?? 'free';
    });
    u.forEach(usr => { roles[usr.id] = usr.role ?? 'user'; });
    setEditCredits(credits);
    setEditPlan(plans);
    setEditRole(roles);
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const importFromStripe = async () => {
    if (!confirm('This will import all Stripe customers as UserProfiles (skipping existing emails). Continue?')) return;
    setImportingStripe(true);
    const res = await base44.functions.invoke('importStripeCustomers', {});
    const { imported, skipped, total_stripe_customers } = res.data || {};
    toast({ title: `Import Done! ${imported} imported, ${skipped} skipped out of ${total_stripe_customers} Stripe customers.` });
    setImportingStripe(false);
    load();
  };

  const syncToStripe = async () => {
    setSyncingStripe(true);
    const res = await base44.functions.invoke('syncUsersToStripe', {});
    const { created, skipped, errors } = res.data || {};
    toast({ title: `Stripe Sync Done! Created: ${created}, Skipped: ${skipped}${errors?.length ? `, Errors: ${errors.length}` : ''}` });
    setSyncingStripe(false);
  };

  const syncAndRefresh = async () => {
    setSyncing(true);
    await load();
    setSyncing(false);
    toast({ title: '✅ Data synced & refreshed!' });
  };

  const updateProfile = async (profileId) => {
    const currentProfile = profiles.find(p => p.id === profileId);
    const planChanged = currentProfile && currentProfile.subscription_plan !== editPlan[profileId];
    const creditsChanged = currentProfile && currentProfile.ai_credits !== Number(editCredits[profileId]);
    const updateData = {
      ai_credits: Number(editCredits[profileId]),
      subscription_plan: editPlan[profileId],
    };
    // Reset monthly usage when upgrading/changing plan so user gets fresh quota
    if (planChanged) {
      updateData.usage_counts = { resume: 0, cover_letter: 0, job_analysis: 0, follow_up_email: 0, mock_interview: 0, auto_apply: 0, salary_negotiation: 0, career_roadmap: 0, portfolio_ideas: 0 };
      updateData.monthly_uses = 0;
    }
    // Update the profile (admin users have permission)
    await base44.entities.UserProfile.update(profileId, updateData);
    // Immediately sync with updated profile in state
    setProfiles(p => p.map(pr => pr.id === profileId ? { ...pr, ...updateData } : pr));
    
    // Show success notification
    let message = '✅ Saved!';
    if (planChanged && creditsChanged) {
      message = `✅ Credits (${editCredits[profileId]}) & plan (${editPlan[profileId]}) saved! User can now access unlocked features.`;
    } else if (creditsChanged) {
      message = `✅ ${editCredits[profileId]} credits saved! User can now access feature.`;
    } else if (planChanged) {
      message = `✅ Plan upgraded to ${editPlan[profileId]}! User can now access all features.`;
    }
    toast({ title: message });
    
    // Auto-switch to payments tab
    setAdminTab('payments');
  };

  const resetUsage = async (profileId) => {
    await base44.entities.UserProfile.update(profileId, {
      usage_counts: { resume: 0, cover_letter: 0, job_analysis: 0, follow_up_email: 0, mock_interview: 0, auto_apply: 0, salary_negotiation: 0, career_roadmap: 0, portfolio_ideas: 0 },
      monthly_uses: 0,
    });
    toast({ title: '🔄 Monthly usage reset to 0!' });
    load();
  };

  const updateUserRole = async (userId) => {
    await base44.entities.User.update(userId, { role: editRole[userId] });
    toast({ title: `Role updated to "${editRole[userId]}"` });
    load();
  };

  const inviteUser = async (email, profileId) => {
    setInviting(i => ({ ...i, [profileId]: true }));
    await base44.users.inviteUser(email, 'user');
    toast({ title: `✅ Invite sent to ${email}! They'll get an email to join the app.` });
    setInviting(i => ({ ...i, [profileId]: false }));
  };

  const deleteUser = async (profileId) => {
    if (!confirm('Delete this user profile?')) return;
    await base44.entities.UserProfile.delete(profileId);
    toast({ title: 'User profile deleted.' });
    load();
  };

  const getProfileForUser = (email) => profiles.find(p => p.email === email || p.created_by === email);

  const stats = {
    totalUsers: users.length,
    totalProfiles: profiles.length,
    totalApplications: applications.length,
    totalResumes: resumes.length,
    proUsers: profiles.filter(p => p.subscription_plan === 'pro').length,
    eliteUsers: profiles.filter(p => p.subscription_plan === 'elite').length,
  };

  if (user?.role !== 'admin') {
    return (
      <div className="p-6 flex items-center justify-center min-h-[60vh]">
        <Card className="text-center p-8">
          <Shield className="w-12 h-12 text-destructive mx-auto mb-3" />
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">This page is for admins only.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <PageHeader icon={Shield} title="Admin Controls" subtitle="Manage users, sync data, update profiles" />
        <div className="flex gap-2">
          <Button onClick={importFromStripe} disabled={importingStripe} variant="outline" className="gap-2 border-purple-500/50 text-purple-400 hover:bg-purple-500/10">
            <Download className={`w-4 h-4 ${importingStripe ? 'animate-bounce' : ''}`} />
            {importingStripe ? 'Importing...' : 'Import from Stripe'}
          </Button>
          <Button onClick={syncToStripe} disabled={syncingStripe} variant="outline" className="gap-2">
            <CloudUpload className={`w-4 h-4 ${syncingStripe ? 'animate-pulse' : ''}`} />
            {syncingStripe ? 'Syncing to Stripe...' : 'Sync Users → Stripe'}
          </Button>
          <Button onClick={syncAndRefresh} disabled={syncing} className="gap-2 bg-primary text-primary-foreground">
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync & Refresh'}
          </Button>
        </div>
      </div>

      {/* Admin tab nav */}
      <div className="flex gap-1 mb-5 bg-secondary/30 rounded-xl p-1 overflow-x-auto" role="tablist">
        {[
          { id: 'users', label: 'Users', icon: Users },
          { id: 'payments', label: 'Payments & Credits', icon: CreditCard },
          { id: 'resumes', label: 'Resumes', icon: FileText },
          { id: 'features', label: 'Features', icon: Settings },
        ].map(tab => (
          <button
            key={tab.id}
            role="tab"
            aria-selected={adminTab === tab.id}
            onClick={() => setAdminTab(tab.id)}
            className={`flex items-center gap-1.5 py-2 px-4 rounded-lg text-sm font-medium transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-primary ${adminTab === tab.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <tab.icon className="w-4 h-4" /> {tab.label}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {[
          { label: 'Total Users', value: stats.totalUsers, color: 'text-foreground' },
          { label: 'Profiles', value: stats.totalProfiles, color: 'text-blue-400' },
          { label: 'Applications', value: stats.totalApplications, color: 'text-yellow-400' },
          { label: 'Resumes', value: stats.totalResumes, color: 'text-green-400' },
          { label: 'Pro', value: stats.proUsers, color: 'text-primary' },
          { label: 'Elite', value: stats.eliteUsers, color: 'text-purple-400' },
        ].map(s => (
          <Card key={s.label}>
            <CardContent className="pt-3 pb-3 text-center">
              <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Payments & Credits Tab */}
      {adminTab === 'payments' && (
        <AdminPaymentsPanel profiles={profiles} />
      )}

      {/* Resumes Tab */}
      {adminTab === 'resumes' && (
        <AdminResumesPanel resumes={resumes} users={users} onRefresh={load} />
      )}

      {/* Features Tab */}
      {adminTab === 'features' && (
        <AdminFeatureToggles />
      )}

      {/* User Management */}
      {adminTab === 'users' && <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Users className="w-4 h-4" /> User Management <span className="text-muted-foreground text-sm font-normal">({users.length} app accounts · {profiles.length} profiles)</span></CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="space-y-4">

              {/* App Users (have login accounts) */}
              {users.length > 0 && (
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 px-1">App Accounts ({users.length})</div>
                  <div className="space-y-2">
              {users.map(u => {
                const profile = getProfileForUser(u.email);
                const isExpanded = expandedUser === u.id;
                return (
                  <div key={u.id} className="border border-border rounded-lg overflow-hidden">
                    {/* User row */}
                    <div
                      className="flex items-center gap-3 p-3 cursor-pointer hover:bg-secondary/30"
                      onClick={() => setExpandedUser(isExpanded ? null : u.id)}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                        {u.full_name?.charAt(0) || u.email?.charAt(0) || '?'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{u.full_name || u.email}</span>
                          <Badge className={u.role === 'admin' ? 'bg-red-500/20 text-red-300 text-xs' : 'bg-secondary text-secondary-foreground text-xs'}>{u.role}</Badge>
                          {profile && (
                            <Badge className={profile.subscription_plan === 'elite' ? 'bg-purple-500/20 text-purple-300 text-xs' : profile.subscription_plan === 'pro' ? 'bg-primary/20 text-primary text-xs' : 'bg-secondary text-secondary-foreground text-xs'}>
                              {profile.subscription_plan || 'free'}
                            </Badge>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">{u.email}</div>
                      </div>
                      <div className="text-xs text-muted-foreground shrink-0">
                        {profile ? `${profile.ai_credits ?? 0} credits` : 'No profile'}
                      </div>
                      {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                    </div>

                    {/* Expanded controls */}
                    {isExpanded && (
                      <div className="border-t border-border bg-secondary/10 p-4 space-y-4">
                        {/* Role control — always shown */}
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <UserCog className="w-3.5 h-3.5 text-red-400" />
                            <span className="text-xs font-semibold text-red-400 uppercase tracking-wide">User Role</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <Select value={editRole[u.id] || 'user'} onValueChange={v => setEditRole(r => ({ ...r, [u.id]: v }))}>
                              <SelectTrigger className="h-8 text-sm w-40"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="user">User</SelectItem>
                                <SelectItem value="admin">Admin</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button size="sm" onClick={() => updateUserRole(u.id)} className="bg-red-500/80 hover:bg-red-500 text-white gap-1 h-8">
                              <Save className="w-3 h-3" /> Save Role
                            </Button>
                            <span className="text-xs text-muted-foreground">Current: <span className={u.role === 'admin' ? 'text-red-400 font-semibold' : 'text-foreground'}>{u.role}</span></span>
                          </div>
                        </div>

                        {/* Profile controls */}
                        {profile ? (
                          <div className="border-t border-border/50 pt-4 space-y-4">

                            {/* Admin Override System */}
                            <div className="bg-purple-500/5 border border-purple-500/20 rounded-lg p-3">
                              <div className="text-xs font-semibold text-purple-400 uppercase tracking-wide mb-3">⚡ Advanced Override System</div>
                              <AdminOverridePanel
                                userEmail={u.email}
                                currentPlan={profile.subscription_plan || 'free'}
                                currentCredits={profile.ai_credits || 0}
                                adminEmail={user.email}
                              />
                              <div className="mt-3 pt-3 border-t border-purple-500/10">
                                <AdminOverrideLogsPanel userEmail={u.email} />
                              </div>
                            </div>

                            {/* Credits & Plan Override */}
                            <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                              <div className="text-xs font-semibold text-primary uppercase tracking-wide mb-3 flex items-center gap-1"><Star className="w-3 h-3" /> Subscription & Credits Override</div>
                              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 items-end">
                                <div className="md:col-span-1">
                                  <label className="text-xs font-medium mb-1 block">AI Credits</label>
                                  <div className="flex gap-1">
                                    <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: Math.max(0, (Number(c[profile.id]) || 0) - 10) }))}>
                                      <Minus className="w-3 h-3" />
                                    </Button>
                                    <Input
                                      type="number"
                                      value={editCredits[profile.id] ?? ''}
                                      onChange={e => setEditCredits(c => ({ ...c, [profile.id]: e.target.value }))}
                                      className="h-8 text-sm text-center"
                                    />
                                    <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: (Number(c[profile.id]) || 0) + 10 }))}>
                                      <Plus className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </div>
                                <div>
                                  <label className="text-xs font-medium mb-1 block">Add Credits</label>
                                  <div className="flex gap-1">
                                    {[25, 50, 100].map(n => (
                                      <Button key={n} size="sm" variant="outline" className="h-8 text-xs px-2 text-primary border-primary/30" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: (Number(c[profile.id]) || 0) + n }))}>
                                        +{n}
                                      </Button>
                                    ))}
                                  </div>
                                </div>
                                <div>
                                  <label className="text-xs font-medium mb-1 block">Plan</label>
                                  <Select value={editPlan[profile.id] || 'free'} onValueChange={v => setEditPlan(p => ({ ...p, [profile.id]: v }))}>
                                    <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="free">Free</SelectItem>
                                      <SelectItem value="pro">Pro</SelectItem>
                                      <SelectItem value="elite">Elite</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <Button size="sm" onClick={() => updateProfile(profile.id)} className="bg-primary text-primary-foreground gap-1 h-8">
                                  <Save className="w-3 h-3" /> Save
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => resetUsage(profile.id)} className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10 gap-1 h-8">
                                  <RefreshCw className="w-3 h-3" /> Reset Usage
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => deleteUser(profile.id)} className="border-destructive text-destructive hover:bg-destructive/10 gap-1 h-8">
                                  <Trash2 className="w-3 h-3" /> Delete
                                </Button>
                                </div>
                                </div>

                                {/* Full Profile Details */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                              {/* Personal Info */}
                              <div className="space-y-2">
                                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Personal Info</div>
                                <div className="flex items-center gap-2 text-sm"><Users className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Name:</span> <span>{profile.full_name || '—'}</span></div>
                                <div className="flex items-center gap-2 text-sm"><Mail className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Email:</span> <span>{profile.email || u.email || '—'}</span></div>
                                <div className="flex items-center gap-2 text-sm"><Phone className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Phone:</span> <span>{profile.phone || '—'}</span></div>
                                <div className="flex items-center gap-2 text-sm"><MapPin className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Location:</span> <span>{profile.location || '—'}</span></div>
                                {profile.linkedin_url && <div className="flex items-center gap-2 text-sm"><ExternalLink className="w-3.5 h-3.5 text-muted-foreground" /><a href={profile.linkedin_url} target="_blank" rel="noreferrer" className="text-primary hover:underline truncate">{profile.linkedin_url}</a></div>}
                                {profile.portfolio_url && <div className="flex items-center gap-2 text-sm"><ExternalLink className="w-3.5 h-3.5 text-muted-foreground" /><a href={profile.portfolio_url} target="_blank" rel="noreferrer" className="text-primary hover:underline truncate">{profile.portfolio_url}</a></div>}
                              </div>

                              {/* Stats */}
                              <div className="space-y-2">
                                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Account Stats</div>
                                <div className="flex items-center gap-2 text-sm"><Star className="w-3.5 h-3.5 text-primary" /><span className="text-muted-foreground">Plan:</span> <Badge className={profile.subscription_plan === 'elite' ? 'bg-purple-500/20 text-purple-300 text-xs' : profile.subscription_plan === 'pro' ? 'bg-primary/20 text-primary text-xs' : 'bg-secondary text-secondary-foreground text-xs'}>{profile.subscription_plan || 'free'}</Badge></div>
                                <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">AI Credits:</span> <span className="font-bold text-primary">{profile.ai_credits ?? 0}</span></div>
                                <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">Monthly Uses:</span> <span>{profile.monthly_uses ?? 0}</span></div>
                                <div className="flex items-center gap-2 text-sm"><FileText className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Resumes:</span> <span>{resumes.filter(r => r.created_by === u.email).length}</span></div>
                                <div className="flex items-center gap-2 text-sm"><Briefcase className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Applications:</span> <span>{applications.filter(a => a.created_by === u.email).length}</span></div>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground"><span>Joined:</span> <span>{profile.created_date ? new Date(profile.created_date).toLocaleDateString() : '—'}</span></div>
                              </div>
                            </div>

                            {/* Skills & Summary */}
                            {(profile.professional_summary || profile.skills) && (
                              <div className="border-t border-border/50 pt-3 space-y-3">
                                {profile.professional_summary && (
                                  <div>
                                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Professional Summary</div>
                                    <p className="text-sm text-foreground/80 leading-relaxed">{profile.professional_summary}</p>
                                  </div>
                                )}
                                {profile.skills && (
                                  <div>
                                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Skills</div>
                                    <p className="text-sm text-foreground/80">{profile.skills}</p>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Experience */}
                            {profile.experience?.length > 0 && (
                              <div className="border-t border-border/50 pt-3">
                                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1"><Briefcase className="w-3 h-3" /> Experience ({profile.experience.length})</div>
                                <div className="space-y-2">
                                  {profile.experience.map((exp, i) => (
                                    <div key={i} className="text-sm bg-secondary/20 rounded p-2">
                                      <div className="font-medium">{exp.job_title} <span className="text-muted-foreground">@ {exp.company}</span></div>
                                      <div className="text-xs text-muted-foreground">{exp.start_date} — {exp.current ? 'Present' : exp.end_date}</div>
                                      {exp.description && <div className="text-xs text-foreground/70 mt-1">{exp.description.slice(0, 120)}{exp.description.length > 120 ? '...' : ''}</div>}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Education */}
                            {profile.education?.length > 0 && (
                              <div className="border-t border-border/50 pt-3">
                                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1"><GraduationCap className="w-3 h-3" /> Education ({profile.education.length})</div>
                                <div className="space-y-2">
                                  {profile.education.map((edu, i) => (
                                    <div key={i} className="text-sm bg-secondary/20 rounded p-2">
                                      <div className="font-medium">{edu.degree} in {edu.field}</div>
                                      <div className="text-muted-foreground">{edu.school} • {edu.graduation_year}</div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                          </div>
                        ) : (
                          <div className="text-sm text-muted-foreground border-t border-border/50 pt-3">No UserProfile record for this user yet.</div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
                  </div>
                </div>
              )}

              {/* Profile-only records (imported from Stripe, no app account yet) */}
              {(() => {
                const userEmails = new Set(users.map(u => u.email?.toLowerCase()));
                const orphanProfiles = profiles.filter(p => {
                  const email = (p.email || p.created_by || '').toLowerCase();
                  return email && !userEmails.has(email);
                });
                if (orphanProfiles.length === 0) return null;
                return (
                  <div>
                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 px-1">Stripe Imported Profiles — No App Account Yet ({orphanProfiles.length})</div>
                    <div className="space-y-2">
                      {orphanProfiles.map(profile => {
                        const rowId = `profile-${profile.id}`;
                        const isExpanded = expandedUser === rowId;
                        return (
                          <div key={profile.id} className="border border-border border-dashed rounded-lg overflow-hidden">
                            <div
                              className="flex items-center gap-3 p-3 cursor-pointer hover:bg-secondary/30"
                              onClick={() => setExpandedUser(isExpanded ? null : rowId)}
                            >
                              <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center text-sm font-bold text-blue-400 shrink-0">
                                {profile.full_name?.charAt(0) || profile.email?.charAt(0) || '?'}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium text-sm">{profile.full_name || profile.email || 'Unknown'}</span>
                                  <Badge className="bg-blue-500/20 text-blue-300 text-xs">Stripe Import</Badge>
                                  <Badge className={profile.subscription_plan === 'elite' ? 'bg-purple-500/20 text-purple-300 text-xs' : profile.subscription_plan === 'pro' ? 'bg-primary/20 text-primary text-xs' : 'bg-secondary text-secondary-foreground text-xs'}>
                                    {profile.subscription_plan || 'free'}
                                  </Badge>
                                </div>
                                <div className="text-xs text-muted-foreground">{profile.email || '—'}</div>
                              </div>
                              <div className="text-xs text-muted-foreground shrink-0">{profile.ai_credits ?? 0} credits</div>
                              <Button
                                size="sm"
                                variant="outline"
                                className="gap-1 h-7 text-xs border-blue-500/50 text-blue-400 hover:bg-blue-500/10 shrink-0"
                                onClick={(e) => { e.stopPropagation(); inviteUser(profile.email, profile.id); }}
                                disabled={inviting[profile.id] || !profile.email}
                              >
                                {inviting[profile.id] ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                                {inviting[profile.id] ? 'Sending...' : 'Invite to App'}
                              </Button>
                              {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                            </div>
                            {isExpanded && (
                              <div className="border-t border-border bg-secondary/10 p-4 space-y-4">
                                {/* Credits & Plan Override */}
                                <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
                                  <div className="text-xs font-semibold text-primary uppercase tracking-wide mb-3 flex items-center gap-1"><Star className="w-3 h-3" /> Subscription & Credits Override</div>
                                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 items-end">
                                    <div className="md:col-span-1">
                                      <label className="text-xs font-medium mb-1 block">AI Credits</label>
                                      <div className="flex gap-1">
                                        <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: Math.max(0, (Number(c[profile.id]) || 0) - 10) }))}><Minus className="w-3 h-3" /></Button>
                                        <Input type="number" value={editCredits[profile.id] ?? ''} onChange={e => setEditCredits(c => ({ ...c, [profile.id]: e.target.value }))} className="h-8 text-sm text-center" />
                                        <Button size="sm" variant="outline" className="h-8 w-8 p-0" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: (Number(c[profile.id]) || 0) + 10 }))}><Plus className="w-3 h-3" /></Button>
                                      </div>
                                    </div>
                                    <div>
                                      <label className="text-xs font-medium mb-1 block">Add Credits</label>
                                      <div className="flex gap-1">
                                        {[25, 50, 100].map(n => (
                                          <Button key={n} size="sm" variant="outline" className="h-8 text-xs px-2 text-primary border-primary/30" onClick={() => setEditCredits(c => ({ ...c, [profile.id]: (Number(c[profile.id]) || 0) + n }))}>+{n}</Button>
                                        ))}
                                      </div>
                                    </div>
                                    <div>
                                      <label className="text-xs font-medium mb-1 block">Plan</label>
                                      <Select value={editPlan[profile.id] || 'free'} onValueChange={v => setEditPlan(p => ({ ...p, [profile.id]: v }))}>
                                        <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="free">Free</SelectItem>
                                          <SelectItem value="pro">Pro</SelectItem>
                                          <SelectItem value="elite">Elite</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    <Button size="sm" onClick={() => updateProfile(profile.id)} className="bg-primary text-primary-foreground gap-1 h-8"><Save className="w-3 h-3" /> Save</Button>
                                    <Button size="sm" variant="outline" onClick={() => resetUsage(profile.id)} className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10 gap-1 h-8"><RefreshCw className="w-3 h-3" /> Reset Usage</Button>
                                    <Button size="sm" variant="outline" onClick={() => deleteUser(profile.id)} className="border-destructive text-destructive hover:bg-destructive/10 gap-1 h-8"><Trash2 className="w-3 h-3" /> Delete</Button>
                                  </div>
                                </div>
                                {/* Personal Info */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Personal Info</div>
                                    <div className="flex items-center gap-2 text-sm"><Mail className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Email:</span> <span>{profile.email || '—'}</span></div>
                                    <div className="flex items-center gap-2 text-sm"><Phone className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Phone:</span> <span>{profile.phone || '—'}</span></div>
                                    <div className="flex items-center gap-2 text-sm"><MapPin className="w-3.5 h-3.5 text-muted-foreground" /><span className="text-muted-foreground">Location:</span> <span>{profile.location || '—'}</span></div>
                                  </div>
                                  <div className="space-y-2">
                                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Account Stats</div>
                                    <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">Plan:</span> <Badge className={profile.subscription_plan === 'elite' ? 'bg-purple-500/20 text-purple-300 text-xs' : profile.subscription_plan === 'pro' ? 'bg-primary/20 text-primary text-xs' : 'bg-secondary text-secondary-foreground text-xs'}>{profile.subscription_plan || 'free'}</Badge></div>
                                    <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">AI Credits:</span> <span className="font-bold text-primary">{profile.ai_credits ?? 0}</span></div>
                                    <div className="flex items-center gap-2 text-sm text-muted-foreground"><span>Imported:</span> <span>{profile.created_date ? new Date(profile.created_date).toLocaleDateString() : '—'}</span></div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {users.length === 0 && profiles.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No users found.</p>}
            </div>
          )}
        </CardContent>
      </Card>}
    </div>
  );
}