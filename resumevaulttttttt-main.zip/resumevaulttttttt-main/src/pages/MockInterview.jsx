import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Mic, ChevronDown, ChevronUp, Sparkles, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '@/components/PageHeader';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import PlanGate from '@/components/PlanGate';

export default function MockInterview() {
  const { canUse, incrementUsage, plan, getUsage, profile } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState({});

  const generate = async () => {
    if (!canUse('mock_interview')) return;
    setLoading(true);
    setQuestions([]);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate 8 realistic interview questions for a ${jobTitle} role${jobDescription ? ` based on this job description: ${jobDescription}` : ''}. 
For each question, also provide a model answer.
Return as JSON array with objects: { question: string, model_answer: string, type: string (e.g. "Behavioral", "Technical", "Situational") }`,
      response_json_schema: {
        type: 'object',
        properties: {
          questions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                question: { type: 'string' },
                model_answer: { type: 'string' },
                type: { type: 'string' },
              },
            },
          },
        },
      },
    });
    setQuestions(res?.questions || []);
    await incrementUsage('mock_interview');
    setLoading(false);
  };

  const toggle = (i) => setExpanded(e => ({ ...e, [i]: !e[i] }));

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={Mic} title="Interview Coach" subtitle="Practice with AI-generated interview questions and model answers" />

      <Card className="bg-card border-border mb-6">
        <CardContent className="pt-6 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Job Title *</label>
              <Input value={jobTitle} onChange={e => setJobTitle(e.target.value)} placeholder="e.g. Product Manager" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Job Description (optional)</label>
              <Textarea value={jobDescription} onChange={e => setJobDescription(e.target.value)} placeholder="Paste job description for tailored questions..." className="h-24 resize-none" />
            </div>
          </div>
          <PlanGate feature="mock_interview" canUse={canUse('mock_interview')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !jobTitle} className="gap-2">
              <Sparkles className="w-4 h-4" />
              {loading ? 'Generating Questions...' : 'Generate Interview Questions'}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {questions.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-white font-semibold text-sm mb-3">Interview Questions ({questions.length})</h2>
          {questions.map((q, i) => (
            <Card key={i} className="bg-card border-border">
              <button className="w-full text-left" onClick={() => toggle(i)}>
                <CardHeader className="py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <span className="text-primary font-bold text-sm shrink-0">Q{i + 1}</span>
                      <div className="min-w-0">
                        <span className="text-xs text-primary bg-primary/10 rounded px-2 py-0.5 mr-2">{q.type}</span>
                        <span className="text-white text-sm font-medium">{q.question}</span>
                      </div>
                    </div>
                    {expanded[i] ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
                  </div>
                </CardHeader>
              </button>
              {expanded[i] && (
                <CardContent className="pt-0 pb-4">
                  <div className="border-t border-border pt-4">
                    <p className="text-xs text-primary font-semibold mb-2">Model Answer:</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{q.model_answer}</p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
          <Button variant="outline" size="sm" onClick={generate} className="gap-2 mt-2">
            <RefreshCw className="w-3 h-3" /> Regenerate Questions
          </Button>
        </div>
      )}
    </div>
  );
}