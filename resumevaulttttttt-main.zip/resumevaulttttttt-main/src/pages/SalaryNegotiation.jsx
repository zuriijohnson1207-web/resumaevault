import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { DollarSign, Zap, Copy } from 'lucide-react';
import PlanGate from '@/components/PlanGate';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '@/components/PageHeader';

export default function SalaryNegotiation() {
  const { plan, canUse, getUsage, incrementUsage, profile } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [offer, setOffer] = useState('');
  const [target, setTarget] = useState('');
  const [experience, setExperience] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const generate = async () => {
    if (!canUse('salary_negotiation')) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Create professional salary negotiation scripts and strategy for:
Job Title: ${jobTitle}
Current Offer: ${offer}
Target Salary: ${target}
Years of Experience: ${experience}
Location: ${location}

Provide:
1. Initial counter-offer email script
2. Phone/verbal negotiation talking points (5 bullet points)
3. Response if they push back
4. Benefits negotiation tips (if salary is firm)
5. Market research talking points`,
      response_json_schema: {
        type: 'object',
        properties: {
          email_script: { type: 'string' },
          talking_points: { type: 'array', items: { type: 'string' } },
          pushback_response: { type: 'string' },
          benefits_tips: { type: 'array', items: { type: 'string' } },
          market_points: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    await incrementUsage('salary_negotiation');
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={DollarSign} title="Salary Negotiation Scripts" subtitle="Get professional, ready-to-send negotiation scripts and strategies" />

      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Job Title</label>
              <Input placeholder="e.g. Senior Software Engineer" value={jobTitle} onChange={e => setJobTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Current Offer</label>
              <Input placeholder="e.g. $120,000" value={offer} onChange={e => setOffer(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Target Salary</label>
              <Input placeholder="e.g. $145,000" value={target} onChange={e => setTarget(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Years of Experience</label>
              <Input placeholder="e.g. 7 years" value={experience} onChange={e => setExperience(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Location</label>
              <Input placeholder="e.g. San Francisco, CA" value={location} onChange={e => setLocation(e.target.value)} />
            </div>
          </div>
          <PlanGate feature="salary_negotiation" canUse={canUse('salary_negotiation')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !jobTitle.trim()} className="bg-primary text-primary-foreground gap-2">
              {loading ? <><Zap className="w-4 h-4 animate-spin" /> Generating...</> : <><DollarSign className="w-4 h-4" /> Generate Negotiation Scripts</>}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center justify-between">
                📧 Counter-Offer Email Script
                <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(result.email_script)} className="gap-1 text-xs">
                  <Copy className="w-3 h-3" /> Copy
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="whitespace-pre-wrap text-sm bg-secondary/30 rounded-lg p-3">{result.email_script}</div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">🗣️ Talking Points</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.talking_points?.map((p, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-primary mt-0.5 font-bold">{i + 1}.</span>{p}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">💼 Benefits Negotiation</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.benefits_tips?.map((t, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 mt-1.5 shrink-0" />{t}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">🔄 If They Push Back</CardTitle></CardHeader>
            <CardContent>
              <div className="whitespace-pre-wrap text-sm bg-secondary/30 rounded-lg p-3">{result.pushback_response}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">📊 Market Research Points</CardTitle></CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.market_points?.map((p, i) => (
                  <li key={i} className="text-sm flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 shrink-0" />{p}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}