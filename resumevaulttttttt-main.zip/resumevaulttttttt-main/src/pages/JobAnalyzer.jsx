import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Zap, Copy, CheckCircle } from 'lucide-react';
import PlanGate from '@/components/PlanGate';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/PageHeader';
import MotivationBanner from '@/components/MotivationBanner';

export default function JobAnalyzer() {
  const { plan, canUse, getUsage, incrementUsage, profile } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [jobDesc, setJobDesc] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);

  const analyze = async () => {
    if (!jobDesc.trim() || !canUse('job_analysis')) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze this job description and extract:
1. Top 15 ATS keywords (most important for applicant tracking systems)
2. Required skills (list)
3. Nice-to-have skills (list)
4. Key responsibilities (3-5 bullet points)
5. Company culture insights (2-3 sentences)
6. Suggested resume headline for this role

Job Title: ${jobTitle || 'Not specified'}
Company: ${company || 'Not specified'}
Job Description: ${jobDesc}`,
      response_json_schema: {
        type: 'object',
        properties: {
          ats_keywords: { type: 'array', items: { type: 'string' } },
          required_skills: { type: 'array', items: { type: 'string' } },
          nice_to_have: { type: 'array', items: { type: 'string' } },
          responsibilities: { type: 'array', items: { type: 'string' } },
          culture_insights: { type: 'string' },
          resume_headline: { type: 'string' },
        }
      }
    });
    await incrementUsage('job_analysis');
    setResult(res);
    setLoading(false);
  };

  const copyKeywords = () => {
    if (result?.ats_keywords) {
      navigator.clipboard.writeText(result.ats_keywords.join(', '));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={Search} title="Job Analyzer" subtitle="Paste a job description to extract ATS keywords and get strategic insights" />
      <MotivationBanner />

      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Job Title</label>
              <Input placeholder="e.g. Senior Product Manager" value={jobTitle} onChange={e => setJobTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Company</label>
              <Input placeholder="e.g. Google" value={company} onChange={e => setCompany(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Job Description</label>
            <Textarea
              placeholder="Paste the full job description here..."
              value={jobDesc}
              onChange={e => setJobDesc(e.target.value)}
              className="min-h-[200px]"
            />
          </div>
          <PlanGate feature="job_analysis" canUse={canUse('job_analysis')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={analyze} disabled={loading || !jobDesc.trim()} className="bg-primary text-primary-foreground gap-2">
              {loading ? <><Zap className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Search className="w-4 h-4" /> Step 1: Analyze Job</>}
            </Button>
          </PlanGate>
          <p className="text-xs text-muted-foreground">Analyze the job first to extract keywords and requirements</p>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-4">
          {/* ATS Keywords */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center justify-between">
                🎯 Top ATS Keywords
                <Button size="sm" variant="outline" onClick={copyKeywords} className="gap-1 text-xs">
                  {copied ? <CheckCircle className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  {copied ? 'Copied!' : 'Copy All'}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {result.ats_keywords?.map((kw, i) => (
                  <Badge key={i} className="bg-primary/20 text-primary border border-primary/30">{kw}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Resume Headline */}
          {result.resume_headline && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">✍️ Suggested Resume Headline</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm italic text-foreground bg-secondary/50 rounded-lg p-3">"{result.resume_headline}"</p>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Required Skills */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">✅ Required Skills</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {result.required_skills?.map((s, i) => (
                    <li key={i} className="text-sm flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 shrink-0" />
                      {s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Nice to Have */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">⭐ Nice to Have</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {result.nice_to_have?.map((s, i) => (
                    <li key={i} className="text-sm flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                      {s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Responsibilities */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-base">📋 Key Responsibilities</CardTitle></CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.responsibilities?.map((r, i) => (
                  <li key={i} className="text-sm flex items-start gap-2">
                    <span className="text-primary mt-0.5">•</span>
                    {r}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Culture */}
          {result.culture_insights && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">🏢 Culture Insights</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{result.culture_insights}</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}