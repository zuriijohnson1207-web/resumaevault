import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Send, Zap, Copy } from 'lucide-react';
import PlanGate from '@/components/PlanGate';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';

export default function FollowUpEmail() {
  const { plan, canUse, getUsage, incrementUsage, profile } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [recipient, setRecipient] = useState('');
  const [emailType, setEmailType] = useState('post_application');
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');

  const typeLabels = {
    post_application: 'Post-Application Follow-Up',
    post_interview: 'Post-Interview Thank You',
    networking: 'Networking Outreach',
    referral_request: 'Referral Request',
  };

  const generate = async () => {
    if (!canUse('follow_up_email')) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a professional ${typeLabels[emailType]} email for:
Job Title: ${jobTitle}
Company: ${company}
Recipient: ${recipient || 'Hiring Manager'}
Additional context: ${context}

Keep it concise (under 200 words), polite, and action-oriented. Include subject line.`
    });
    await incrementUsage('follow_up_email');
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={Send} title="Follow-Up Email" subtitle="Craft professional follow-up emails that get responses" />
      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Job Title</label>
              <Input placeholder="e.g. Software Engineer" value={jobTitle} onChange={e => setJobTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Company</label>
              <Input placeholder="e.g. Google" value={company} onChange={e => setCompany(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Recipient Name (optional)</label>
              <Input placeholder="e.g. Jane Smith" value={recipient} onChange={e => setRecipient(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Email Type</label>
              <Select value={emailType} onValueChange={setEmailType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(typeLabels).map(([v, l]) => (
                    <SelectItem key={v} value={v}>{l}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Additional Context (optional)</label>
            <Textarea placeholder="e.g. Interviewed last Tuesday, met with Sarah from HR..." value={context} onChange={e => setContext(e.target.value)} className="min-h-[100px]" />
          </div>
          <PlanGate feature="follow_up_email" canUse={canUse('follow_up_email')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !jobTitle.trim()} className="bg-primary text-primary-foreground gap-2">
              {loading ? <><Zap className="w-4 h-4 animate-spin" /> Generating...</> : 'Generate Email'}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Your Follow-Up Email</h3>
              <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(result)} className="gap-1 text-xs">
                <Copy className="w-3 h-3" /> Copy
              </Button>
            </div>
            <div className="whitespace-pre-wrap text-sm bg-secondary/30 rounded-lg p-4">{result}</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}