import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Map, Zap } from 'lucide-react';
import PlanGate from '@/components/PlanGate';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/PageHeader';

export default function CareerRoadmap() {
  const { plan, canUse, getUsage, incrementUsage, profile } = usePlanLimits();
  const [current, setCurrent] = useState('');
  const [goal, setGoal] = useState('');
  const [timeline, setTimeline] = useState('');
  const [skills, setSkills] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const generate = async () => {
    if (!canUse('career_roadmap')) return;
    setLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Create a detailed career roadmap:
Current Role/Level: ${current}
Goal Role/Title: ${goal}
Timeline: ${timeline || '12-18 months'}
Current Skills: ${skills}

Provide a structured roadmap with:
1. Phase-by-phase plan (3-4 phases with timeframes)
2. Skills to develop for each phase
3. Resources/certifications to pursue
4. Milestones to hit
5. Networking strategy`,
      response_json_schema: {
        type: 'object',
        properties: {
          phases: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                timeframe: { type: 'string' },
                goals: { type: 'array', items: { type: 'string' } },
                skills: { type: 'array', items: { type: 'string' } },
                resources: { type: 'array', items: { type: 'string' } },
              }
            }
          },
          networking_strategy: { type: 'string' },
          key_milestones: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    await incrementUsage('career_roadmap');
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={Map} title="Career Roadmap" subtitle="Step-by-step plan to reach your career goals" />

      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Current Role/Level</label>
              <Input placeholder="e.g. Junior Software Engineer, 2 years exp" value={current} onChange={e => setCurrent(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Goal Role/Title</label>
              <Input placeholder="e.g. Senior Engineering Manager" value={goal} onChange={e => setGoal(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Timeline</label>
              <Input placeholder="e.g. 18 months, 2 years" value={timeline} onChange={e => setTimeline(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Current Skills</label>
              <Input placeholder="e.g. React, Node.js, Python" value={skills} onChange={e => setSkills(e.target.value)} />
            </div>
          </div>
          <PlanGate feature="career_roadmap" canUse={canUse('career_roadmap')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !current.trim() || !goal.trim()} className="bg-primary text-primary-foreground gap-2">
              {loading ? <><Zap className="w-4 h-4 animate-spin" /> Generating...</> : <><Map className="w-4 h-4" /> Generate Roadmap</>}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-4">
          {/* Key Milestones */}
          {result.key_milestones?.length > 0 && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">🏆 Key Milestones</CardTitle></CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {result.key_milestones.map((m, i) => (
                    <Badge key={i} className="bg-primary/20 text-primary border border-primary/30">{m}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Phases */}
          {result.phases?.map((phase, i) => (
            <Card key={i} className="border-l-4 border-l-primary">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold shrink-0">{i + 1}</span>
                  {phase.title}
                  {phase.timeframe && <Badge className="bg-secondary text-secondary-foreground ml-auto">{phase.timeframe}</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {phase.goals?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Goals</p>
                    <ul className="space-y-1">
                      {phase.goals.map((g, j) => <li key={j} className="text-sm flex items-start gap-2"><span className="text-primary mt-0.5">•</span>{g}</li>)}
                    </ul>
                  </div>
                )}
                {phase.skills?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Skills to Develop</p>
                    <div className="flex flex-wrap gap-1">
                      {phase.skills.map((s, j) => <Badge key={j} className="text-xs bg-blue-500/20 text-blue-300">{s}</Badge>)}
                    </div>
                  </div>
                )}
                {phase.resources?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Resources & Certifications</p>
                    <ul className="space-y-1">
                      {phase.resources.map((r, j) => <li key={j} className="text-xs text-muted-foreground flex items-start gap-2"><span className="text-green-400">→</span>{r}</li>)}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}

          {result.networking_strategy && (
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">🤝 Networking Strategy</CardTitle></CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{result.networking_strategy}</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}