import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Zap, FileText, Search, Mail, BarChart2, Star, Check, ArrowRight, Shield, Mic, DollarSign, Map, Lightbulb, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const features = [
  { icon: Search, title: 'ATS Job Analyzer', desc: 'Paste any job description and instantly extract keywords to beat ATS filters.' },
  { icon: FileText, title: 'AI Resume Builder', desc: 'Generate perfectly tailored resumes in seconds — matched to the exact job.' },
  { icon: Mail, title: 'Cover Letter Generator', desc: 'Write compelling, personalized cover letters that get noticed.' },
  { icon: Send, title: 'Auto Apply', desc: 'Find and apply to matching jobs automatically with your AI profile.' },
  { icon: Mic, title: 'Mock Interview Coach', desc: 'Practice with AI-generated interview questions specific to your role.' },
  { icon: DollarSign, title: 'Salary Negotiation', desc: 'Get ready-to-use scripts to confidently negotiate your dream salary.' },
  { icon: Map, title: 'Career Roadmap', desc: 'Get a step-by-step personalized plan to reach your career goals.' },
  { icon: BarChart2, title: 'Application Tracker', desc: 'Track every application, interview, and offer in one clean dashboard.' },
];

const testimonials = [
  { name: 'Jessica M.', role: 'Software Engineer', text: 'I landed 3 interviews in my first week using ResumeVault. The ATS optimizer is absolutely insane.', stars: 5 },
  { name: 'Marcus T.', role: 'Marketing Manager', text: 'Got my dream job at a Fortune 500 company. The tailored resumes are next level.', stars: 5 },
  { name: 'Priya K.', role: 'Data Analyst', text: 'From 0 callbacks to 5 interviews in 2 weeks. This tool is a game changer.', stars: 5 },
];

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: '/mo',
    features: ['2 AI Resumes/mo', '2 Cover Letters/mo', '2 Job Analyses/mo', 'Basic Dashboard'],
    cta: 'Get Started Free',
    highlight: false,
  },
  {
    name: 'Pro',
    price: '$29.99',
    period: '/mo',
    features: ['80 AI Resumes/mo', 'Unlimited Cover Letters', '20 Mock Interviews', '50 Auto-Applies/mo', 'Salary Scripts', 'Career Roadmap'],
    cta: 'Start Pro',
    highlight: true,
  },
  {
    name: 'Elite',
    price: '$79.99',
    period: '/mo',
    features: ['150 AI Resumes/mo', 'Unlimited Everything', '200 Auto-Applies/mo', 'Career Coaching', 'Priority Support', 'Portfolio Builder'],
    cta: 'Go Elite',
    highlight: false,
  },
];

export default function Landing() {
  const handleLogin = () => {
    window.location.href = '/auth';
  };

  const handleGoogleSignup = () => {
    window.location.href = '/auth';
  };

  // If user is already authenticated, redirect to dashboard
  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (authed) window.location.href = '/';
    });
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <div>
              <div className="font-bold text-sm leading-tight">ResumeVault</div>
              <div className="text-xs text-primary font-semibold leading-tight">GOD-MODE JOB HUNT</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={handleLogin}>Log In</Button>
            <Button size="sm" onClick={handleLogin} className="bg-primary text-primary-foreground">
              Get Started Free
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge className="bg-primary/10 text-primary border border-primary/20 mb-4">⚡ Beat the ATS in 60 Seconds</Badge>
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
            Land Your <span className="text-primary">Dream Job</span><br />in God Mode
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            ResumeVaultGodAI uses cutting-edge AI to tailor your resume, crush ATS filters, write cover letters, and auto-apply — all in minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button size="lg" onClick={handleLogin} className="bg-primary text-primary-foreground text-base font-bold px-8 shadow-lg shadow-primary/20">
              Start For Free <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
            <Button size="lg" variant="outline" onClick={handleGoogleSignup} className="text-base font-semibold px-8 border-border">
              Sign In with Google
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">No credit card required • Free plan available • Cancel anytime</p>
        </div>

        {/* Hero visual */}
        <div className="max-w-5xl mx-auto mt-16 rounded-2xl overflow-hidden border border-border shadow-2xl shadow-primary/10 bg-card">
          <div className="bg-secondary/50 px-4 py-3 flex items-center gap-2 border-b border-border">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="ml-3 text-xs text-muted-foreground font-mono">resumevaultgodai.app — Dashboard</span>
          </div>
          <div className="p-6 grid grid-cols-3 gap-4">
            <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 text-left">
              <Zap className="w-5 h-5 text-primary mb-2" />
              <div className="text-2xl font-bold text-primary">80</div>
              <div className="text-xs text-muted-foreground">AI Credits</div>
            </div>
            <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4 text-left">
              <BarChart2 className="w-5 h-5 text-green-400 mb-2" />
              <div className="text-2xl font-bold text-green-400">12</div>
              <div className="text-xs text-muted-foreground">Applications</div>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 text-left">
              <Star className="w-5 h-5 text-blue-400 mb-2" />
              <div className="text-2xl font-bold text-blue-400">5</div>
              <div className="text-xs text-muted-foreground">Interviews</div>
            </div>
            <div className="col-span-3 bg-secondary/50 rounded-xl p-4 text-left">
              <div className="text-xs text-primary font-bold mb-2">🤖 AI Resume Generated</div>
              <div className="text-sm text-muted-foreground">Tailored resume for <span className="text-foreground font-medium">Senior Software Engineer @ Google</span> — ATS Score: <span className="text-green-400 font-bold">94%</span></div>
            </div>
          </div>
        </div>
      </section>

      {/* Social proof */}
      <section className="py-10 border-y border-border bg-card/50">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="flex flex-col sm:flex-row gap-8 justify-center items-center">
            <div><div className="text-3xl font-bold text-primary">50,000+</div><div className="text-sm text-muted-foreground">Resumes Generated</div></div>
            <div className="hidden sm:block w-px h-10 bg-border"></div>
            <div><div className="text-3xl font-bold text-primary">89%</div><div className="text-sm text-muted-foreground">Interview Rate Increase</div></div>
            <div className="hidden sm:block w-px h-10 bg-border"></div>
            <div><div className="text-3xl font-bold text-primary">4.9★</div><div className="text-sm text-muted-foreground">Average Rating</div></div>
            <div className="hidden sm:block w-px h-10 bg-border"></div>
            <div><div className="text-3xl font-bold text-primary">72hrs</div><div className="text-sm text-muted-foreground">Avg. Time to Interview</div></div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-primary/10 text-primary border border-primary/20 mb-3">Everything You Need</Badge>
            <h2 className="text-4xl font-extrabold mb-3">Your Entire Job Search.<br />Powered by AI.</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Every tool you need to go from unemployed to employed — faster than ever before.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f) => (
              <div key={f.title} className="bg-card border border-border rounded-xl p-5 hover:border-primary/40 transition-colors">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="font-bold mb-1 text-sm">{f.title}</div>
                <div className="text-xs text-muted-foreground leading-relaxed">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6 bg-card/30">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-extrabold mb-3">Real Results. Real People.</h2>
            <p className="text-muted-foreground">Join thousands who've already landed their dream jobs.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="bg-card border border-border rounded-xl p-6">
                <div className="flex mb-3">
                  {Array.from({ length: t.stars }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-primary fill-primary" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">"{t.text}"</p>
                <div>
                  <div className="font-bold text-sm">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-primary/10 text-primary border border-primary/20 mb-3">Simple Pricing</Badge>
            <h2 className="text-4xl font-extrabold mb-3">Pick Your Power Level</h2>
            <p className="text-muted-foreground">Start free. Upgrade when you're ready to go God Mode.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`rounded-2xl border p-6 flex flex-col ${plan.highlight ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10 relative' : 'border-border bg-card'}`}
              >
                {plan.highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-3">Most Popular</Badge>
                  </div>
                )}
                <div className="mb-4">
                  <div className="font-bold text-lg mb-1">{plan.name}</div>
                  <div className="flex items-end gap-1">
                    <span className="text-4xl font-extrabold">{plan.price}</span>
                    <span className="text-muted-foreground mb-1">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-2 mb-6 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary shrink-0" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={handleLogin}
                  variant={plan.highlight ? 'default' : 'outline'}
                  className={`w-full font-bold ${plan.highlight ? 'bg-primary text-primary-foreground' : ''}`}
                >
                  {plan.cta}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-t border-border">
        <div className="max-w-3xl mx-auto text-center">
          <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-4xl font-extrabold mb-4">Ready to Job Hunt in God Mode?</h2>
          <p className="text-muted-foreground mb-8 text-lg">Join 50,000+ job seekers who are landing interviews faster with AI.</p>
          <Button size="lg" onClick={handleLogin} className="bg-primary text-primary-foreground text-base font-bold px-10 shadow-lg shadow-primary/20">
            Get Started Free — No Credit Card <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <Zap className="w-3 h-3 text-primary-foreground" />
            </div>
            <span className="font-bold text-sm">ResumeVaultGodAI</span>
          </div>
          <p className="text-xs text-muted-foreground">© 2026 ResumeVaultGodAI. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span className="cursor-pointer hover:text-foreground">Privacy</span>
            <span className="cursor-pointer hover:text-foreground">Terms</span>
            <span className="cursor-pointer hover:text-foreground">Contact</span>
          </div>
        </div>
      </footer>
    </div>
  );
}