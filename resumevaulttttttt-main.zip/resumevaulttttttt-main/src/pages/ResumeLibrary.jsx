import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import {
  BookOpen, Copy, Trash2, FileText, Search,
  ArrowUpDown, FileDown, CheckCircle2, Palette,
  Edit3, Save, X, ChevronLeft, Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/PageHeader';
import { toast } from 'sonner';
import { RESUME_TEMPLATES, getTemplateById } from '@/data/resumeTemplates';
import ThemedResumePreview from '@/components/resume/ThemedResumePreview';

const SORT_OPTIONS = [
  { value: 'newest', label: 'Newest First' },
  { value: 'oldest', label: 'Oldest First' },
  { value: 'title', label: 'Title A–Z' },
];

const TYPE_FILTERS = ['all', 'tailored', 'general', 'template'];

export default function ResumeLibrary() {
  const [resumes, setResumes] = useState([]);
  const [selected, setSelected] = useState(null);
  const [mobileDetailOpen, setMobileDetailOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sort, setSort] = useState('newest');
  const [copied, setCopied] = useState(false);
  const [showThemePicker, setShowThemePicker] = useState(false);
  const [savingTheme, setSavingTheme] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editContent, setEditContent] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [saving, setSaving] = useState(false);
  const [previewTemplateId, setPreviewTemplateId] = useState(null);

  const load = async () => {
    const data = await base44.entities.Resume.list('-created_date');
    setResumes(data);
    setSelected(prev => prev ? (data.find(r => r.id === prev.id) || null) : null);
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    await base44.entities.Resume.delete(id);
    if (selected?.id === id) { setSelected(null); setMobileDetailOpen(false); }
    load();
    toast.success('Resume deleted.');
  };

  const copy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadPDF = (r) => {
    const template = getTemplateById(previewTemplateId || r.template_id);
    const { theme } = template;
    const w = window.open('', '_blank');
    w.document.write(`<html><head><title>${r.title}</title>
    <style>body{font-family:${theme.font};font-size:11pt;margin:.75in;background:${theme.bg};color:${theme.text};line-height:1.5}pre{white-space:pre-wrap;font-family:${theme.font}}</style>
    </head><body><pre>${(r.content || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre></body></html>`);
    w.document.close();
    setTimeout(() => { w.print(); w.close(); }, 400);
  };

  const applyTheme = async (template, saveAsNew = false) => {
    if (!selected) return;
    setSavingTheme(true);
    if (saveAsNew) {
      await base44.entities.Resume.create({
        ...selected,
        id: undefined,
        created_date: undefined,
        updated_date: undefined,
        title: `${selected.title} (${template.name})`,
        template_id: template.id,
      });
      toast.success(`Saved as new copy with "${template.name}" template!`);
    } else {
      await base44.entities.Resume.update(selected.id, { template_id: template.id });
      setSelected(prev => ({ ...prev, template_id: template.id }));
      toast.success(`Template changed to "${template.name}"!`);
    }
    setSavingTheme(false);
    setShowThemePicker(false);
    setPreviewTemplateId(null);
    load();
  };

  const enterEdit = () => {
    setEditContent(selected.content || '');
    setEditTitle(selected.title || '');
    setEditMode(true);
    setShowThemePicker(false);
  };

  const saveEdits = async () => {
    setSaving(true);
    await base44.entities.Resume.update(selected.id, { title: editTitle, content: editContent });
    toast.success('Resume saved!');
    setSaving(false);
    setEditMode(false);
    await load();
  };

  const cancelEdit = () => {
    setEditMode(false);
    setEditContent('');
    setEditTitle('');
  };

  const openDetail = (r) => {
    setSelected(r);
    setEditMode(false);
    setShowThemePicker(false);
    setPreviewTemplateId(null);
    setMobileDetailOpen(true);
  };

  const filteredResumes = useMemo(() => {
    let list = [...resumes];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(r =>
        r.title?.toLowerCase().includes(q) ||
        r.job_title?.toLowerCase().includes(q) ||
        r.company?.toLowerCase().includes(q)
      );
    }
    if (typeFilter !== 'all') list = list.filter(r => r.type === typeFilter);
    if (sort === 'newest') list.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    else if (sort === 'oldest') list.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    else if (sort === 'title') list.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
    return list;
  }, [resumes, search, typeFilter, sort]);

  const typeColor = (t) => {
    if (t === 'tailored') return 'bg-primary/20 text-primary border-primary/30';
    if (t === 'general') return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    return 'bg-secondary text-secondary-foreground';
  };

  const currentTemplate = selected ? getTemplateById(selected.template_id) : null;

  // ── Mobile Detail Panel ──────────────────────────────────────────────────────
  const DetailPanel = () => (
    <div className="fixed inset-0 z-50 bg-background flex flex-col md:hidden overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-sidebar shrink-0">
        <button
          onClick={() => { setMobileDetailOpen(false); setEditMode(false); }}
          className="w-10 h-10 flex items-center justify-center rounded-xl bg-secondary text-foreground shrink-0"
          aria-label="Go back to resume list"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          {editMode
            ? <Input value={editTitle} onChange={e => setEditTitle(e.target.value)} className="h-9 text-sm font-semibold" placeholder="Resume title" />
            : <p className="font-bold text-sm text-foreground truncate">{selected?.title}</p>
          }
          <p className="text-xs text-muted-foreground">{currentTemplate?.icon} {currentTemplate?.name}</p>
        </div>
        <button
          onClick={e => { e.stopPropagation(); remove(selected?.id); }}
          className="w-10 h-10 flex items-center justify-center rounded-xl bg-destructive/10 text-destructive shrink-0"
          aria-label="Delete this resume"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Action row */}
      <div className="flex gap-2 px-4 py-3 border-b border-border bg-card/50 shrink-0 overflow-x-auto">
        {editMode ? (
          <>
            <Button onClick={saveEdits} disabled={saving} className="gap-2 h-11 flex-1 text-base font-bold">
              <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save Changes'}
            </Button>
            <Button variant="outline" onClick={cancelEdit} className="gap-2 h-11 px-4">
              <X className="w-4 h-4" /> Cancel
            </Button>
          </>
        ) : (
          <>
            <Button variant="outline" onClick={enterEdit} className="gap-2 h-11 flex-1 text-sm font-semibold">
              <Edit3 className="w-4 h-4" /> Edit
            </Button>
            <Button variant="outline" onClick={() => setShowThemePicker(v => !v)} className="gap-2 h-11 flex-1 text-sm font-semibold">
              <Palette className="w-4 h-4" /> Theme
            </Button>
            <Button variant="outline" onClick={() => copy(selected?.content)} className="gap-2 h-11 px-4">
              {copied ? <CheckCircle2 className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </Button>
            <Button onClick={() => downloadPDF(selected)} className="gap-2 h-11 flex-1 text-sm font-semibold">
              <Download className="w-4 h-4" /> PDF
            </Button>
          </>
        )}
      </div>

      {/* Theme picker */}
      {showThemePicker && !editMode && (
        <div className="px-4 py-3 border-b border-border bg-secondary/20 shrink-0">
          <p className="text-sm font-semibold mb-2 flex items-center gap-2">
            <Palette className="w-4 h-4 text-primary" /> Choose Template
          </p>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {RESUME_TEMPLATES.map(t => (
              <button key={t.id} onClick={() => setPreviewTemplateId(t.id)} disabled={savingTheme}
                className={`shrink-0 rounded-lg border-2 p-2 text-left transition-all w-24 ${(previewTemplateId || selected?.template_id) === t.id ? 'border-primary bg-primary/10' : 'border-border'}`}>
                <div className={`w-full h-8 rounded bg-gradient-to-br ${t.preview_color} flex items-center justify-center text-sm mb-1`}>{t.icon}</div>
                <p className="text-xs font-semibold leading-tight truncate">{t.name}</p>
              </button>
            ))}
          </div>
          {previewTemplateId && previewTemplateId !== selected?.template_id && (
            <div className="flex gap-2 mt-2">
              <Button size="sm" disabled={savingTheme} onClick={() => applyTheme(RESUME_TEMPLATES.find(t => t.id === previewTemplateId))} className="flex-1 h-10 text-sm">
                {savingTheme ? 'Saving...' : '✓ Apply Template'}
              </Button>
              <Button size="sm" variant="outline" disabled={savingTheme} onClick={() => applyTheme(RESUME_TEMPLATES.find(t => t.id === previewTemplateId), true)} className="flex-1 h-10 text-sm">
                Save as New
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {editMode ? (
          <Textarea
            value={editContent}
            onChange={e => setEditContent(e.target.value)}
            className="w-full h-full min-h-[60vh] font-mono text-xs leading-relaxed resize-none rounded-none border-0 focus-visible:ring-0 p-4"
            placeholder="Resume content..."
          />
        ) : (
          <div className="overflow-auto">
            <ThemedResumePreview content={selected?.content} templateId={previewTemplateId || selected?.template_id} />
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Mobile detail overlay */}
      {mobileDetailOpen && selected && <DetailPanel />}

      <PageHeader icon={BookOpen} title="Resume Library" subtitle="View, edit, and restyle your saved resumes" />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search resumes..." className="pl-9 h-11" />
        </div>
        <div className="flex gap-1 bg-secondary/30 rounded-lg p-1 overflow-x-auto">
          {TYPE_FILTERS.map(f => (
            <button key={f} onClick={() => setTypeFilter(f)}
              className={`px-3 py-2 rounded-md text-xs font-semibold capitalize transition-all whitespace-nowrap ${typeFilter === f ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
              {f}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <ArrowUpDown className="w-4 h-4 text-muted-foreground shrink-0" />
          <select value={sort} onChange={e => setSort(e.target.value)}
            className="text-sm bg-card border border-border rounded-lg px-3 py-2 h-11 text-foreground focus:outline-none focus:ring-2 focus:ring-primary w-full">
            {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {resumes.length > 0 && (
        <div className="text-sm text-muted-foreground mb-4">
          <span className="font-semibold text-foreground">{filteredResumes.length}</span> of {resumes.length} resumes
        </div>
      )}

      {resumes.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <FileText className="w-14 h-14 text-muted-foreground mx-auto mb-4 opacity-40" />
            <p className="font-semibold text-lg text-muted-foreground">No resumes saved yet</p>
            <p className="text-sm text-muted-foreground mt-1 mb-5">Generate a resume in the Resume Builder and save it here.</p>
            <Button className="gap-2 h-12 text-base px-6" onClick={() => window.location.href = '/resume-builder'}>
              <FileText className="w-5 h-5" /> Go to Resume Builder
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* ── Mobile: card list (tap to open full-screen detail) ── */}
          <div className="md:hidden space-y-3">
            {filteredResumes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border rounded-xl">
                No resumes match your search.
              </div>
            ) : (
              filteredResumes.map(r => {
                const tpl = getTemplateById(r.template_id);
                return (
                  <button
                    key={r.id}
                    onClick={() => openDetail(r)}
                    className="w-full text-left border rounded-2xl p-4 bg-card border-border hover:border-primary/50 active:scale-[0.98] transition-all shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-base text-foreground truncate">{r.title}</p>
                        {r.job_title && (
                          <p className="text-sm text-muted-foreground mt-0.5 truncate">{r.job_title}{r.company ? ` @ ${r.company}` : ''}</p>
                        )}
                      </div>
                      <Badge className={`text-xs border shrink-0 ${typeColor(r.type)}`}>{r.type}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">
                        {tpl.icon} {tpl.name} · {new Date(r.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                      <span className="text-xs text-primary font-semibold">Tap to open →</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* ── Desktop: side-by-side layout ── */}
          <div className="hidden md:grid md:grid-cols-3 gap-4">
            <div className="md:col-span-1 space-y-2">
              {filteredResumes.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-border rounded-xl">
                  No resumes match your search.
                </div>
              ) : (
                filteredResumes.map(r => {
                  const tpl = getTemplateById(r.template_id);
                  return (
                    <div key={r.id} onClick={() => { setSelected(r); setEditMode(false); setShowThemePicker(false); setPreviewTemplateId(null); }}
                      className={`border rounded-xl p-3.5 cursor-pointer transition-all hover:shadow-md ${selected?.id === r.id ? 'border-primary bg-primary/10 shadow-sm' : 'border-border hover:border-primary/40 bg-card'}`}>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate text-foreground">{r.title}</p>
                          {r.job_title && (
                            <p className="text-xs text-muted-foreground mt-0.5 truncate">{r.job_title}{r.company ? ` @ ${r.company}` : ''}</p>
                          )}
                        </div>
                        <Badge className={`text-xs border shrink-0 ${typeColor(r.type)}`}>{r.type}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-muted-foreground">
                            {new Date(r.created_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </p>
                          <span className="text-xs text-muted-foreground">{tpl.icon} {tpl.name}</span>
                        </div>
                        <button onClick={e => { e.stopPropagation(); remove(r.id); }}
                          className="text-muted-foreground hover:text-destructive transition-colors p-1 rounded">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="md:col-span-2">
              {selected ? (
                <Card className="border-primary/20">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div className="flex-1 min-w-0">
                        {editMode ? (
                          <Input value={editTitle} onChange={e => setEditTitle(e.target.value)} className="text-base font-semibold h-9" placeholder="Resume title" />
                        ) : (
                          <>
                            <CardTitle className="text-base">{selected.title}</CardTitle>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {currentTemplate?.icon} {currentTemplate?.name} theme · Saved {new Date(selected.created_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                            </p>
                          </>
                        )}
                      </div>
                      <div className="flex gap-1.5 flex-wrap">
                        {editMode ? (
                          <>
                            <Button size="sm" onClick={saveEdits} disabled={saving} className="gap-1 h-8 text-xs">
                              <Save className="w-3 h-3" /> {saving ? 'Saving...' : 'Save'}
                            </Button>
                            <Button size="sm" variant="outline" onClick={cancelEdit} className="gap-1 h-8 text-xs">
                              <X className="w-3 h-3" /> Cancel
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button size="sm" variant="outline" onClick={() => setShowThemePicker(!showThemePicker)} className="gap-1 h-8 text-xs">
                              <Palette className="w-3 h-3" /> Theme
                            </Button>
                            <Button size="sm" variant="outline" onClick={enterEdit} className="gap-1 h-8 text-xs">
                              <Edit3 className="w-3 h-3" /> Edit
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => copy(selected.content)} className="gap-1 h-8 text-xs">
                              {copied ? <CheckCircle2 className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                              {copied ? 'Copied!' : 'Copy'}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => downloadPDF(selected)} className="gap-1 h-8 text-xs">
                              <FileDown className="w-3 h-3" /> PDF
                            </Button>
                          </>
                        )}
                      </div>
                    </div>

                    {showThemePicker && !editMode && (
                      <div className="mt-4 p-4 bg-secondary/30 rounded-xl border border-border">
                        <p className="text-sm font-semibold mb-3 flex items-center gap-2">
                          <Palette className="w-4 h-4 text-primary" /> Choose a Template ({RESUME_TEMPLATES.length} styles)
                        </p>
                        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-52 overflow-y-auto pr-1 mb-3">
                          {RESUME_TEMPLATES.map(t => (
                            <button key={t.id} onClick={() => setPreviewTemplateId(t.id)} disabled={savingTheme}
                              className={`rounded-lg border-2 p-2 text-left transition-all hover:scale-105 ${(previewTemplateId || selected.template_id) === t.id ? 'border-primary bg-primary/10 shadow-md' : 'border-border hover:border-primary/50'}`}>
                              <div className={`w-full h-8 rounded bg-gradient-to-br ${t.preview_color} flex items-center justify-center text-sm mb-1`}>{t.icon}</div>
                              <p className="text-xs font-semibold leading-tight truncate">{t.name}</p>
                              <p className="text-xs text-muted-foreground leading-tight truncate">{t.category}</p>
                              {selected.template_id === t.id && !previewTemplateId && <span className="text-xs text-primary font-bold">✓ Active</span>}
                              {previewTemplateId === t.id && <span className="text-xs text-primary font-bold">● Previewing</span>}
                            </button>
                          ))}
                        </div>
                        {previewTemplateId && previewTemplateId !== selected.template_id && (
                          <div className="flex gap-2 flex-wrap">
                            <button onClick={() => { setPreviewTemplateId(null); }}
                              className="text-xs text-muted-foreground underline">Cancel preview</button>
                            <Button size="sm" disabled={savingTheme} onClick={() => applyTheme(RESUME_TEMPLATES.find(t => t.id === previewTemplateId))}
                              className="h-7 text-xs bg-primary text-primary-foreground">
                              {savingTheme ? 'Saving...' : '✓ Apply to this resume'}
                            </Button>
                            <Button size="sm" variant="outline" disabled={savingTheme} onClick={() => applyTheme(RESUME_TEMPLATES.find(t => t.id === previewTemplateId), true)}
                              className="h-7 text-xs">
                              Save as New Copy
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </CardHeader>

                  <CardContent>
                    {editMode ? (
                      <div>
                        <p className="text-xs text-muted-foreground mb-2">Edit your resume content below.</p>
                        <Textarea value={editContent} onChange={e => setEditContent(e.target.value)}
                          className="min-h-[60vh] font-mono text-xs leading-relaxed resize-none" placeholder="Resume content..." />
                      </div>
                    ) : (
                      <div className="max-h-[70vh] overflow-auto rounded-lg border border-border">
                        <ThemedResumePreview
                          content={selected.content}
                          templateId={previewTemplateId || selected.template_id}
                        />
                        {previewTemplateId && previewTemplateId !== selected.template_id && (
                          <div className="sticky bottom-0 bg-primary/90 text-primary-foreground text-xs px-3 py-2 flex items-center justify-between">
                            <span>Previewing: {RESUME_TEMPLATES.find(t => t.id === previewTemplateId)?.name}</span>
                            <button onClick={() => setPreviewTemplateId(null)} className="underline ml-3">Back to saved</button>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card className="h-full">
                  <CardContent className="flex flex-col items-center justify-center py-20 text-muted-foreground text-center gap-3">
                    <FileText className="w-12 h-12 opacity-20" />
                    <p className="text-sm font-medium">Select a resume to preview it</p>
                    <p className="text-xs">Click any resume from the list on the left</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}