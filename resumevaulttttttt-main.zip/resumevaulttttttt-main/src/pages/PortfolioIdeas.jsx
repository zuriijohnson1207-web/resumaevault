import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Lightbulb, Sparkles, ExternalLink, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/PageHeader';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import PlanGate from '@/components/PlanGate';

export default function PortfolioIdeas() {
  const { canUse, incrementUsage, plan, getUsage, profile } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [skills, setSkills] = useState('');
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState({});

  const generate = async () => {
    if (!canUse('portfolio_ideas')) return;
    setLoading(true);
    setIdeas([]);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate 6 impressive portfolio project ideas for a ${jobTitle}${skills ? ` with skills: ${skills}` : ''}.
Each idea should be something a hiring manager would actually be impressed by.
Return JSON array of objects: { title: string, description: string, tech_stack: string[], difficulty: "Beginner"|"Intermediate"|"Advanced", impact: string, resources: string[] }`,
      response_json_schema: {
        type: 'object',
        properties: {
          ideas: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                tech_stack: { type: 'array', items: { type: 'string' } },
                difficulty: { type: 'string' },
                impact: { type: 'string' },
                resources: { type: 'array', items: { type: 'string' } },
              },
            },
          },
        },
      },
    });
    setIdeas(res?.ideas || []);
    await incrementUsage('portfolio_ideas');
    setLoading(false);
  };

  const difficultyColor = {
    Beginner: 'bg-green-500/20 text-green-400 border-green-500/30',
    Intermediate: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    Advanced: 'bg-red-500/20 text-red-400 border-red-500/30',
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader icon={Lightbulb} title="Portfolio Ideas" subtitle="Get AI-powered project ideas that impress hiring managers" />

      <Card className="bg-card border-border mb-6">
        <CardContent className="pt-6 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Job Title / Role *</label>
              <Input value={jobTitle} onChange={e => setJobTitle(e.target.value)} placeholder="e.g. Frontend Developer" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Your Skills (optional)</label>
              <Input value={skills} onChange={e => setSkills(e.target.value)} placeholder="e.g. React, Node.js, Python" />
            </div>
          </div>
          <PlanGate feature="portfolio_ideas" canUse={canUse('portfolio_ideas')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !jobTitle} className="gap-2">
              <Sparkles className="w-4 h-4" />
              {loading ? 'Generating Ideas...' : 'Generate Portfolio Ideas'}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {ideas.length > 0 && (
        <div className="grid md:grid-cols-2 gap-4">
          {ideas.map((idea, i) => (
            <Card key={i} className={`bg-card border-border transition-opacity ${completed[i] ? 'opacity-60' : ''}`}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-sm text-white">{idea.title}</CardTitle>
                  <button onClick={() => setCompleted(c => ({ ...c, [i]: !c[i] }))} className="shrink-0">
                    <CheckCircle2 className={`w-5 h-5 ${completed[i] ? 'text-green-400' : 'text-muted-foreground'}`} />
                  </button>
                </div>
                <span className={`inline-block text-xs px-2 py-0.5 rounded border w-fit ${difficultyColor[idea.difficulty] || 'bg-muted text-muted-foreground'}`}>
                  {idea.difficulty}
                </span>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground leading-relaxed">{idea.description}</p>
                {idea.impact && (
                  <div className="bg-primary/5 border border-primary/20 rounded-lg p-2">
                    <p className="text-xs text-primary font-semibold mb-1">💡 Why it impresses:</p>
                    <p className="text-xs text-white/80">{idea.impact}</p>
                  </div>
                )}
                {idea.tech_stack?.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {idea.tech_stack.map(t => (
                      <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                    ))}
                  </div>
                )}
                {idea.resources?.length > 0 && (
                  <div>
                    <p className="text-xs text-muted-foreground mb-1 font-semibold">Resources:</p>
                    <ul className="space-y-0.5">
                      {idea.resources.map((r, ri) => (
                        <li key={ri} className="text-xs text-primary/80 truncate">• {r}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}