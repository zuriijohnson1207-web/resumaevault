import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { User, Plus, Trash2, Save, Zap, LogOut, AlertTriangle, Crown, ShoppingCart, Briefcase, GraduationCap, Settings, History } from 'lucide-react';
import CreditHistoryPanel from '@/components/credits/CreditHistoryPanel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { Link } from 'react-router-dom';

const emptyExp = { job_title: '', company: '', start_date: '', end_date: '', current: false, description: '' };
const emptyEdu = { degree: '', school: '', field: '', graduation_year: '' };


export default function Profile() {
  const [profile, setProfile] = useState(null);
  const [profileId, setProfileId] = useState(null);
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', location: '', linkedin_url: '', portfolio_url: '', professional_summary: '', skills: '', certifications: '' });
  const [experience, setExperience] = useState([]);
  const [education, setEducation] = useState([]);
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(null);
  const { toast } = useToast();
  const { user, logout } = useAuth();

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.UserProfile.filter({ created_by: user.email }).then(p => {
      if (p.length) {
        const prof = p[0];
        setProfile(prof);
        setProfileId(prof.id);
        const { experience: exp = [], education: edu = [], ...rest } = prof;
        setForm({ full_name: rest.full_name || '', email: rest.email || '', phone: rest.phone || '', location: rest.location || '', linkedin_url: rest.linkedin_url || '', portfolio_url: rest.portfolio_url || '', professional_summary: rest.professional_summary || '', skills: rest.skills || '', certifications: rest.certifications || '' });
        setExperience(exp);
        setEducation(edu);
      }
    });

    // Real-time subscription — only update if it's the current user's profile
    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      if ((event.type === 'update' || event.type === 'create') && event.data?.created_by === user.email) {
        setProfile(event.data);
      }
    });
    return () => unsubscribe();
  }, [user?.email]);

  const save = async () => {
    if (!form.full_name?.trim()) {
      toast({ title: 'Full name is required', variant: 'destructive' });
      return;
    }
    setSaving(true);
    const data = { ...form, experience, education };
    if (profileId) {
      await base44.entities.UserProfile.update(profileId, data);
    } else {
      const created = await base44.entities.UserProfile.create(data);
      setProfileId(created.id);
    }
    setSaving(false);
    toast({ title: '✅ Profile saved successfully!' });
  };

  const getMissingCount = () => {
    const required = ['full_name', 'professional_summary', 'skills'];
    return required.filter(f => !form[f]?.trim()).length;
  };

  const clearProfile = async () => {
    if (!window.confirm('Are you sure you want to clear ALL your profile data? This cannot be undone.')) return;
    setClearing(true);
    const empty = { full_name: '', email: '', phone: '', location: '', linkedin_url: '', portfolio_url: '', professional_summary: '', skills: '', certifications: '', experience: [], education: [] };
    if (profileId) {
      await base44.entities.UserProfile.update(profileId, empty);
    }
    setForm({ full_name: '', email: '', phone: '', location: '', linkedin_url: '', portfolio_url: '', professional_summary: '', skills: '', certifications: '' });
    setExperience([]);
    setEducation([]);
    setClearing(false);
    toast({ title: '🗑️ Profile cleared successfully' });
  };

  const buyCredits = async (packId) => {
    setCheckoutLoading(packId);
    const res = await base44.functions.invoke('createCheckout', { product_key: packId });
    if (res.data?.url) {
      // Trigger sync when returning from checkout
      window.addEventListener('focus', async () => {
        await base44.functions.invoke('syncAccessState', { userEmail: user?.email, action: 'credit_added' }).catch(() => {});
      }, { once: true });
      window.location.href = res.data.url;
    }
    setCheckoutLoading(null);
  };

  const aiSuggest = async () => {
    setAiLoading(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Based on this profile, suggest improvements:
Name: ${form.full_name}
Summary: ${form.professional_summary}
Skills: ${form.skills}

Provide: 1) An improved professional summary (2-3 sentences), 2) Additional skills to add, 3) Quick tips. Keep it concise.`
    });
    toast({ title: 'AI Suggestions', description: res, duration: 8000 });
    setAiLoading(false);
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-6 pb-24">

      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-primary/10">
          <Settings className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground text-sm">Your profile, resume data & account</p>
        </div>
      </div>

      {/* AI suggestions banner */}
      {getMissingCount() > 0 && (
        <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/30 rounded-lg cursor-pointer mb-4" onClick={aiSuggest}>
          <div className="flex items-center gap-2 text-sm text-primary">
            <Zap className="w-4 h-4" />
            <span className="font-semibold">AI Profile Suggestions</span>
            <span className="text-muted-foreground">— {getMissingCount()} field(s) missing</span>
          </div>
          {aiLoading ? <span className="text-xs text-muted-foreground">Loading...</span> : <span className="text-xs text-primary">Tap to get tips →</span>}
        </div>
      )}

      <Tabs defaultValue="account">
        <TabsList className="w-full justify-start overflow-x-auto mb-6 flex-wrap h-auto gap-1">
          <TabsTrigger value="account" className="gap-1.5"><Crown className="w-3.5 h-3.5" /> Account</TabsTrigger>
          <TabsTrigger value="history" className="gap-1.5"><History className="w-3.5 h-3.5" /> Credit History</TabsTrigger>
          <TabsTrigger value="personal" className="gap-1.5"><User className="w-3.5 h-3.5" /> Profile</TabsTrigger>
          <TabsTrigger value="experience" className="gap-1.5"><Briefcase className="w-3.5 h-3.5" /> Experience</TabsTrigger>
          <TabsTrigger value="education" className="gap-1.5"><GraduationCap className="w-3.5 h-3.5" /> Education</TabsTrigger>
        </TabsList>

        {/* Account & Billing */}
        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardContent className="pt-4 space-y-3">
              <div className="flex justify-between text-sm py-2 border-b border-border">
                <span className="text-muted-foreground">Name</span>
                <span className="font-medium">{user?.full_name || '—'}</span>
              </div>
              <div className="flex justify-between text-sm py-2 border-b border-border">
                <span className="text-muted-foreground">Email</span>
                <span className="font-medium">{user?.email || '—'}</span>
              </div>
              <div className="flex justify-between text-sm py-2 border-b border-border">
                <span className="text-muted-foreground">Plan</span>
                <span className="font-medium capitalize">{profile?.subscription_plan || 'Free'}</span>
              </div>
              <div className="flex justify-between text-sm py-2">
                <span className="text-muted-foreground">AI Credits</span>
                <span className="font-medium text-primary">{profile?.ai_credits ?? 0} remaining</span>
              </div>
              <Link to="/pricing" className="block pt-1">
                <Button size="sm" variant="outline" className="w-full gap-1 text-xs"><Crown className="w-3 h-3" /> Upgrade Plan</Button>
              </Link>
            </CardContent>
          </Card>

          <div>
            <p className="text-sm font-semibold mb-3 text-foreground">Buy AI Credit Packs</p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'credits_50', label: '50 Credits', price: '$9.99', desc: 'Starter' },
                { id: 'credits_150', label: '150 Credits', price: '$24.99', desc: 'Popular' },
                { id: 'credits_400', label: '400 Credits', price: '$59.99', desc: 'Best value' },
              ].map(pack => (
                <button
                  key={pack.id}
                  onClick={() => buyCredits(pack.id)}
                  disabled={!!checkoutLoading}
                  className="flex flex-col items-center p-3 rounded-xl border border-border hover:border-primary/50 bg-card hover:bg-primary/10 transition-all text-center"
                >
                  <ShoppingCart className="w-4 h-4 text-primary mb-1" />
                  <span className="text-sm font-bold">{pack.label}</span>
                  <span className="text-xs text-primary font-semibold">{pack.price}</span>
                  <span className="text-xs text-muted-foreground">{pack.desc}</span>
                  {checkoutLoading === pack.id && <span className="text-xs text-muted-foreground mt-1">Loading...</span>}
                </button>
              ))}
            </div>
          </div>

          <Card className="border-destructive/30">
            <CardContent className="pt-4 space-y-3">
              <p className="text-sm font-semibold text-destructive flex items-center gap-1"><AlertTriangle className="w-3.5 h-3.5" /> Danger Zone</p>
              <div className="flex items-center justify-between p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                <div>
                  <p className="text-sm font-semibold">Clear Profile Data</p>
                  <p className="text-xs text-muted-foreground">Erase all saved profile info permanently.</p>
                </div>
                <Button size="sm" variant="destructive" onClick={clearProfile} disabled={clearing} className="gap-1 text-xs shrink-0">
                  <Trash2 className="w-3 h-3" /> {clearing ? 'Clearing...' : 'Clear'}
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-red-500/5 rounded-lg border border-red-500/20">
                <div>
                  <p className="text-sm font-semibold">Log Out</p>
                  <p className="text-xs text-muted-foreground">Sign out of your account.</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => logout()} className="gap-1 text-xs text-red-400 border-red-400/30 hover:bg-red-500/10 shrink-0">
                  <LogOut className="w-3 h-3" /> Log Out
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Credit History */}
        <TabsContent value="history">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-foreground">Credit History</h3>
                <p className="text-xs text-muted-foreground">Every credit usage, purchase, and adjustment</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">{profile?.ai_credits ?? 0}</div>
                <div className="text-xs text-muted-foreground">credits remaining</div>
              </div>
            </div>
            <CreditHistoryPanel limit={50} />
            <div className="text-center pt-2">
              <Link to="/pricing" className="text-sm text-primary font-semibold hover:underline">Buy More Credits →</Link>
            </div>
          </div>
        </TabsContent>

        {/* Personal Info */}
        <TabsContent value="personal">
          <Card>
            <CardContent className="pt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { key: 'full_name', label: 'Full Name *', placeholder: 'John Doe' },
                  { key: 'email', label: 'Email Address', placeholder: 'john@example.com' },
                  { key: 'phone', label: 'Phone', placeholder: '+1 (555) 123-4567' },
                  { key: 'location', label: 'Location', placeholder: 'San Francisco, CA' },
                  { key: 'linkedin_url', label: 'LinkedIn URL', placeholder: 'https://linkedin.com/in/johndoe' },
                  { key: 'portfolio_url', label: 'Portfolio URL', placeholder: 'https://johndoe.com' },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-xs font-medium mb-1 block text-muted-foreground">{f.label}</label>
                    <Input value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} />
                  </div>
                ))}
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block text-muted-foreground">Professional Summary</label>
                <Textarea value={form.professional_summary} onChange={e => setForm(p => ({ ...p, professional_summary: e.target.value }))} placeholder="Brief professional summary..." className="min-h-[100px]" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium mb-1 block text-muted-foreground">Skills (comma-separated)</label>
                  <Input value={form.skills} onChange={e => setForm(p => ({ ...p, skills: e.target.value }))} placeholder="JavaScript, React, Node.js" />
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block text-muted-foreground">Certifications (comma-separated)</label>
                  <Input value={form.certifications} onChange={e => setForm(p => ({ ...p, certifications: e.target.value }))} placeholder="AWS Certified, PMP" />
                </div>
              </div>
              <Button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground gap-2 mt-2">
                <Save className="w-4 h-4" /> {saving ? 'Saving...' : '💾 Save Personal Info'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Experience */}
        <TabsContent value="experience" className="space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setExperience(e => [...e, { ...emptyExp }])} className="gap-1 text-xs">
              <Plus className="w-3 h-3" /> Add Experience
            </Button>
          </div>
          {experience.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-10 border border-dashed border-border rounded-lg">No experience added yet.</p>
          )}
          {experience.map((exp, i) => (
            <Card key={i}>
              <CardContent className="pt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Experience #{i + 1}</span>
                  <Button size="icon" variant="ghost" onClick={() => setExperience(e => e.filter((_, idx) => idx !== i))} className="w-7 h-7 text-destructive">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Input placeholder="Job Title" value={exp.job_title} onChange={e => setExperience(prev => prev.map((x, idx) => idx === i ? { ...x, job_title: e.target.value } : x))} />
                  <Input placeholder="Company" value={exp.company} onChange={e => setExperience(prev => prev.map((x, idx) => idx === i ? { ...x, company: e.target.value } : x))} />
                  <Input placeholder="Start Date (e.g. Jan 2020)" value={exp.start_date} onChange={e => setExperience(prev => prev.map((x, idx) => idx === i ? { ...x, start_date: e.target.value } : x))} />
                  <Input placeholder="End Date (or 'Present')" value={exp.end_date} onChange={e => setExperience(prev => prev.map((x, idx) => idx === i ? { ...x, end_date: e.target.value } : x))} />
                </div>
                <Textarea placeholder="Describe your responsibilities and achievements..." value={exp.description} onChange={e => setExperience(prev => prev.map((x, idx) => idx === i ? { ...x, description: e.target.value } : x))} className="min-h-[80px]" />
              </CardContent>
            </Card>
          ))}
          <Button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground gap-2 mt-4">
            <Save className="w-4 h-4" /> {saving ? 'Saving...' : '💾 Save Experience'}
          </Button>
        </TabsContent>

        {/* Education */}
        <TabsContent value="education" className="space-y-3">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setEducation(e => [...e, { ...emptyEdu }])} className="gap-1 text-xs">
              <Plus className="w-3 h-3" /> Add Education
            </Button>
          </div>
          {education.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-10 border border-dashed border-border rounded-lg">No education added yet.</p>
          )}
          {education.map((edu, i) => (
            <Card key={i}>
              <CardContent className="pt-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Education #{i + 1}</span>
                  <Button size="icon" variant="ghost" onClick={() => setEducation(e => e.filter((_, idx) => idx !== i))} className="w-7 h-7 text-destructive">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Input placeholder="Degree (e.g. Bachelor's)" value={edu.degree} onChange={e => setEducation(prev => prev.map((x, idx) => idx === i ? { ...x, degree: e.target.value } : x))} />
                  <Input placeholder="School" value={edu.school} onChange={e => setEducation(prev => prev.map((x, idx) => idx === i ? { ...x, school: e.target.value } : x))} />
                  <Input placeholder="Field of Study" value={edu.field} onChange={e => setEducation(prev => prev.map((x, idx) => idx === i ? { ...x, field: e.target.value } : x))} />
                  <Input placeholder="Graduation Year" value={edu.graduation_year} onChange={e => setEducation(prev => prev.map((x, idx) => idx === i ? { ...x, graduation_year: e.target.value } : x))} />
                </div>
              </CardContent>
            </Card>
          ))}
          <Button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground gap-2 mt-4">
            <Save className="w-4 h-4" /> {saving ? 'Saving...' : '💾 Save Education'}
          </Button>
        </TabsContent>
      </Tabs>

      {/* Sticky save bar */}
      <div className="fixed bottom-0 left-0 right-0 md:left-56 bg-background/95 backdrop-blur border-t border-border py-3 px-6 flex justify-end z-30">
        <Button onClick={save} disabled={saving} className="bg-primary text-primary-foreground gap-2 shadow-lg">
          <Save className="w-4 h-4" /> {saving ? 'Saving...' : '💾 Save Profile'}
        </Button>
      </div>

    </div>
  );
}