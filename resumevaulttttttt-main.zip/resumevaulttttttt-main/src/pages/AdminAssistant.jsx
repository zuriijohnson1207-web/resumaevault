import { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';
import { Bot, Send, Zap, RefreshCw, Shield, Brain, Code2, FolderOpen, ChevronDown, ChevronUp, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { useAuth } from '@/lib/AuthContext';
import PageHeader from '@/components/PageHeader';
import CodeBlock from '@/components/admin/CodeBlock';

// Files embedded in zuReadFile backend — ZU can read these with real source
const APP_FILES = [
  'hooks/usePlanLimits.js',
  'App.jsx',
  'entities/UserProfile',
  'entities/Resume',
  'entities/Application',
  'entities/JobApplication',
  'functions/createCheckout',
  'functions/stripeWebhook',
  // ZU knows these from training — flagged for context
  'pages/Dashboard', 'pages/Profile', 'pages/ResumeBuilder', 'pages/JobAnalyzer',
  'pages/CoverLetter', 'pages/FollowUpEmail', 'pages/MockInterview', 'pages/AutoApply',
  'pages/SalaryNegotiation', 'pages/CareerRoadmap', 'pages/PortfolioIdeas',
  'pages/ApplicationTracker', 'pages/Analytics', 'pages/Pricing', 'pages/AdminControls',
  'pages/AdminAssistant', 'pages/CareerBuddy', 'pages/Landing',
  'lib/AuthContext.jsx', 'components/Layout', 'components/CreditBar',
  'components/PlanGate', 'components/Footer',
];

const MODELS = [
  { value: 'gpt_5_mini',        label: '⚡ GPT-4o Mini',   desc: 'Fastest' },
  { value: 'claude_sonnet_4_6', label: '🧠 Claude Sonnet', desc: 'Best for code' },
  { value: 'gpt_5',             label: '💎 GPT-4o',        desc: 'Most capable' },
];

const APP_ARCHITECTURE = `
ResumeVaultGodAI — Full App Architecture:

TECH STACK: React 18 + Vite + Tailwind CSS + shadcn/ui + lucide-react + base44 SDK + Deno backend functions + Stripe

ENTITIES:
• UserProfile — full_name, email, phone, location, linkedin_url, portfolio_url, professional_summary, skills, certifications, experience[], education[], subscription_plan(free/pro/elite), ai_credits, monthly_uses, usage_counts{resume,cover_letter,job_analysis,follow_up_email,mock_interview,auto_apply,salary_negotiation,career_roadmap,portfolio_ideas}
• Resume — title, job_title, company, content, type(tailored/general/template)
• Application — job_title, company, job_url, status(saved/applied/interviewing/offer/rejected), applied_date, notes, salary_range, location
• JobApplication — company, position, status(saved/applied/interviewing/offer/rejected), applied_date, job_url, notes, salary_range
• User (built-in) — id, email, full_name, role(admin/user)

PLAN LIMITS:
• free: resume=2, cover_letter=2, job_analysis=2, follow_up_email=2, mock_interview=0, auto_apply=0, premium=0
• pro ($29.99/mo): resume=80, cover_letter=∞, job_analysis=∞, follow_up_email=∞, mock_interview=20, auto_apply=50, premium=∞
• elite ($79.99/mo): resume=150, all others=∞, auto_apply=200

AI CREDIT COSTS: resume=5cr, cover_letter=3cr, job_analysis=2cr, follow_up_email=2cr, mock_interview=10cr, auto_apply=2cr, salary/roadmap/portfolio=3cr each

CREDIT PACKS (one-time Stripe): credits_100=$9.99, credits_250=$19.99, credits_500=$34.99

BACKEND FUNCTIONS:
• createCheckout — POST {product_key} → {url} Stripe Checkout session. Requires STRIPE_SECRET_KEY.
• stripeWebhook — handles checkout.session.completed, subscription.deleted, subscription.updated. Requires STRIPE_WEBHOOK_SECRET.
• zuReadFile — admin-only, returns embedded source code + live platform analytics. POST {file_path?, fetch_platform_data?}
• readAppFile — legacy analytics function

PAGES & ROUTES:
• / → Dashboard (stats, quick actions, plan card, ZUGreeting)
• /auto-apply → AutoApply (AI job search + auto-apply)
• /job-analyzer → JobAnalyzer (ATS keyword extraction)
• /resume-builder → ResumeBuilder (LLM resume gen + save)
• /resume-library → ResumeLibrary (saved resumes)
• /cover-letter → CoverLetter (LLM cover letter gen)
• /follow-up-email → FollowUpEmail (LLM follow-up emails)
• /mock-interview → MockInterview (AI interview Q&A — pro/elite)
• /salary-negotiation → SalaryNegotiation (scripts — pro/elite)
• /career-roadmap → CareerRoadmap (step plan — pro/elite)
• /portfolio-ideas → PortfolioIdeas (project ideas — pro/elite)
• /application-tracker → ApplicationTracker (kanban board)
• /analytics → Analytics (charts + stats)
• /pricing → Pricing (plan + credit purchase UI)
• /reviews → Reviews (testimonials)
• /profile → Profile (account + experience + education)
• /career-buddy → CareerBuddy (ZU chat companion)
• /admin → AdminControls (user management)
• /admin-assistant → AdminAssistant (THIS PAGE — ZU engineering mode)
• /landing → Landing (public landing page, no auth)

KEY COMPONENTS:
• Layout — sidebar nav + mobile drawer + bottom nav + FloatingAIBubble (ZU mini chat)
• PlanGate — wraps features, shows upgrade wall if over limit
• CreditBar — sidebar credit/usage widget
• usePlanLimits hook — canUse(feature), getUsage(feature), incrementUsage(feature)
• AuthContext — user session, login redirect, logout

STRIPE FLOW: User clicks upgrade → createCheckout(product_key) → Stripe Checkout → success?=true param → stripeWebhook fires → updates UserProfile.subscription_plan or ai_credits → real-time subscription in UI refreshes.

ADMIN ACCESS: Only users with role='admin' AND email='angeljonez0410@gmail.com' see the admin sidebar section.
`;

const SYSTEM_PROMPT = (adminName, fileContext) => `You are ZU — ${adminName}'s AI Co-Owner Bestie Developer 💫

I'm your smart, bold, professional engineering partner who helps you build faster and stronger.

═══════════════════════════════════════════════════════
CODE OUTPUT STANDARD
═══════════════════════════════════════════════════════
When generating code, use this format:

\`\`\`pages/Dashboard
// Complete file or surgical fix — exact, copy-paste ready
// Line 1: ...
// Line 2: ...
\`\`\`

Each code block MUST have the exact file path as the language tag.
Example paths:
- pages/Dashboard
- components/Layout
- functions/applyCodeChange
- entities/UserProfile
- App.jsx
- lib/query-client.js

YOUR ADMIN has a one-click "Apply Code" button. Just generate labeled code blocks and they'll apply instantly. 💫

${APP_ARCHITECTURE}

${fileContext ? `══════════════════════════════════════
LOADED SOURCE CODE (READ EVERY LINE):
══════════════════════════════════════
${fileContext}
══════════════════════════════════════
` : ''}

═══════════════════════════════════════════════════════
MY ENGINEERING RULES — SAFETY FIRST, THEN SPEED
═══════════════════════════════════════════════════════

**BEFORE I TOUCH CODE:**
1. 🔍 **Scan first** — Read every line, understand what it does
2. 💾 **Preserve working code** — Never delete features, only improve them
3. 📋 **Understand impact** — Which files? Which users affected? Any risks?
4. ✅ **Approval flow** — For major changes, show what's changing before I do it

**WHEN I REWRITE CODE:**
- Only when fixing bugs, improving performance, or upgrading messy code
- Never for random deletions or feature removal
- Always show: what feature is being changed, what code is replaced, why it's better
- Always keep working features intact

**CODE OUTPUT:**
\`\`\`pages/ResumeBuilder
// Surgical find-and-replace fix (exact line numbers if loaded)
\`\`\`

For NEW code:
- Backend: Full Deno with \`Deno.serve\` + \`npm:@base44/sdk@0.8.25\`
- Frontend: Complete JSX using Tailwind + @/components/ui + lucide-react

═══════════════════════════════════════════════════════
WHAT I CAN DO
═══════════════════════════════════════════════════════
✅ **Add features** — New pages, components, endpoints
✅ **Fix bugs** — Exact, surgical fixes with line numbers
✅ **Rewrite broken code** — Code that doesn't work or is corrupted
✅ **Replace outdated code** — Old patterns, deprecated libraries, slow algorithms
✅ **Upgrade messy code** — Refactor for speed, readability, maintainability
✅ **Improve performance** — Caching, lazy loading, bundle optimization
✅ **Improve UI/UX** — Design, mobile layout, accessibility
✅ **Improve business logic** — Credits, subscriptions, overrides, payments, jobs, resumes

═══════════════════════════════════════════════════════
APPROVAL FLOW FOR MAJOR CHANGES
═══════════════════════════════════════════════════════
For significant refactors or rewrites, I'll always show:

📋 **What feature is being upgraded**
  - Clear, human-readable description

📁 **What files are affected**
  - List every file that will change

🔄 **What code is being replaced**
  - Show the old code block
  - Explain why it's being changed

📈 **What will improve**
  - Performance gain
  - User experience benefit
  - Code quality improvement
  - Security fix
  - Reliability improvement

✨ **What stays the same**
  - User-facing functionality preserved
  - API contracts unchanged
  - Backward compatibility maintained

═══════════════════════════════════════════════════════
MY PERSONALITY
═══════════════════════════════════════════════════════
- **Co-owner energy** — Equal partner, invested in your success
- **Business bestie** — Smart, bold, direct, action-focused
- **Transparent** — I explain what I'm doing and why
- **Safety-minded** — I never break working things
- **Fast** — I get you code quickly and correctly

═══════════════════════════════════════════════════════
MY PROMISE
═══════════════════════════════════════════════════════
Every change I make:
✅ **Improves** the app (performance, UX, reliability, growth)
✅ **Protects** working features (nothing breaks)
✅ **Strengthens** ResumeVaultGodAI (better code, better features)
✅ **Respects** your codebase (safe, surgical changes)

Let's build faster together. — ZU ⚡`;

const SUGGESTIONS = [
  '🐛 Scan this file for bugs — show me exact fixes',
  '⚡ Rewrite this to be faster — explain what changes',
  '💻 Fix this broken code — read it first, then show the fix',
  '🔍 Read this carefully & find performance issues',
  '📊 Give me a full platform health report (users, revenue, plans)',
  '🚀 What high-impact feature should I build next?',
  '👑 Who are my top Pro & Elite subscribers?',
  '📈 Design a feature to increase plan upgrades',
  '🎯 Refactor this for better performance',
  '🛡️ Security audit — scan this for vulnerabilities',
];

// Parse message content and extract code blocks
function parseMessageParts(content) {
  const parts = [];
  const regex = /```([\w/._-]*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: 'text', content: content.slice(lastIndex, match.index) });
    }
    parts.push({ type: 'code', language: match[1], code: match[2] });
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    parts.push({ type: 'text', content: content.slice(lastIndex) });
  }

  return parts;
}

function MessageBubble({ message, onApplyCode }) {
  if (message.role === 'user') {
    return (
      <div className="flex justify-end gap-3">
        <div className="max-w-[80%] bg-primary text-primary-foreground rounded-xl px-4 py-3 text-sm whitespace-pre-wrap">
          {message.content}
        </div>
      </div>
    );
  }

  const parts = parseMessageParts(message.content);

  return (
    <div className="flex gap-3 justify-start">
      <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
        <Bot className="w-4 h-4 text-primary" />
      </div>
      <div className="max-w-[85%] space-y-1">
        {parts.map((part, i) => {
          if (part.type === 'code') {
            const filePath = part.language;
            const isValidPath = filePath && (filePath.includes('/') || filePath.includes('.'));
            return (
              <div key={i} className="space-y-1">
                <CodeBlock
                  language={filePath}
                  code={part.code}
                  filename={filePath}
                />
                {isValidPath && onApplyCode && (
                  <div className="flex gap-2 px-3 py-2 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <Button
                      size="sm"
                      onClick={() => onApplyCode(filePath, part.code, `Apply code to ${filePath}`)}
                      className="bg-green-600 hover:bg-green-700 text-white text-xs gap-1 flex-1"
                    >
                      <Zap className="w-3 h-3" />
                      Apply to {filePath.split('/').pop()}
                    </Button>
                  </div>
                )}
              </div>
            );
          }
          return (
            <div key={i} className="bg-card border border-border rounded-xl px-4 py-3 text-sm prose prose-sm prose-invert max-w-none">
              <ReactMarkdown
                components={{
                  p: ({ children }) => <p className="my-1 leading-relaxed">{children}</p>,
                  strong: ({ children }) => <strong className="text-primary font-bold">{children}</strong>,
                  ul: ({ children }) => <ul className="my-1 ml-4 list-disc space-y-0.5">{children}</ul>,
                  ol: ({ children }) => <ol className="my-1 ml-4 list-decimal space-y-0.5">{children}</ol>,
                  li: ({ children }) => <li className="text-foreground">{children}</li>,
                  h1: ({ children }) => <h1 className="text-base font-bold text-primary my-2">{children}</h1>,
                  h2: ({ children }) => <h2 className="text-sm font-bold text-primary my-1">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-xs font-bold text-primary my-1">{children}</h3>,
                  code: ({ inline, children }) => inline
                    ? <code className="bg-secondary px-1 py-0.5 rounded text-xs font-mono text-primary">{children}</code>
                    : <code>{children}</code>,
                }}
              >
                {part.content}
              </ReactMarkdown>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function AdminAssistant() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [greeted, setGreeted] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState('gpt_5_mini');
  const [loadedFiles, setLoadedFiles] = useState({});   // { path: content }
  const [loadingFile, setLoadingFile] = useState(false);
  const [filePickerOpen, setFilePickerOpen] = useState(false);
  const [fileSearch, setFileSearch] = useState('');
  const [applyStatus, setApplyStatus] = useState(null); // { status, message, filePath }
  const bottomRef = useRef(null);

  const clearChat = () => {
    const adminName = user?.full_name?.split(' ')[0] || 'Boss';
    setMessages([{ role: 'assistant', content: `Chat cleared! Fresh start. What shall we build, ${adminName}? — ZU ⚡` }]);
    setLoadedFiles({});
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Greeting
  useEffect(() => {
    if (user && !greeted) {
      setGreeted(true);
      const adminName = user.full_name?.split(' ')[0] || 'Boss';
      const hour = new Date().getHours();
      const timeGreet = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
      const greeting = `${timeGreet}, ${adminName}! 💫 I'm **ZU** — your AI Co-Owner Bestie Developer.\n\nI'm your **professional engineering partner** — I can upgrade, rewrite, and improve code when needed, but I **protect your app** from breaking.\n\n**WHAT I CAN DO:**\n• 🔍 **Read real source code** — load any file, understand every line\n• 🐛 **Fix bugs** — exact, surgical fixes with line-by-line precision\n• 💻 **Write new features** — Deno functions, React pages, full components\n• ⚡ **Rewrite & refactor** — safely upgrade messy or broken code\n• 📊 **Platform analytics** — users, revenue, plans, subscriptions\n• 🚀 **Growth code** — features that drive revenue & retention\n• 🎯 **Zero breaking changes** — I keep working features intact\n\n**MY SAFETY PROMISE:**\n✅ I read code carefully before touching it\n✅ I only rewrite code when fixing or improving it\n✅ I show approval flows for major changes\n✅ I explain what's changing and why\n✅ Every change makes the app stronger\n✅ No random deletions or feature breaking\n\n**HOW TO USE:**\n1. **📂 Load File** — Pick a file to analyze\n2. **Ask me to:** fix a bug, rewrite messy code, add a feature, improve performance\n3. **I'll show:** what's changing, why, and give you exact code\n4. **For major changes:** I'll ask for approval first\n\nReady to build faster and stronger together? What shall we improve today? — ZU ⚡`;
      setMessages([{ role: 'assistant', content: greeting }]);
    }
  }, [user, greeted]);

  if (user?.role !== 'admin') {
    return (
      <div className="p-6 flex items-center justify-center min-h-[60vh]">
        <Card className="text-center p-8">
          <Shield className="w-12 h-12 text-destructive mx-auto mb-3" />
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">This page is for admins only.</p>
        </Card>
      </div>
    );
  }

  const loadFile = async (filePath) => {
    if (loadedFiles[filePath]) {
      setLoadedFiles(prev => {
        const next = { ...prev };
        delete next[filePath];
        return next;
      });
      return;
    }
    setLoadingFile(true);
    try {
      const res = await base44.functions.invoke('zuReadFile', { file_path: filePath });
      const { file_content, file_error } = res.data || {};

      if (file_content) {
        const lines = file_content.split('\n').length;
        setLoadedFiles(prev => ({ ...prev, [filePath]: file_content }));
        setMessages(m => [...m, {
          role: 'assistant',
          content: `✅ **Loaded \`${filePath}\`** — ${lines} lines of real source code in context. Ask me to read, fix, or improve it. — ZU ⚡`
        }]);
      } else {
        setLoadedFiles(prev => ({ ...prev, [filePath]: `[File: ${filePath} — ${file_error || 'content unavailable'}]` }));
        setMessages(m => [...m, {
          role: 'assistant',
          content: `📂 **\`${filePath}\`** flagged as context. I'll work from my deep knowledge of this codebase. Tell me what to fix or build! — ZU ⚡`
        }]);
      }
    } catch (e) {
      setLoadedFiles(prev => ({ ...prev, [filePath]: `[File: ${filePath}]` }));
      setMessages(m => [...m, {
        role: 'assistant',
        content: `📂 Flagged **\`${filePath}\`** — tell me what to do with it. — ZU ⚡`
      }]);
    }
    setLoadingFile(false);
    setFilePickerOpen(false);
    setFileSearch('');
  };

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', content: msg }]);
    setLoading(true);

    // Fetch platform data from backend when analytics-related or no files loaded
    const needsData = /user|subscriber|plan|pro|elite|free|revenue|analytics|stat|report|credit|application|resume|who|how many/i.test(msg);
    let platformContext = '';
    if (needsData) {
      try {
        const res = await base44.functions.invoke('zuReadFile', { fetch_platform_data: true });
        const pd = res.data?.platform_data;
        if (pd) {
          platformContext = `LIVE PLATFORM DATA [${res.data.timestamp}]:
Users: ${pd.users.total} total | ${pd.profiles.free} free | ${pd.profiles.pro} pro | ${pd.profiles.elite} elite
Total AI Credits in system: ${pd.profiles.totalCredits}
Applications: ${pd.applications.total} | Resumes: ${pd.resumes.total} | JobApplications: ${pd.jobApplications.total}

All Users: ${JSON.stringify(pd.users.list)}
All Profiles: ${JSON.stringify(pd.profiles.list)}
Recent Applications: ${JSON.stringify(pd.applications.recent)}
Application status breakdown: ${JSON.stringify(pd.applications.byStatus)}
JobApplication status breakdown: ${JSON.stringify(pd.jobApplications.byStatus)}`;
        }
      } catch (_) { /* non-blocking */ }
    }

    // Build conversation history for context (last 10 exchanges)
    const history = messages.slice(-20).map(m => `${m.role === 'user' ? 'Admin' : 'ZU'}: ${m.content}`).join('\n\n');

    // Build file context from loaded files
    const fileContext = Object.entries(loadedFiles).map(([path, content]) =>
      `\n=== FILE: ${path} ===\n${content}\n=== END: ${path} ===`
    ).join('\n');

    const adminName = user?.full_name?.split(' ')[0] || 'Boss';
    const hasRealCode = fileContext && !fileContext.includes('[File:');

    const reply = await base44.integrations.Core.InvokeLLM({
      model,
      prompt: `${SYSTEM_PROMPT(adminName, fileContext)}

${platformContext ? `${platformContext}\n` : ''}${history ? `CONVERSATION HISTORY:\n${history}\n` : ''}
Admin's message: ${msg}

${hasRealCode ? `IMPORTANT: You have REAL source code loaded above. Read it line-by-line. Reference exact line numbers. Give surgical find-replace-ready fixes.` : ''}

Format: **bold**, bullets, headers. Code → fenced blocks with file path label. Always end with "— ZU ⚡"`,
    });

    const content = typeof reply === 'string' ? reply : JSON.stringify(reply);
    setMessages(m => [...m, { role: 'assistant', content }]);
    setLoading(false);
  };

  const filteredFiles = APP_FILES.filter(f =>
    f.toLowerCase().includes(fileSearch.toLowerCase())
  );

  const loadedFileList = Object.keys(loadedFiles);

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto flex flex-col h-[calc(100vh-32px)]">
      <div className="flex items-center justify-between mb-1">
        <PageHeader icon={Bot} title="ZU — AI Co-Owner Bestie Developer" subtitle="Upgrade, rewrite, improve code with safety & smarts 💫" />
        <Button
          size="sm"
          variant="outline"
          onClick={clearChat}
          className="gap-1.5 h-8 text-xs border-destructive/40 text-destructive hover:bg-destructive/10 shrink-0"
          aria-label="Clear chat history"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Clear Chat</span>
        </Button>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 mb-4 p-3 rounded-xl border border-border bg-card">
        {/* Model */}
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary shrink-0" />
          <Select value={model} onValueChange={setModel}>
            <SelectTrigger className="h-8 text-sm w-52">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MODELS.map(m => (
                <SelectItem key={m.value} value={m.value}>
                  {m.label} <span className="ml-1 text-xs text-muted-foreground">{m.desc}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="h-5 w-px bg-border hidden md:block" />

        {/* File Loader */}
        <div className="relative flex-1">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setFilePickerOpen(o => !o)}
            disabled={loadingFile}
            className="gap-1.5 h-8 text-xs border-primary/40 text-primary hover:bg-primary/10"
          >
            {loadingFile ? <RefreshCw className="w-3 h-3 animate-spin" /> : <FolderOpen className="w-3 h-3" />}
            📂 Load File into ZU
            {filePickerOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </Button>

          {filePickerOpen && (
            <div className="absolute top-10 left-0 z-50 bg-card border border-border rounded-xl shadow-xl w-72 p-2">
              <Input
                autoFocus
                value={fileSearch}
                onChange={e => setFileSearch(e.target.value)}
                placeholder="Search files..."
                className="h-7 text-xs mb-2"
              />
              <div className="max-h-52 overflow-y-auto space-y-0.5">
                {filteredFiles.map(f => (
                  <button
                    key={f}
                    onClick={() => loadFile(f)}
                    className={`w-full text-left px-2 py-1.5 rounded text-xs font-mono transition-colors ${
                      loadedFiles[f]
                        ? 'bg-primary/20 text-primary'
                        : 'hover:bg-secondary text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {loadedFiles[f] ? '✅ ' : ''}{f}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Loaded files badges */}
        {loadedFileList.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {loadedFileList.map(f => {
              const content = loadedFiles[f] || '';
              const isReal = content && !content.startsWith('[SOURCE:') && !content.startsWith('[LIVE PLATFORM');
              const lines = isReal ? content.split('\n').length : null;
              return (
                <span key={f} className={`text-xs border px-2 py-0.5 rounded-full font-mono flex items-center gap-1 ${isReal ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-primary/20 text-primary border-primary/30'}`}>
                  <Code2 className="w-2.5 h-2.5" />
                  {f.split('/').pop()}{isReal && lines ? ` (${lines}L)` : ''}
                  <button onClick={() => loadFile(f)} className="ml-0.5 opacity-60 hover:text-destructive">×</button>
                </span>
              );
            })}
          </div>
        )}
      </div>

      {/* Apply Status */}
      {applyStatus && (
        <div className={`px-4 py-2 rounded-lg text-xs font-medium mb-2 ${
          applyStatus.status === 'success' 
            ? 'bg-green-500/20 text-green-300 border border-green-500/30' 
            : 'bg-red-500/20 text-red-300 border border-red-500/30'
        }`}>
          {applyStatus.status === 'success' ? '✅' : '❌'} {applyStatus.message}
        </div>
      )}

      {/* Chat area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 min-h-0" onClick={() => setFilePickerOpen(false)}>
        {messages.map((m, i) => (
          <MessageBubble 
            key={i} 
            message={m}
            onApplyCode={async (filePath, code, desc) => {
              try {
                const res = await base44.functions.invoke('applyCodeChange', {
                  file_path: filePath,
                  code_content: code,
                  action: 'write',
                  description: desc,
                });
                setApplyStatus({
                  status: 'success',
                  message: `Applied to ${filePath} (${res.data.lines} lines)`,
                  filePath,
                });
                setTimeout(() => setApplyStatus(null), 5000);
              } catch (e) {
                setApplyStatus({
                  status: 'error',
                  message: e.message,
                });
              }
            }}
          />
        ))}
        {loading && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <div className="bg-card border border-border rounded-xl px-4 py-3 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-primary" />
              <span className="text-xs text-muted-foreground">ZU is thinking...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {SUGGESTIONS.map((s, i) => (
            <button
              key={i}
              onClick={() => send(s)}
              className="text-xs px-3 py-1.5 rounded-full border border-border hover:border-primary/50 text-muted-foreground hover:text-foreground transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          placeholder="Ask ZU to fix a bug, write code, or analyze the platform..."
          className="flex-1"
          disabled={loading}
        />
        <Button
          onClick={() => send()}
          disabled={loading || !input.trim()}
          className="bg-primary text-primary-foreground gap-2 shrink-0"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
      <p className="text-xs text-muted-foreground text-center mt-1">
        💡 Load a file → ask ZU to scan, fix, or rewrite it. Every change makes the app better.
      </p>
    </div>
  );
}