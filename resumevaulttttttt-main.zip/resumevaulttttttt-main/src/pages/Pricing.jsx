import { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  Crown, Zap, Check, Star, Loader2, Sparkles, CreditCard,
  Shield, RefreshCw, TrendingUp, X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

// ─── Product config ───────────────────────────────────────────────────────────
const PLAN_KEYS = { Starter: 'pro_monthly', Pro: 'elite_monthly' };

const PLANS = [
  {
    key: 'free',
    name: 'Free',
    price: '$0',
    period: '/forever',
    badge: null,
    tagline: 'Perfect for getting started',
    accent: 'border-border',
    btnClass: 'bg-secondary text-foreground hover:bg-secondary/80',
    features: [
      '2 AI resume generations',
      'Basic resume templates',
      'Basic ATS score',
      'Resume library access',
      'Application tracker',
    ],
    locked: [
      'Full ATS keyword report',
      'AI cover letters',
      'Resume vs job comparison',
      'Auto-apply',
      'Mock interviews',
    ],
    cta: 'Start Free',
    productKey: null,
  },
  {
    key: 'pro',
    name: 'Pro',
    price: '$29.99',
    period: '/month',
    badge: 'Most Popular',
    tagline: 'Best for active job seekers',
    accent: 'border-primary shadow-xl shadow-primary/25',
    btnClass: 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/30',
    features: [
      '80 AI resume generations/mo',
      'Full ATS keyword scoring',
      'All resume templates',
      'Resume editing tools',
      'PDF + Word downloads',
      'AI cover letters',
      'Job match scoring',
      'Priority support',
    ],
    locked: [],
    cta: 'Upgrade to Pro',
    productKey: 'pro_monthly',
  },
  {
    key: 'elite',
    name: 'Elite',
    price: '$79.99',
    period: '/month',
    badge: 'Maximum Power',
    tagline: 'For serious career changers',
    accent: 'border-purple-500/60 shadow-xl shadow-purple-500/20',
    btnClass: 'bg-purple-600 text-white hover:bg-purple-700',
    features: [
      '150 AI resume generations/mo',
      'Unlimited cover letters & emails',
      'Unlimited ATS analysis',
      'Resume vs job comparison',
      '200 auto-applications/month',
      'Mock interview sessions',
      'Salary negotiation AI',
      'Career roadmap builder',
      'Portfolio ideas generator',
      '24/7 priority support',
    ],
    locked: [],
    cta: 'Go Elite',
    productKey: 'elite_monthly',
  },
];

const CREDIT_PACKS = [
  {
    key: 'credits_50',
    credits: 50,
    price: '$9.99',
    per: '$0.20/credit',
    save: null,
    examples: ['10 AI resumes', '16 cover letters', '25 auto-applications'],
    popular: false,
  },
  {
    key: 'credits_150',
    credits: 150,
    price: '$24.99',
    per: '$0.17/credit',
    save: 'Save 15%',
    examples: ['30 AI resumes', '50 cover letters', '75 auto-applications'],
    popular: true,
  },
  {
    key: 'credits_400',
    credits: 400,
    price: '$59.99',
    per: '$0.15/credit',
    save: 'Save 25%',
    examples: ['80 AI resumes', '133 cover letters', '200 auto-applications'],
    popular: false,
  },
];

const TESTIMONIALS = [
  { quote: "Got 3 interviews in my first week. The ATS keyword matching is a game-changer.", name: "Sarah K.", role: "Software Engineer" },
  { quote: "The salary negotiation AI helped me land $18K more than the initial offer. Absolutely worth it.", name: "Marcus T.", role: "Product Manager" },
  { quote: "Went from zero callbacks to 5 interviews in 2 weeks. ResumeVault AI changed everything.", name: "Priya M.", role: "Data Analyst" },
];

const FEATURE_COSTS = [
  { icon: '📄', label: 'AI Resume', cost: '5 credits' },
  { icon: '✉️', label: 'Cover Letter', cost: '3 credits' },
  { icon: '🎯', label: 'Job Analysis', cost: '2 credits' },
  { icon: '🎤', label: 'Mock Interview', cost: '10 credits' },
  { icon: '🚀', label: 'Auto-Apply', cost: '2 credits' },
  { icon: '💰', label: 'Salary Negotiation', cost: '3 credits' },
];

// ─── Component ────────────────────────────────────────────────────────────────
export default function Pricing() {
  const [loadingKey, setLoadingKey] = useState(null);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [userCredits, setUserCredits] = useState(0);
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const success = params.get('success');
  const cancelled = params.get('cancelled');

  useEffect(() => {
    base44.entities.UserProfile.list().then(p => {
      if (p[0]) {
        setCurrentPlan(p[0].subscription_plan);
        setUserCredits(p[0].ai_credits || 0);
      }
    });
    const unsub = base44.entities.UserProfile.subscribe(e => {
      if (e.type === 'update' || e.type === 'create') {
        setCurrentPlan(e.data?.subscription_plan);
        setUserCredits(e.data?.ai_credits || 0);
      }
    });
    return () => unsub();
  }, []);

  // Poll after successful payment
  useEffect(() => {
    if (!success) return;
    let attempts = 0;
    const interval = setInterval(async () => {
      const p = await base44.entities.UserProfile.list();
      if (p[0]) { setCurrentPlan(p[0].subscription_plan); setUserCredits(p[0].ai_credits || 0); }
      if (++attempts >= 10) clearInterval(interval);
    }, 2000);
    return () => clearInterval(interval);
  }, [success]);

  const checkout = async (productKey) => {
    if (!productKey) return;
    setLoadingKey(productKey);
    const res = await base44.functions.invoke('createCheckout', { product_key: productKey });
    if (res.data?.url) {
      window.location.href = res.data.url;
    } else {
      toast.error('Checkout failed. Please try again.');
      setLoadingKey(null);
    }
  };

  const isCurrentPlan = (planKey) => currentPlan === planKey;

  return (
    <div className="min-h-screen bg-background">

      {/* ── Hero ─────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden bg-gradient-to-br from-background via-card to-background border-b border-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,hsl(var(--primary)/0.12),transparent_70%)]" />
        <div className="relative max-w-4xl mx-auto px-6 py-16 text-center">
          <Badge className="bg-primary/10 text-primary border-primary/30 border mb-4 text-xs font-semibold px-3 py-1">
            AI-Powered Resume Builder
          </Badge>
          <h1 className="text-4xl md:text-5xl font-black text-foreground leading-tight mb-4">
            Stop Getting Ignored.<br />
            <span className="text-primary">Build a Resume That Gets Seen.</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            ResumeVault AI helps you create ATS-friendly resumes, match job descriptions, and apply smarter with AI — so recruiters actually call you back.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link to="/resume-builder">
              <Button size="lg" className="font-bold px-8 gap-2 shadow-lg shadow-primary/30">
                <Zap className="w-5 h-5" /> Start Free
              </Button>
            </Link>
            <a href="#plans">
              <Button size="lg" variant="outline" className="font-semibold px-8 border-primary/40 text-primary hover:bg-primary/10">
                View Plans
              </Button>
            </a>
          </div>
          {currentPlan && (
            <p className="text-xs text-muted-foreground mt-4">
              Current plan: <span className="text-primary font-semibold capitalize">{currentPlan}</span>
              {userCredits > 0 && <span> · <span className="text-foreground font-semibold">{userCredits} credits</span> remaining</span>}
            </p>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-16">

        {/* ── Alerts ───────────────────────────────────────────────── */}
        {success && (
          <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/30 text-green-400 rounded-xl px-5 py-4 text-sm font-medium">
            <Sparkles className="w-5 h-5 shrink-0" />
            Upgrade successful — your credits are ready. Let's get you that job! 🎉
          </div>
        )}
        {cancelled && (
          <div className="flex items-center gap-3 bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 rounded-xl px-5 py-4 text-sm">
            <X className="w-4 h-4 shrink-0" />
            Payment cancelled — no worries, you can upgrade anytime!
          </div>
        )}

        {/* ── Stats ────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          {[['50K+', 'Happy Users'], ['85%', 'Interview Rate'], ['200K+', 'Resumes Built'], ['14 Days', 'Avg. Time to Offer']].map(([v, l]) => (
            <div key={l} className="bg-card border border-border rounded-xl p-4">
              <div className="text-2xl font-black text-primary">{v}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{l}</div>
            </div>
          ))}
        </div>

        {/* ── Pricing Plans ────────────────────────────────────────── */}
        <div id="plans">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-black text-foreground mb-2">Simple, Honest Pricing</h2>
            <p className="text-muted-foreground">Start free. Upgrade when you're ready. Cancel anytime.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PLANS.map(plan => (
              <Card key={plan.key} className={`border relative flex flex-col ${plan.accent}`}>
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                    <Badge className={`text-xs font-bold px-3 py-1 ${plan.key === 'elite' ? 'bg-purple-600 text-white' : 'bg-primary text-primary-foreground'}`}>
                      {plan.badge}
                    </Badge>
                  </div>
                )}
                <CardHeader className="pb-4 pt-6">
                  <CardTitle className="text-foreground text-xl font-black">{plan.name}</CardTitle>
                  <div className="flex items-end gap-1 mt-1">
                    <span className="text-4xl font-black text-foreground">{plan.price}</span>
                    <span className="text-sm text-muted-foreground mb-1">{plan.period}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{plan.tagline}</p>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4">
                  <ul className="space-y-2 flex-1">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                        <Check className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                        {f}
                      </li>
                    ))}
                    {plan.locked.map((f, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground/50">
                        <X className="w-4 h-4 text-border shrink-0 mt-0.5" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  {isCurrentPlan(plan.key) ? (
                    <div className="w-full py-2.5 rounded-lg text-center text-sm font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                      ✓ Your Current Plan
                    </div>
                  ) : plan.productKey ? (
                    <Button
                      className={`w-full h-11 font-bold text-sm ${plan.btnClass}`}
                      disabled={loadingKey === plan.productKey}
                      onClick={() => checkout(plan.productKey)}
                    >
                      {loadingKey === plan.productKey
                        ? <Loader2 className="w-4 h-4 animate-spin" />
                        : plan.cta}
                    </Button>
                  ) : (
                    <Link to="/resume-builder">
                      <Button className={`w-full h-11 font-bold text-sm ${plan.btnClass}`}>
                        {plan.cta}
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ── Credit Packs ─────────────────────────────────────────── */}
        <div>
          <div className="text-center mb-6">
            <h2 className="text-3xl font-black text-foreground mb-2 flex items-center justify-center gap-2">
              <Zap className="w-7 h-7 text-primary" /> AI Credit Packs
            </h2>
            <p className="text-muted-foreground">Pay-as-you-go · Credits <strong className="text-foreground">never expire</strong> · Use for any feature</p>
          </div>

          {/* Feature cost grid */}
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-8">
            {FEATURE_COSTS.map(fc => (
              <div key={fc.label} className="bg-card border border-border rounded-xl p-3 text-center">
                <div className="text-2xl mb-1">{fc.icon}</div>
                <div className="text-xs font-semibold text-foreground">{fc.label}</div>
                <div className="text-xs text-primary font-bold">{fc.cost}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {CREDIT_PACKS.map(cp => (
              <Card key={cp.key} className={`border relative ${cp.popular ? 'border-primary shadow-xl shadow-primary/20' : 'border-border'}`}>
                {cp.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground text-xs font-bold px-3">Best Value</Badge>
                  </div>
                )}
                <CardContent className="pt-6 pb-5 text-center flex flex-col gap-3">
                  <div>
                    <div className="text-5xl font-black text-primary">{cp.credits}</div>
                    <div className="text-sm font-semibold text-foreground">Credits</div>
                  </div>
                  <div>
                    <div className="text-3xl font-black text-foreground">{cp.price}</div>
                    <div className="text-xs text-muted-foreground">{cp.per}</div>
                    {cp.save && <div className="text-xs font-bold text-green-400 mt-0.5">{cp.save}</div>}
                  </div>
                  <ul className="text-xs text-muted-foreground space-y-1 text-left">
                    {cp.examples.map((e, i) => <li key={i} className="flex items-center gap-1.5"><Check className="w-3 h-3 text-green-400 shrink-0" />{e}</li>)}
                  </ul>
                  <Button
                    className={`w-full font-bold ${cp.popular ? 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/30' : ''}`}
                    variant={cp.popular ? 'default' : 'outline'}
                    disabled={loadingKey === cp.key}
                    onClick={() => checkout(cp.key)}
                  >
                    {loadingKey === cp.key
                      ? <Loader2 className="w-4 h-4 animate-spin" />
                      : <><CreditCard className="w-4 h-4 mr-1.5" />Buy {cp.credits} Credits</>}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ── Testimonials ─────────────────────────────────────────── */}
        <div>
          <h2 className="text-2xl font-black text-center mb-6">Real People. Real Results.</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {TESTIMONIALS.map((t, i) => (
              <Card key={i} className="border-border">
                <CardContent className="pt-5 pb-4">
                  <div className="flex gap-0.5 mb-3">
                    {[...Array(5)].map((_, j) => <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
                  </div>
                  <p className="text-sm text-foreground/90 mb-3 italic leading-relaxed">"{t.quote}"</p>
                  <div>
                    <p className="text-sm font-bold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* ── Guarantees ───────────────────────────────────────────── */}
        <Card className="bg-gradient-to-br from-primary/10 to-purple-500/10 border border-primary/30">
          <CardContent className="pt-6 pb-6 text-center">
            <h3 className="font-black text-xl text-foreground mb-2">No Risk. Just Results.</h3>
            <p className="text-sm text-muted-foreground mb-6 max-w-lg mx-auto">
              Start free, try credits, or go all-in with a subscription. Switch or cancel anytime — no questions asked.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-foreground font-medium">
              <span className="flex items-center gap-2"><Shield className="w-4 h-4 text-green-400" /> 30-day money-back guarantee</span>
              <span className="flex items-center gap-2"><RefreshCw className="w-4 h-4 text-primary" /> Cancel anytime</span>
              <span className="flex items-center gap-2"><TrendingUp className="w-4 h-4 text-purple-400" /> Instant credit delivery</span>
            </div>
            <p className="text-xs text-muted-foreground mt-4 italic">
              "Your resume should not be getting ignored. Let's fix that." — ResumeVault AI
            </p>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}