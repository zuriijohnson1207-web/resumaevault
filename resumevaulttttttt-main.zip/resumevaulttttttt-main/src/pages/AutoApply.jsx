import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Search, ExternalLink, MapPin, DollarSign, Clock, Target, Loader2,
  AlertCircle, Briefcase, Check, CheckCircle2, BookmarkPlus, Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Link } from 'react-router-dom';
import PageHeader from '@/components/PageHeader';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';

const scoreColor = (s) => {
  if (s >= 90) return 'bg-green-500/20 text-green-300 border-green-500/30';
  if (s >= 75) return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
  return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
};

export default function LiveJobs() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [jobTitle, setJobTitle] = useState('');
  const [location, setLocation] = useState('');
  const [jobType, setJobType] = useState('any');
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [searched, setSearched] = useState(false);
  const [savedJobs, setSavedJobs] = useState(new Set());

  const [viewJob, setViewJob] = useState(null);
  const [confirmApply, setConfirmApply] = useState(null);
  const [confirmStatus, setConfirmStatus] = useState('');

  const search = async () => {
    if (!jobTitle.trim()) {
      toast({ title: 'Enter a job title', variant: 'destructive' });
      return;
    }

    setLoading(true);
    setSearched(true);
    setJobs([]);

    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `FIND ONLY REAL, VERIFIED JOB LISTINGS for: "${jobTitle}" ${location ? `in ${location}` : 'Remote'}.

SEARCH INSTRUCTIONS:
- Use Google Jobs + Indeed + LinkedIn + company career pages ONLY
- Verify each link works by checking it exists on the actual site
- Only return jobs posted in the LAST 30 DAYS
- Verify the company exists and is real

CRITICAL FILTERS (REJECT ANY THAT DON'T MEET ALL):
✅ MUST have: valid apply_url (http/https link that actually works)
✅ MUST have: real company name (not fake/generic)
✅ MUST have: real job description (2-3 sentences minimum)
✅ MUST match: job title keywords
✅ MUST be: posted recently (1-30 days)

❌ REJECT if:
- No working apply link
- Placeholder/fake URL
- Generic job board without real company
- Title doesn't match search
- Posted >30 days ago
- Broken/404 links
- Unrealistic match scores

For EACH verified job, return:
- title: exact job title
- company: real legal company name
- location: city, state OR "Remote"
- job_type: full-time, part-time, contract, internship
- is_remote: true or false
- salary: only if publicly listed, else ""
- posted_date: "X days ago" or "1 week ago"
- description: real job duties (2-3 sentences)
- match_score: 60-100 (realistic based on actual match)
- match_reasons: array of 2-3 real reasons this matches
- source: "Indeed" or "Company Site" or "LinkedIn"
- apply_url: VERIFIED working link (must start with http)

Return MINIMUM 5-8 real verified jobs. ZERO false jobs.`,
        add_context_from_internet: true,
        model: 'gemini_3_1_pro',
        response_json_schema: {
          type: 'object',
          properties: {
            jobs: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  company: { type: 'string' },
                  location: { type: 'string' },
                  job_type: { type: 'string' },
                  is_remote: { type: 'boolean' },
                  salary: { type: 'string' },
                  posted_date: { type: 'string' },
                  description: { type: 'string' },
                  match_score: { type: 'number' },
                  match_reasons: { type: 'array', items: { type: 'string' } },
                  source: { type: 'string' },
                  apply_url: { type: 'string' }
                }
              }
            }
          }
        }
      });

      // Strict validation: only include jobs with valid, real data
      const filtered = (res.jobs || [])
        .filter(j => {
          const hasValidUrl = j.apply_url && (j.apply_url.startsWith('http://') || j.apply_url.startsWith('https://'));
          const hasTitle = j.title && j.title.trim().length > 3;
          const hasCompany = j.company && j.company.trim().length > 2;
          const hasDescription = j.description && j.description.trim().length > 10;
          const hasLocation = j.location && j.location.trim().length > 0;
          const validScore = j.match_score >= 60 && j.match_score <= 100;
          
          return hasValidUrl && hasTitle && hasCompany && hasDescription && hasLocation && validScore;
        })
        .slice(0, 15);

      if (filtered.length === 0) {
        toast({ title: 'No verified active jobs found. Try different keywords.', variant: 'default' });
      } else {
        setJobs(filtered);
        toast({ title: `Found ${filtered.length} verified live jobs`, variant: 'default' });
      }
    } catch (e) {
      console.error('Search error:', e);
      toast({ title: 'Could not search jobs. Check your internet connection.', variant: 'destructive' });
    }
    setLoading(false);
  };

  const saveJob = async (job) => {
    try {
      await base44.entities.Application.create({
        job_title: job.title,
        company: job.company,
        location: job.location,
        salary_range: job.salary,
        job_url: job.apply_url,
        status: 'saved',
        notes: `Source: ${job.source} | Match: ${job.match_score}%`,
      });
      setSavedJobs(prev => new Set([...prev, job.apply_url]));
      toast({ title: '✅ Saved to Application Tracker' });
    } catch (e) {
      toast({ title: 'Failed to save job', variant: 'destructive' });
    }
  };

  const handleApplyClick = (job) => {
    setConfirmApply(job);
    setConfirmStatus('');
  };

  const markAsApplied = async (status) => {
    if (!confirmApply || !status) return;

    try {
      await base44.entities.Application.create({
        job_title: confirmApply.title,
        company: confirmApply.company,
        location: confirmApply.location,
        salary_range: confirmApply.salary,
        job_url: confirmApply.apply_url,
        status: status,
        applied_date: new Date().toISOString().split('T')[0],
        notes: `Source: ${confirmApply.source} | Match: ${confirmApply.match_score}%`,
      });
      toast({ title: `✅ Marked as "${status}"` });
      setConfirmApply(null);
    } catch (e) {
      toast({ title: 'Failed to update status', variant: 'destructive' });
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <PageHeader
        icon={Search}
        title="Live Jobs"
        subtitle="Find real, active job listings with working apply links"
      />

      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-1">
              <label className="text-xs font-medium mb-1 block">Job Title / Keywords *</label>
              <Input
                placeholder="React Developer, Nurse, Sales..."
                value={jobTitle}
                onChange={e => setJobTitle(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && search()}
              />
            </div>
            <div>
              <label className="text-xs font-medium mb-1 block">Location</label>
              <Input
                placeholder="City, State or Remote"
                value={location}
                onChange={e => setLocation(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && search()}
              />
            </div>
            <div>
              <label className="text-xs font-medium mb-1 block">Job Type</label>
              <select
                value={jobType}
                onChange={e => setJobType(e.target.value)}
                className="w-full text-sm bg-card border border-border rounded-md px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-primary h-9"
              >
                <option value="any">Any Type</option>
                <option value="full-time">Full-time</option>
                <option value="part-time">Part-time</option>
                <option value="contract">Contract</option>
                <option value="remote">Remote Only</option>
                <option value="internship">Internship</option>
              </select>
            </div>
          </div>
          <Button
            onClick={search}
            disabled={loading || !jobTitle.trim()}
            className="bg-primary text-primary-foreground gap-2 w-full"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Searching live jobs...
              </>
            ) : (
              <>
                <Search className="w-4 h-4" /> Search Live Jobs
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {loading && (
        <div className="text-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Searching Google, Indeed, LinkedIn, company sites...</p>
          <p className="text-xs text-muted-foreground mt-1">Finding active, verified listings</p>
        </div>
      )}

      {searched && !loading && jobs.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Briefcase className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">No active jobs found.</p>
          <p className="text-xs mt-1">Try broader keywords or check a different location.</p>
        </div>
      )}

      {jobs.length > 0 && (
        <div className="mb-3">
          <p className="text-sm font-medium text-muted-foreground">{jobs.length} live listings found</p>
        </div>
      )}

      <div className="space-y-3">
        {[...jobs].sort((a, b) => (b.match_score || 0) - (a.match_score || 0)).map((job, idx) => (
          <Card key={idx} className="transition-all hover:border-primary/40">
            <CardContent className="pt-4 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="font-bold text-foreground">{job.title}</span>
                    <span className="text-muted-foreground text-sm">@ {job.company}</span>
                    <Badge className={`text-xs border ${scoreColor(job.match_score || 0)}`}>
                      <Target className="w-2.5 h-2.5 mr-1" />
                      {job.match_score || 0}% match
                    </Badge>
                  </div>

                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-2">
                    {job.location && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {job.location}
                      </span>
                    )}
                    {job.is_remote && (
                      <span className="flex items-center gap-1 text-blue-300">
                        🌐 Remote
                      </span>
                    )}
                    {job.job_type && (
                      <span className="text-primary/70">{job.job_type}</span>
                    )}
                    {job.salary && (
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />
                        {job.salary}
                      </span>
                    )}
                    {job.posted_date && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {job.posted_date}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{job.description}</p>

                  {job.match_reasons && job.match_reasons.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs text-green-400 mb-1">✓ Why it matches:</p>
                      <div className="flex flex-wrap gap-1">
                        {job.match_reasons.slice(0, 3).map((reason, i) => (
                          <span key={i} className="text-xs bg-green-500/10 text-green-300 px-2 py-0.5 rounded">
                            {reason}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-row sm:flex-col gap-2 shrink-0">
                  <a href={job.apply_url} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" className="gap-1 text-xs w-full bg-primary text-primary-foreground">
                      <ExternalLink className="w-3 h-3" /> View Job
                    </Button>
                  </a>
                  <Button
                    size="sm"
                    onClick={() => handleApplyClick(job)}
                    variant="outline"
                    className="gap-1 text-xs w-full"
                  >
                    <CheckCircle2 className="w-3 h-3" /> Applied?
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => saveJob(job)}
                    disabled={savedJobs.has(job.apply_url)}
                    variant="outline"
                    className={`gap-1 text-xs w-full ${savedJobs.has(job.apply_url) ? 'border-green-500/40 text-green-400' : ''}`}
                  >
                    {savedJobs.has(job.apply_url) ? (
                      <>
                        <Check className="w-3 h-3" /> Saved
                      </>
                    ) : (
                      <>
                        <BookmarkPlus className="w-3 h-3" /> Save
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Mark Applied Dialog */}
      <Dialog open={!!confirmApply} onOpenChange={v => !v && setConfirmApply(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Did you submit this application?</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <div className="bg-secondary/30 rounded-lg p-3">
              <p className="text-sm font-semibold">{confirmApply?.title}</p>
              <p className="text-xs text-muted-foreground">@ {confirmApply?.company}</p>
            </div>
            <p className="text-sm text-muted-foreground">
              Tell us the status so we can track your progress.
            </p>
          </div>
          <DialogFooter className="gap-2 flex-wrap">
            <Button
              variant="outline"
              onClick={() => setConfirmApply(null)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={() => markAsApplied('saved')}
              variant="outline"
              className="flex-1 text-blue-300"
            >
              Saved for Later
            </Button>
            <Button
              onClick={() => markAsApplied('applied')}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              Yes, I Applied
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}