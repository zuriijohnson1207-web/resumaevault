import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Tag, Plus, Pencil, Trash2, ExternalLink, Bell,
  TrendingUp, Briefcase, CheckCircle2, XCircle, Clock,
  Filter, Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import PageHeader from '@/components/PageHeader';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

const STATUS_CONFIG = {
  saved:        { label: 'Saved',        color: 'bg-gray-500/20 text-gray-300 border-gray-500/30',       icon: '🔖' },
  applied:      { label: 'Applied',      color: 'bg-blue-500/20 text-blue-300 border-blue-500/30',       icon: '📤' },
  interviewing: { label: 'Interviewing', color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30', icon: '🎤' },
  offer:        { label: 'Offer',        color: 'bg-green-500/20 text-green-300 border-green-500/30',    icon: '🎉' },
  rejected:     { label: 'Rejected',     color: 'bg-red-500/20 text-red-300 border-red-500/30',          icon: '❌' },
};

const emptyForm = {
  job_title: '', company: '', job_url: '', status: 'applied',
  applied_date: '', notes: '', salary_range: '', location: '',
};

const PIPELINE_STAGES = ['saved', 'applied', 'interviewing', 'offer', 'rejected'];

export default function ApplicationTracker() {
  const { toast } = useToast();
  const [applications, setApplications] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const [view, setView] = useState('list');

  const load = () => base44.entities.Application.list('-created_date').then(setApplications);
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (editId) {
      await base44.entities.Application.update(editId, form);
    } else {
      await base44.entities.Application.create(form);
    }
    setOpen(false);
    setForm(emptyForm);
    setEditId(null);
    load();
    toast({ title: editId ? '✅ Application updated!' : '✅ Application added!' });
  };

  const remove = async (id) => {
    await base44.entities.Application.delete(id);
    load();
    toast({ title: 'Application removed.' });
  };

  const openEdit = (app) => {
    setForm({ ...emptyForm, ...app });
    setEditId(app.id);
    setOpen(true);
  };

  const updateStatus = async (id, status) => {
    await base44.entities.Application.update(id, { status });
    load();
  };

  const counts = {
    total: applications.length,
    applied: applications.filter(a => a.status === 'applied').length,
    interviewing: applications.filter(a => a.status === 'interviewing').length,
    offer: applications.filter(a => a.status === 'offer').length,
    rejected: applications.filter(a => a.status === 'rejected').length,
  };

  const filtered = statusFilter === 'all' ? applications : applications.filter(a => a.status === statusFilter);
  const byStatus = (s) => applications.filter(a => a.status === s);

  const followUps = applications.filter(a => {
    if (a.status !== 'applied' || !a.applied_date) return false;
    const daysSince = Math.floor((Date.now() - new Date(a.applied_date)) / 86400000);
    return daysSince >= 7;
  });

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      <PageHeader icon={Tag} title="Application Tracker" subtitle="Track every application, interview, and offer in one place" />

      {followUps.length > 0 && (
        <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <p className="text-sm text-yellow-300 font-medium flex items-center gap-2 mb-1">
            <Bell className="w-4 h-4" /> Follow-up Reminders ({followUps.length})
          </p>
          <div className="space-y-1">
            {followUps.map(a => (
              <div key={a.id} className="flex items-center justify-between text-xs text-yellow-200/80">
                <span>{a.job_title} @ {a.company} — applied {a.applied_date}</span>
                <Link to="/follow-up-email" className="underline text-primary text-xs">Generate Follow-up →</Link>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
        {[
          { label: 'Total', value: counts.total, color: 'text-foreground', icon: Briefcase },
          { label: 'Applied', value: counts.applied, color: 'text-blue-400', icon: TrendingUp },
          { label: 'Interviewing', value: counts.interviewing, color: 'text-yellow-400', icon: Clock },
          { label: 'Offers', value: counts.offer, color: 'text-green-400', icon: CheckCircle2 },
          { label: 'Rejected', value: counts.rejected, color: 'text-red-400', icon: XCircle },
        ].map(s => (
          <Card key={s.label} className="cursor-pointer hover:border-primary/40 transition-colors"
            onClick={() => setStatusFilter(prev => prev === s.label.toLowerCase() ? 'all' : s.label.toLowerCase())}>
            <CardContent className="pt-4 pb-4 text-center">
              <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <Button onClick={() => { setForm(emptyForm); setEditId(null); setOpen(true); }} className="bg-primary text-primary-foreground gap-2">
          <Plus className="w-4 h-4" /> Add Application
        </Button>
        <div className="flex gap-1 bg-secondary/30 rounded-lg p-1">
          {['list', 'pipeline'].map(v => (
            <button key={v} onClick={() => setView(v)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${view === v ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
              {v}
            </button>
          ))}
        </div>
        {view === 'list' && (
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-muted-foreground" />
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
              className="text-sm bg-card border border-border rounded-lg px-2 py-1.5 text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
              <option value="all">All Status</option>
              {Object.entries(STATUS_CONFIG).map(([v, c]) => (
                <option key={v} value={v}>{c.icon} {c.label}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {applications.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Briefcase className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="font-medium">No applications yet.</p>
            <p className="text-sm mt-1">Search for jobs in <Link to="/auto-apply" className="text-primary underline">Job Search</Link> or add manually above.</p>
          </CardContent>
        </Card>
      ) : view === 'pipeline' ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {PIPELINE_STAGES.map(stage => {
            const stageApps = byStatus(stage);
            const cfg = STATUS_CONFIG[stage];
            return (
              <div key={stage} className="min-w-[160px]">
                <div className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg mb-2 border ${cfg.color}`}>
                  <span className="text-sm">{cfg.icon}</span>
                  <span className="text-xs font-semibold">{cfg.label}</span>
                  <span className="ml-auto text-xs font-bold">{stageApps.length}</span>
                </div>
                <div className="space-y-2">
                  {stageApps.map(app => (
                    <Card key={app.id} className="hover:border-primary/30 transition-colors">
                      <CardContent className="p-3">
                        <p className="font-semibold text-xs leading-tight mb-1">{app.job_title}</p>
                        <p className="text-xs text-muted-foreground">{app.company}</p>
                        {app.applied_date && <p className="text-xs text-muted-foreground mt-1">📅 {app.applied_date}</p>}
                        <div className="flex gap-1 mt-2">
                          {app.job_url && (
                            <a href={app.job_url} target="_blank" rel="noreferrer">
                              <Button size="icon" variant="ghost" className="w-6 h-6"><ExternalLink className="w-3 h-3" /></Button>
                            </a>
                          )}
                          <Button size="icon" variant="ghost" className="w-6 h-6" onClick={() => openEdit(app)}><Pencil className="w-3 h-3" /></Button>
                          <Button size="icon" variant="ghost" className="w-6 h-6 text-destructive" onClick={() => remove(app.id)}><Trash2 className="w-3 h-3" /></Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(app => (
            <Card key={app.id} className="hover:border-primary/30 transition-colors">
              <CardContent className="pt-3 pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-semibold text-sm">{app.job_title}</span>
                      <span className="text-muted-foreground text-sm">@ {app.company}</span>
                      <Badge className={`text-xs border ${STATUS_CONFIG[app.status]?.color}`}>
                        {STATUS_CONFIG[app.status]?.icon} {STATUS_CONFIG[app.status]?.label}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                      {app.location && <span>📍 {app.location}</span>}
                      {app.salary_range && <span>💰 {app.salary_range}</span>}
                      {app.applied_date && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {app.applied_date}</span>}
                      {app.job_url && (
                        <a href={app.job_url} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-primary hover:underline">
                          <ExternalLink className="w-3 h-3" /> View Job
                        </a>
                      )}
                    </div>
                    {app.notes && <p className="text-xs text-muted-foreground mt-1 italic line-clamp-1">{app.notes}</p>}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <select value={app.status} onChange={e => updateStatus(app.id, e.target.value)}
                      className="text-xs bg-card border border-border rounded px-1.5 py-1 text-foreground focus:outline-none focus:ring-1 focus:ring-primary mr-1">
                      {Object.entries(STATUS_CONFIG).map(([v, c]) => (
                        <option key={v} value={v}>{c.label}</option>
                      ))}
                    </select>
                    <Button size="icon" variant="ghost" onClick={() => openEdit(app)} className="w-7 h-7"><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(app.id)} className="w-7 h-7 text-destructive hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm">No {statusFilter} applications.</div>
          )}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editId ? 'Edit Application' : 'Add Application'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium mb-1 block">Job Title *</label>
                <Input value={form.job_title} onChange={e => setForm(f => ({ ...f, job_title: e.target.value }))} placeholder="Software Engineer" />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block">Company *</label>
                <Input value={form.company} onChange={e => setForm(f => ({ ...f, company: e.target.value }))} placeholder="Google" />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block">Status</label>
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(STATUS_CONFIG).map(([v, c]) => (
                      <SelectItem key={v} value={v}>{c.icon} {c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block">Applied Date</label>
                <Input type="date" value={form.applied_date} onChange={e => setForm(f => ({ ...f, applied_date: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block">Location</label>
                <Input value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="San Francisco, CA" />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block">Salary Range</label>
                <Input value={form.salary_range} onChange={e => setForm(f => ({ ...f, salary_range: e.target.value }))} placeholder="$120k–$150k" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium mb-1 block">Job URL</label>
              <Input value={form.job_url} onChange={e => setForm(f => ({ ...f, job_url: e.target.value }))} placeholder="https://..." />
            </div>
            <div>
              <label className="text-xs font-medium mb-1 block">Notes / Follow-up</label>
              <Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Interview date, recruiter name, follow-up needed..." className="min-h-[80px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={!form.job_title || !form.company} className="bg-primary text-primary-foreground">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}