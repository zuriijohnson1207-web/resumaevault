import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useUnlockedFeatures } from '@/hooks/useRealTimeAccess';
import { Zap, Briefcase, TrendingUp, Star, Search, FileText, Mail, Send, Crown, X, History, ChevronDown, Loader2 } from 'lucide-react';
import ZUGreeting from '@/components/ZUGreeting';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import CreditHistoryPanel from '@/components/credits/CreditHistoryPanel';
import GetStartedGuide from '@/components/dashboard/GetStartedGuide';
import OverrideBadges from '@/components/dashboard/OverrideBadges';
import FeatureUnlockDisplay from '@/components/FeatureUnlockDisplay';
import DashboardStatsCard from '@/components/dashboard/DashboardStatsCard';
import PlanCard from '@/components/dashboard/PlanCard';
import ZUChatModal from '@/components/ZUChatModal';

const UnlockSystemTester = lazy(() => import('@/components/UnlockSystemTester'));

const CREDIT_COSTS = {
  'AI Resume': 5,
  'Cover Letter': 3,
  'Job Analysis': 2,
  'Follow-Up Email': 2,
  'Mock Interview': 10,
  'Auto Apply': 2,
  'Salary Neg.': 3,
  'Career Roadmap': 3,
};

const quickActions = [
  { label: 'Analyze Job', desc: 'Extract ATS keywords from a job posting', icon: Search, path: '/job-analyzer', color: 'text-orange-400' },
  { label: 'Build Resume', desc: 'Generate a tailored resume', icon: FileText, path: '/resume-builder', color: 'text-blue-400' },
  { label: 'Cover Letter', desc: 'Write a compelling cover letter', icon: Mail, path: '/cover-letter', color: 'text-green-400' },
  { label: 'Follow-Up', desc: 'Craft a professional follow-up email', icon: Send, path: '/follow-up-email', color: 'text-purple-400' },
];

const premiumTools = [
  { label: 'Mock Interview', desc: 'Practice with AI-generated questions', path: '/mock-interview', icon: '🎤' },
  { label: 'Salary Negotiation', desc: 'Ready-to-use negotiation scripts', path: '/salary-negotiation', icon: '💰' },
  { label: 'Career Roadmap', desc: 'Step-by-step plan to your goals', path: '/career-roadmap', icon: '🗺️' },
  { label: 'Portfolio Ideas', desc: 'Impress recruiters with standout projects', path: '/portfolio-ideas', icon: '💡' },
];

export default function Dashboard() {
  const [profile, setProfile] = useState(null);
  const [applications, setApplications] = useState([]);
  const [showBanner, setShowBanner] = useState(true);
  const [expandCredits, setExpandCredits] = useState(false);
  const [zuChatOpen, setZuChatOpen] = useState(false);
  const { user } = useAuth();
  const { unlocked, loading: unlockLoading, refetch: refetchUnlocked } = useUnlockedFeatures();
  const location = useLocation();

  const loadProfile = useCallback(async () => {
    if (!user?.email) return;
    let retries = 0;
    const maxRetries = 3;
    
    const attemptLoad = async () => {
      try {
        // Filter by created_by to always get THIS user's own profile
        const profiles = await base44.entities.UserProfile.filter({ created_by: user.email });
        if (profiles.length > 0) {
          setProfile(profiles[0]);
        } else {
          // Don't auto-populate full_name from auth — let the user set it themselves
          const newProfile = await base44.entities.UserProfile.create({
            email: user.email,
            subscription_plan: 'free',
            ai_credits: 0,
            monthly_uses: 0,
          });
          setProfile(newProfile);
        }
      } catch (e) {
        console.error('Profile load error (attempt ' + (retries + 1) + '):', e);
        if (retries < maxRetries) {
          retries++;
          await new Promise(r => setTimeout(r, 1000 * retries)); // exponential backoff
          await attemptLoad();
        }
      }
    };
    
    await attemptLoad();
  }, [user?.email]);

  useEffect(() => {
    if (user) {
      loadProfile();
      base44.entities.Application.list().then(setApplications).catch(() => {});
    }
  }, [user, loadProfile]);

  // Refresh profile after returning from Stripe payment + real-time subscription
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('success')) {
      let attempts = 0;
      const interval = setInterval(async () => {
        await loadProfile();
        attempts++;
        if (attempts >= 8) clearInterval(interval);
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [location.search, loadProfile]);

  // Real-time profile sync (plan/credits update instantly, ANY UserProfile change refreshes THIS user)
  useEffect(() => {
    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      if (event.type === 'update' || event.type === 'create') {
        // Only update if it's THIS user's profile
        if (event.data?.created_by?.toLowerCase() === user?.email?.toLowerCase()) {
          setProfile(event.data);
        }
      }
    });
    return () => unsubscribe();
  }, [user?.email]);

  const stats = {
    total: applications.length,
    active: applications.filter(a => a.status === 'applied' || a.status === 'interviewing').length,
    interviews: applications.filter(a => a.status === 'interviewing').length,
  };

  const credits = profile?.ai_credits ?? 0;
  const plan = profile?.subscription_plan ?? 'free';
  const params = new URLSearchParams(location.search);
  const paymentSuccess = params.get('success');

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Payment success */}
      {paymentSuccess && (
        <div className="bg-green-500/10 border border-green-500/30 text-green-400 rounded-xl px-4 py-3 mb-4 text-sm font-medium">
          🎉 Payment successful! Your plan & credits have been updated. Welcome to the next level!
        </div>
      )}
      {/* Profile setup nudge — shown prominently until name is set */}
      {!profile?.full_name && (
        <div className="relative mb-6 rounded-xl bg-gradient-to-r from-yellow-500 via-orange-500 to-primary p-5 text-white shadow-lg border-2 border-yellow-400/60">
          <div className="flex items-center gap-2 mb-1">
            <Star className="w-5 h-5 text-white" />
            <span className="font-bold text-xl text-white drop-shadow">👋 First, tell us your name!</span>
          </div>
          <p className="text-white text-sm mb-3 font-medium">
            Complete your profile so ZU knows who you are and can personalize everything — resumes, cover letters, greetings, and more. It only takes 60 seconds!
          </p>
          <div className="flex gap-2 flex-wrap">
            <Link to="/profile"><Button size="sm" className="bg-white text-orange-700 hover:bg-white/90 font-bold shadow">✍️ Complete My Profile →</Button></Link>
            <Link to="/pricing"><Button size="sm" variant="outline" className="border-white text-white hover:bg-white/20 font-semibold">View Plans</Button></Link>
          </div>
        </div>
      )}

      {/* Welcome Banner — only shown after name is set */}
      {showBanner && profile?.full_name && (
        <div className="relative mb-6 rounded-xl bg-gradient-to-r from-yellow-500 via-orange-500 to-primary p-5 text-white shadow-lg">
          <button onClick={() => setShowBanner(false)} className="absolute top-3 right-3 text-white/80 hover:text-white">
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 mb-1">
            <Zap className="w-5 h-5 text-white" />
            <span className="font-bold text-xl text-white drop-shadow">Welcome, {profile.full_name.split(' ')[0]} 👋</span>
          </div>
          <p className="text-white text-sm mb-3 font-medium">
            Get started: Paste a job description → Generate a tailored resume & cover letter in seconds!
          </p>
          <div className="flex gap-2 flex-wrap">
            <Link to="/job-analyzer"><Button size="sm" className="bg-white text-orange-700 hover:bg-white/90 font-bold shadow">Analyze a Job →</Button></Link>
            <Link to="/pricing"><Button size="sm" variant="outline" className="border-white text-white hover:bg-white/20 font-semibold">Upgrade Plans</Button></Link>
          </div>
        </div>
      )}

      {/* Tagline */}
      <div className="text-center text-primary text-xs font-bold tracking-widest uppercase mb-6">
        ⚡ Beat the ATS in 60 seconds • God-Mode Your Job Hunt
      </div>

      {/* ZU AI Greeting */}
      <ZUGreeting user={user} profile={profile} />



      {/* Get Started Guide */}
      <GetStartedGuide onAskZu={() => setZuChatOpen(true)} />

      {/* Unlocked Features Display */}
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-3">Your Unlocked Features</h2>
        <FeatureUnlockDisplay />
      </div>

      {/* Dev Tester — lazy load */}
      {import.meta.env.MODE === 'development' && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3">🧪 Dev Tester</h2>
          <Suspense fallback={<div className="p-6 text-center"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></div>}>
            <UnlockSystemTester />
          </Suspense>
        </div>
      )}

      {/* Stats row with memoized components */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Credits */}
        <Card className="col-span-1 md:col-span-1 border-primary/30 bg-card cursor-pointer md:cursor-default" onClick={() => setExpandCredits(!expandCredits)}>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center justify-between gap-2 text-base">
              <span className="flex items-center gap-2"><Zap className="w-4 h-4 text-primary" /> AI Credits</span>
              <ChevronDown className={`w-4 h-4 text-primary md:hidden transition-transform ${expandCredits ? 'rotate-180' : ''}`} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-4xl font-bold">{credits}</span>
                <span className="text-muted-foreground ml-1 text-sm">credits</span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary-foreground" />
              </div>
            </div>
            {/* Collapsible content on mobile, always visible on desktop */}
            <div className={`md:block ${expandCredits ? 'block' : 'hidden'}`}>
              <div className="text-xs text-muted-foreground mb-1 font-semibold uppercase tracking-wide">Credit Usage:</div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs mb-3">
                {Object.entries(CREDIT_COSTS).map(([k, v]) => (
                  <div key={k} className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block"></span>
                    <span className="text-muted-foreground">{k}: {v} credits</span>
                  </div>
                ))}
              </div>
              <Link to="/pricing">
                <Button className="w-full bg-primary text-primary-foreground text-xs py-1 h-8">+ Buy Credits</Button>
              </Link>
              <p className="text-xs text-muted-foreground mt-2 text-center">💡 Get credits to use AI features or upgrade to Pro for 80 resumes/month!</p>
            </div>
          </CardContent>
        </Card>

        {/* Memoized stat cards */}
        <DashboardStatsCard icon={Briefcase} label="Total Applications" value={stats.total} />
        <DashboardStatsCard icon={TrendingUp} label="Active Applications" value={stats.active} color="text-green-400" />
      </div>

      {/* Memoized plan card */}
      <PlanCard plan={plan} credits={credits} />

      {/* Quick Actions */}
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {quickActions.map(a => (
            <Link key={a.path} to={a.path}>
              <Card className="border-border hover:border-primary/50 transition-colors cursor-pointer h-full">
                <CardContent className="pt-4 pb-4">
                  <a.icon className={`w-5 h-5 mb-2 ${a.color}`} />
                  <div className="font-semibold text-sm mb-1">{a.label}</div>
                  <div className="text-xs text-muted-foreground">{a.desc}</div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Credit Activity */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold flex items-center gap-2"><History className="w-4 h-4 text-muted-foreground" /> Recent Credit Activity</h2>
          <Link to="/profile?tab=history" className="text-xs text-primary hover:underline">View all →</Link>
        </div>
        <Card>
          <CardContent className="pt-4 pb-4">
            <CreditHistoryPanel limit={5} compact />
          </CardContent>
        </Card>
      </div>

      {/* Premium Tools */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold">Premium Tools</h2>
          {plan === 'free' && <Link to="/pricing" className="text-xs text-primary hover:underline">Unlock all →</Link>}
          {plan === 'pro' && <Badge className="bg-primary/20 text-primary text-xs">Pro Access</Badge>}
          {plan === 'elite' && <Badge className="bg-purple-500/20 text-purple-300 text-xs">Elite Access</Badge>}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {premiumTools.map(t => {
            const unlocked = plan === 'pro' || plan === 'elite';
            return (
              <Link key={t.path} to={t.path}>
                <Card className={`border-border hover:border-primary/50 transition-colors cursor-pointer h-full ${unlocked ? '' : 'opacity-60'}`}>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="text-2xl">{t.icon}</div>
                      {!unlocked && <span className="text-xs text-muted-foreground">🔒</span>}
                      {unlocked && <span className="text-xs text-green-400">✓</span>}
                    </div>
                    <div className="font-semibold text-sm mb-1">{t.label}</div>
                    <div className="text-xs text-muted-foreground">{t.desc}</div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* ZU Chat Modal */}
      <ZUChatModal isOpen={zuChatOpen} onClose={() => setZuChatOpen(false)} />
    </div>
  );
}