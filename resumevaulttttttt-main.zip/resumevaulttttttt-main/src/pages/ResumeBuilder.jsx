import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import {
  FileText, Sparkles, Copy, Download, Save, ChevronDown, ChevronUp,
  Loader2, CheckCircle2, AlertCircle, LayoutTemplate, Lightbulb,
  FileDown, Upload, GitCompare, Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/PageHeader';
import { useAuth } from '@/lib/AuthContext';
import { Link } from 'react-router-dom';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import PlanGate from '@/components/PlanGate';
import TemplateSelector from '@/components/resume/TemplateSelector';
import SuggestedJobs from '@/components/resume/SuggestedJobs';
import ATSAnalysisPanel from '@/components/resume/ATSAnalysisPanel';
import UploadAndImprove from '@/components/resume/UploadAndImprove';
import ResumeComparison from '@/components/resume/ResumeComparison';
import QuickResumeMode from '@/components/resume/QuickResumeMode';
import { RESUME_TEMPLATES, buildResumePrompt, buildSampleResumePrompt } from '@/data/resumeTemplates';
import { FlaskConical, Info } from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import HelpTip from '@/components/HelpTip';

const TABS = [
  { id: 'form', label: 'Build Resume', icon: FileText },
  { id: 'quick', label: 'Quick Mode', icon: Zap },
  { id: 'templates', label: 'Templates', icon: LayoutTemplate },
  { id: 'upload', label: 'Upload & Improve', icon: Upload },
  { id: 'compare', label: 'Compare', icon: GitCompare },
  { id: 'suggested', label: 'Job Matches', icon: Lightbulb },
];

export default function ResumeBuilder() {
  const { user } = useAuth();
  const { canUse, incrementUsage, plan, getUsage, profile: planProfile } = usePlanLimits();
  const [profile, setProfile] = useState(null);
  const credits = planProfile?.ai_credits ?? 0;
  const [activeTab, setActiveTab] = useState('form');
  const [selectedTemplate, setSelectedTemplate] = useState(RESUME_TEMPLATES[0]);
  const [generatedResume, setGeneratedResume] = useState('');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveTitle, setSaveTitle] = useState('');
  const [isSampleMode, setIsSampleMode] = useState(false);
  const [sampleConfirmed, setSampleConfirmed] = useState(false);

  // Form fields
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [careerGoal, setCareerGoal] = useState('');
  const [summary, setSummary] = useState('');
  const [skills, setSkills] = useState('');
  const [experience, setExperience] = useState('');
  const [education, setEducation] = useState('');
  const [hsGradYear, setHsGradYear] = useState('');
  const [certifications, setCertifications] = useState('');
  const [projects, setProjects] = useState('');
  const [resumeLength, setResumeLength] = useState('full');

  useEffect(() => {
    if (!user?.email) return;
    
    // Memoize profile parsing to avoid redundant computations
    const parseProfile = (p) => {
      if (!p) return null;
      return {
        fullName: p.full_name || '',
        email: p.email || user.email || '',
        phone: p.phone || '',
        location: p.location || '',
        linkedin: p.linkedin_url || '',
        summary: p.professional_summary || '',
        skills: p.skills || '',
        experience: p.experience?.length ? p.experience.map(e =>
          `${e.job_title} at ${e.company} (${e.start_date} - ${e.current ? 'Present' : e.end_date})\n${e.description || ''}`
        ).join('\n\n') : '',
        education: p.education?.length ? p.education.map(e =>
          `${e.degree} in ${e.field} - ${e.school} (${e.graduation_year})`
        ).join('\n') : '',
        certifications: p.certifications || '',
      };
    };
    
    base44.entities.UserProfile.filter({ created_by: user.email }).then(profiles => {
      const p = profiles[0];
      if (p) {
        setProfile(p);
        const parsed = parseProfile(p);
        setFullName(parsed.fullName);
        setEmail(parsed.email);
        setPhone(parsed.phone);
        setLocation(parsed.location);
        setLinkedin(parsed.linkedin);
        setSummary(parsed.summary);
        setSkills(parsed.skills);
        setExperience(parsed.experience);
        setEducation(parsed.education);
        setCertifications(parsed.certifications);
      }
    }).catch(e => console.error('Profile load:', e));
  }, [user?.email]);

  const formData = {
    fullName, email, phone, location, linkedin,
    summary, skills, experience, education, hsGradYear,
    certifications, projects, careerGoal, jobDescription,
    jobTitle, company, resumeLength,
  };

  const generate = async () => {
    if (!canUse('resume')) return;
    if (!jobTitle.trim() && !jobDescription.trim()) {
      toast.error('Please enter either a job title or paste a job description.');
      return;
    }
    setLoading(true);
    setSaved(false);
    setSampleConfirmed(false);
    const samplePersonalInfo = { fullName, email, phone, location, linkedin };
    const prompt = isSampleMode
      ? buildSampleResumePrompt(jobTitle || 'Software Engineer', company, jobDescription, selectedTemplate, samplePersonalInfo)
      : buildResumePrompt(formData, selectedTemplate);
    const res = await base44.integrations.Core.InvokeLLM({ prompt });
    setGeneratedResume(typeof res === 'string' ? res : JSON.stringify(res));
    await incrementUsage('resume');
    setLoading(false);
  };

  const openSaveDialog = () => {
    const defaultTitle = `${jobTitle}${company ? ` @ ${company}` : ''} — ${selectedTemplate.name}`;
    setSaveTitle(defaultTitle);
    setShowSaveDialog(true);
  };

  const save = async () => {
    const title = saveTitle.trim() || `${jobTitle}${company ? ` @ ${company}` : ''} — ${selectedTemplate.name}`;
    await base44.entities.Resume.create({
      title,
      job_title: jobTitle,
      company,
      content: generatedResume,
      type: 'tailored',
    });
    setSaved(true);
    setShowSaveDialog(false);
    toast.success('Resume saved to your library!');
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedResume);
    toast.success('Copied to clipboard!');
  };

  const downloadPDF = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html><head><title>Resume</title>
      <style>
        body { font-family: Arial, sans-serif; font-size: 11pt; margin: 0.75in; color: #111; line-height: 1.4; }
        pre { white-space: pre-wrap; font-family: Arial, sans-serif; font-size: 11pt; }
      </style>
      </head><body>
      <pre>${generatedResume.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
      </body></html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => { printWindow.print(); printWindow.close(); }, 400);
  };

  const downloadDOCX = () => {
    const content = generatedResume;
    const blob = new Blob([
      `\uFEFF<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body><w:p><w:r><w:t xml:space="preserve">${content.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'</w:t></w:r></w:p><w:p><w:r><w:t xml:space="preserve">')}</w:t></w:r></w:p></w:body>
</w:document>`
    ], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fullName || 'resume'}_${jobTitle || 'resume'}.docx`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('DOCX downloaded! Open in Microsoft Word for best formatting.');
  };

  const handleCompareGenerateOptimized = (resumeText, jd) => {
    setJobDescription(jd);
    setActiveTab('form');
    toast.success('Job description loaded! Scroll up and click Generate.');
  };

  return (
    <div className="p-3 md:p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <PageHeader icon={FileText} title="AI Resume Builder" subtitle="ATS-optimized resumes tailored to your dream job" />
        <Card className="border-primary/30 bg-primary/5 shrink-0">
          <CardContent className="pt-4 pb-4 flex items-center gap-3">
            <Zap className="w-5 h-5 text-primary" />
            <div>
              <div className="text-2xl font-bold text-primary">{credits}</div>
              <div className="text-xs text-muted-foreground font-medium">Credits Remaining</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab nav — scrollable on mobile */}
      <div className="flex gap-1 mb-6 bg-secondary/30 rounded-xl p-1 overflow-x-auto scrollbar-hide" role="tablist">
        {TABS.map(tab => (
          <button
            key={tab.id}
            role="tab"
            aria-selected={activeTab === tab.id}
            onClick={() => setActiveTab(tab.id)}
            title={tab.label}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap focus:outline-none focus:ring-2 focus:ring-primary ${
              activeTab === tab.id
                ? 'bg-card text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
            }`}
          >
            <tab.icon className="w-4 h-4 shrink-0" />
            <span className="sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Templates Tab */}
      {activeTab === 'templates' && (
        <Card>
          <CardContent className="pt-5">
            <TemplateSelector selected={selectedTemplate} onSelect={t => { setSelectedTemplate(t); setActiveTab('form'); }} />
          </CardContent>
        </Card>
      )}

      {/* Quick Resume Mode Tab */}
      {activeTab === 'quick' && (
        <QuickResumeMode onSaveResume={() => {}} />
      )}

      {/* Upload & Improve Tab */}
      {activeTab === 'upload' && <UploadAndImprove />}

      {/* Comparison Tab */}
      {activeTab === 'compare' && (
        <ResumeComparison onGenerateOptimized={handleCompareGenerateOptimized} />
      )}

      {/* Suggested Jobs Tab */}
      {activeTab === 'suggested' && (
        <Card>
          <CardContent className="pt-5">
            <SuggestedJobs
              profile={profile}
              onGenerateForJob={(title) => { setJobTitle(title); setActiveTab('form'); }}
            />
          </CardContent>
        </Card>
      )}

      {/* Form Tab — stacked on mobile, 3-column on large screens */}
      {activeTab === 'form' && (
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr_320px] gap-4 md:gap-6">

          {/* === LEFT: Input Form === */}
          <div className="space-y-4">

            {/* MODE TOGGLE */}
            <div className="flex rounded-xl border border-border overflow-hidden">
              <button
                type="button"
                onClick={() => { setIsSampleMode(false); setSampleConfirmed(false); setGeneratedResume(''); setSaved(false); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-sm font-semibold transition-all ${!isSampleMode ? 'bg-primary text-primary-foreground' : 'bg-secondary/40 text-muted-foreground hover:text-foreground'}`}
              >
                <FileText className="w-4 h-4" />
                Real Resume
              </button>
              <button
                type="button"
                onClick={() => { setIsSampleMode(true); setSampleConfirmed(false); setGeneratedResume(''); setSaved(false); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 text-sm font-semibold transition-all ${isSampleMode ? 'bg-primary text-primary-foreground' : 'bg-secondary/40 text-muted-foreground hover:text-foreground'}`}
              >
                <FlaskConical className="w-4 h-4" />
                Sample Mode
              </button>
            </div>

            {/* Mode description */}
            {isSampleMode ? (
              <div className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                <FlaskConical className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div className="text-xs text-blue-300 space-y-0.5">
                  <p className="font-semibold">Sample Resume Mode</p>
                  <p>AI generates a complete example resume — optionally add your personal info below so it appears on the resume. All experience, roles, and achievements will still be AI-generated examples.</p>
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl">
                <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                <div className="text-xs text-green-300 space-y-0.5">
                  <p className="font-semibold">Real Resume Mode</p>
                  <p>Only uses your provided information. Missing details get clear placeholders — never invented content.</p>
                </div>
              </div>
            )}

            {/* Selected Template Badge */}
            <div className="flex items-center gap-2 p-3 bg-primary/10 border border-primary/30 rounded-xl">
              <span className="text-xl">{selectedTemplate.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-primary">Template: {selectedTemplate.name}</p>
                <p className="text-xs text-muted-foreground">{selectedTemplate.description}</p>
              </div>
              <Button
                size="sm" variant="outline"
                onClick={() => setActiveTab('templates')}
                className="shrink-0 text-xs h-7 border-primary/30 text-primary"
                title="Switch to a different resume style or layout"
              >
                Change
              </Button>
            </div>

            {/* Personal info for Sample Mode */}
            {isSampleMode && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-4 h-4 text-primary" /> Your Info (optional)
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="sm:col-span-2">
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="sampleFullName">Full Name</label>
                    <Input id="sampleFullName" value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Jane Smith (leave blank for AI name)" className="h-11" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="sampleEmail">Email</label>
                    <Input id="sampleEmail" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@email.com" className="h-11" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="samplePhone">Phone</label>
                    <Input id="samplePhone" type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="(555) 123-4567" className="h-11" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="sampleLocation">City, State</label>
                    <Input id="sampleLocation" value={location} onChange={e => setLocation(e.target.value)} placeholder="Los Angeles, CA" className="h-11" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="sampleLinkedin">LinkedIn URL</label>
                    <Input id="sampleLinkedin" value={linkedin} onChange={e => setLinkedin(e.target.value)} placeholder="linkedin.com/in/jane" className="h-11" />
                  </div>
                </CardContent>
              </Card>
            )}

            {!profile && (
              <div className="flex items-start gap-2 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-xl">
                <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                <p className="text-xs text-yellow-300">
                  Complete your <a href="/profile" className="underline font-semibold">Profile</a> for faster, more personalized resumes.
                </p>
              </div>
            )}

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" /> Target Job
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                   <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="jobTitle">Job Title (optional)</label>
                   <Input id="jobTitle" value={jobTitle} onChange={e => setJobTitle(e.target.value)} placeholder="e.g. Marketing Manager" className="h-11" />
                 </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="company">Company (optional)</label>
                  <Input id="company" value={company} onChange={e => setCompany(e.target.value)} placeholder="e.g. Amazon" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="careerGoal">Career Goal</label>
                  <Input id="careerGoal" value={careerGoal} onChange={e => setCareerGoal(e.target.value)} placeholder="e.g. Transition to project management" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1 flex-wrap" htmlFor="jobDesc">
                    Job Description
                    <span className="text-primary">(optional but recommended)</span>
                    <HelpTip text="Copy and paste the job posting from the company website here. Our AI will read it and tailor your resume to match — this greatly improves your chances of getting an interview." />
                  </label>
                  <Textarea id="jobDesc" value={jobDescription} onChange={e => setJobDescription(e.target.value)} placeholder="Paste the job posting here — the AI will match your resume to it and insert ATS keywords automatically..." className="h-32 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block">Resume Length</label>
                  <div className="flex gap-2">
                    {[{ val: '1page', label: '1 Page' }, { val: 'full', label: 'Full Resume' }].map(opt => (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => setResumeLength(opt.val)}
                        className={`flex-1 py-2 px-3 rounded-lg border text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary ${resumeLength === opt.val ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/50'}`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {!isSampleMode && <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Personal Info</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="fullName">Full Name</label>
                  <Input id="fullName" value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Jane Smith" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="email">Email</label>
                  <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@email.com" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="phone">Phone</label>
                  <Input id="phone" type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="(555) 123-4567" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="location">City, State</label>
                  <Input id="location" value={location} onChange={e => setLocation(e.target.value)} placeholder="Los Angeles, CA" className="h-11" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="linkedin">LinkedIn URL</label>
                  <Input id="linkedin" value={linkedin} onChange={e => setLinkedin(e.target.value)} placeholder="linkedin.com/in/jane" className="h-11" />
                </div>
              </CardContent>
            </Card>}

            {!isSampleMode && <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Background</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1" htmlFor="summary">
                    Professional Summary
                    <HelpTip text="A short paragraph (2-3 sentences) that describes who you are and what you do. You can leave this blank and the AI will write it for you automatically." />
                  </label>
                  <Textarea id="summary" value={summary} onChange={e => setSummary(e.target.value)} placeholder="Write 2-3 sentences, or leave blank and AI writes it..." className="h-24 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 flex items-center gap-1" htmlFor="skills">
                    Skills
                    <HelpTip text="List things you are good at, separated by commas. Example: Microsoft Word, Customer Service, Driving, Data Entry. Include anything relevant to the job." />
                  </label>
                  <Textarea id="skills" value={skills} onChange={e => setSkills(e.target.value)} placeholder="Microsoft Office, Customer Service, Project Management..." className="h-20 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="experience">Work Experience</label>
                  <Textarea id="experience" value={experience} onChange={e => setExperience(e.target.value)} placeholder="Job Title at Company (Start - End Date)&#10;What you did and achieved..." className="h-32 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="education">Education</label>
                  <Textarea id="education" value={education} onChange={e => setEducation(e.target.value)} placeholder="e.g. Bachelor of Science in Business - UCLA (2019)" className="h-20 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="hsGrad">High School Graduation Year</label>
                  <Input id="hsGrad" value={hsGradYear} onChange={e => setHsGradYear(e.target.value)} placeholder="e.g. 2015" className="h-11" />
                </div>
              </CardContent>
            </Card>}

            {/* Advanced / Optional — hidden in sample mode */}
            {!isSampleMode && (
              <>
                <button
                  type="button"
                  onClick={() => setShowAdvanced(v => !v)}
                  className="flex items-center gap-2 w-full py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  aria-expanded={showAdvanced}
                >
                  {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  {showAdvanced ? 'Hide' : 'Add'} Certifications & Projects
                </button>
                {showAdvanced && (
                  <Card>
                    <CardContent className="pt-5 space-y-3">
                      <div>
                        <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="certs">Certifications</label>
                        <Textarea id="certs" value={certifications} onChange={e => setCertifications(e.target.value)} placeholder="e.g. Google Analytics Certified (2023), OSHA 10 (2022)" className="h-20 resize-none" />
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="projects">Projects</label>
                        <Textarea id="projects" value={projects} onChange={e => setProjects(e.target.value)} placeholder="e.g. Built an e-commerce store with 200+ monthly visitors..." className="h-20 resize-none" />
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}

            <PlanGate feature="resume" canUse={canUse('resume')} plan={plan} getUsage={getUsage} profile={planProfile}>
              <Button
                 onClick={generate}
                 disabled={loading || (!jobTitle.trim() && !jobDescription.trim())}
                 className="w-full h-14 text-lg font-bold gap-2 shadow-lg shadow-primary/30 rounded-xl"
                 aria-label={isSampleMode ? 'Generate a sample resume using AI' : 'Generate my resume using AI'}
               >
                 {loading ? <Loader2 className="w-6 h-6 animate-spin" aria-hidden="true" /> : <Sparkles className="w-6 h-6" aria-hidden="true" />}
                 {loading ? 'Creating your resume… please wait' : isSampleMode ? 'Generate Sample Resume' : '✨ Generate My Resume'}
               </Button>
               {!jobTitle.trim() && !jobDescription.trim() && (
                 <p className="text-xs text-muted-foreground text-center mt-1" role="status">
                   Enter a job title or paste a job description to get started.
                 </p>
               )}
            </PlanGate>
          </div>

          {/* === CENTER: Preview Panel === */}
          <div id="resume-preview" className="space-y-4">
            <Card className="lg:sticky lg:top-4">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-4 h-4 text-primary" />
                    {isSampleMode ? 'Sample Resume' : 'Your Resume'}
                    {generatedResume && (
                      <Badge className={`border text-xs ${isSampleMode ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-green-500/20 text-green-400 border-green-500/30'}`}>
                        {isSampleMode ? <><FlaskConical className="w-3 h-3 mr-1" /> Sample</> : <><CheckCircle2 className="w-3 h-3 mr-1" /> Ready</>}
                      </Badge>
                    )}
                  </CardTitle>
                  {generatedResume && (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm" variant="outline" onClick={copyToClipboard}
                        className="gap-1.5 h-9 text-sm" aria-label="Copy resume text to clipboard"
                      >
                        <Copy className="w-4 h-4" aria-hidden="true" /> Copy
                      </Button>
                      <Button
                        size="sm" variant="outline"
                        onClick={isSampleMode && !sampleConfirmed ? undefined : downloadPDF}
                        disabled={isSampleMode && !sampleConfirmed}
                        className="gap-1.5 h-9 text-sm"
                        aria-label={isSampleMode && !sampleConfirmed ? 'Check the confirmation box below before downloading' : 'Download resume as PDF'}
                      >
                        <FileDown className="w-4 h-4" aria-hidden="true" /> Download PDF
                      </Button>
                      <Button
                        size="sm" variant="outline"
                        onClick={isSampleMode && !sampleConfirmed ? undefined : downloadDOCX}
                        disabled={isSampleMode && !sampleConfirmed}
                        className="gap-1.5 h-9 text-sm"
                        aria-label={isSampleMode && !sampleConfirmed ? 'Check the confirmation box below before downloading' : 'Download resume as Word document'}
                      >
                        <Download className="w-4 h-4" aria-hidden="true" /> Word (.docx)
                      </Button>
                      <Button
                        size="sm" onClick={openSaveDialog} disabled={saved}
                        className="gap-1.5 h-9 text-sm"
                        aria-label={saved ? 'Resume already saved to your library' : 'Save this resume to your library for later'}
                      >
                        <Save className="w-4 h-4" aria-hidden="true" /> {saved ? '✓ Saved!' : 'Save Resume'}
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {/* Sample mode disclaimer — shown when resume is ready */}
                {isSampleMode && generatedResume && !loading && (
                  <div className="mb-4 space-y-3">
                    <div className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                      <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <p className="text-xs text-blue-300">
                        <span className="font-semibold">This is an AI-generated example.</span> Replace all details — name, companies, dates, and achievements — with your real experience before applying to any job.
                      </p>
                    </div>
                    <label className="flex items-start gap-2.5 cursor-pointer group">
                      <input
                        type="checkbox"
                        checked={sampleConfirmed}
                        onChange={e => setSampleConfirmed(e.target.checked)}
                        className="mt-0.5 w-4 h-4 accent-primary shrink-0"
                      />
                      <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors">
                        I understand I must edit this resume with my real information before using it for job applications.
                      </span>
                    </label>
                  </div>
                )}
                {loading ? (
                   <div className="flex flex-col items-center justify-center h-64 gap-3">
                     <Loader2 className="w-10 h-10 text-primary animate-spin" />
                     <p className="text-sm text-muted-foreground">{isSampleMode ? 'Generating your sample resume...' : 'Building your ATS-optimized resume...'}</p>
                     <p className="text-xs text-muted-foreground">This takes about 15–20 seconds</p>
                   </div>
                 ) : generatedResume ? (
                   <div className="space-y-3">
                     {/* Recommendation banner after generation */}
                     {!saved && (
                       <div className="flex items-start gap-3 p-3 bg-green-500/10 border border-green-500/30 rounded-xl">
                         <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
                         <div className="flex-1 min-w-0">
                           <p className="text-sm font-semibold text-green-300 mb-1">🎉 Resume Ready!</p>
                           <p className="text-xs text-green-200 mb-2">Save this to your library and access it anytime from your Resume Library.</p>
                           <div className="flex gap-2 flex-wrap">
                             <Button size="sm" onClick={openSaveDialog} className="bg-green-600 hover:bg-green-700 text-white text-xs h-7">
                               💾 Save to Library
                             </Button>
                             <Link to="/resume-library">
                               <Button size="sm" variant="outline" className="border-green-500/30 text-green-300 hover:bg-green-500/10 text-xs h-7">
                                 📚 View Library
                               </Button>
                             </Link>
                           </div>
                         </div>
                       </div>
                     )}
                     <pre className="text-sm text-foreground whitespace-pre-wrap font-sans leading-relaxed max-h-[70vh] overflow-y-auto bg-white/5 rounded-lg p-4 border border-border">
                       {generatedResume}
                     </pre>
                   </div>
                 ) : (
                   <div className="flex flex-col items-center justify-center h-64 text-muted-foreground text-center gap-3 px-4">
                     <FileText className="w-12 h-12 opacity-20" />
                     <p className="text-sm font-medium">{isSampleMode ? 'Your sample resume will appear here' : 'Your resume will appear here'}</p>
                     <p className="text-xs">{isSampleMode ? 'Enter a job title or paste a job description, then click Generate Sample Resume' : 'Enter a job title or paste a job description and click Generate'}</p>
                   </div>
                 )}
              </CardContent>
            </Card>
          </div>

          {/* === RIGHT: ATS Analysis Panel === */}
          <div className="lg:sticky lg:top-4 self-start">
            <ATSAnalysisPanel
              resumeText={generatedResume}
              jobDescription={jobDescription}
            />
          </div>

        </div>
      )}

      {/* Save Resume Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Save className="w-4 h-4 text-primary" /> Save Resume
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <label className="text-sm font-medium text-muted-foreground">Resume Name</label>
            <Input
              value={saveTitle}
              onChange={e => setSaveTitle(e.target.value)}
              placeholder="e.g. Marketing Manager @ Google"
              className="h-11"
              autoFocus
              onKeyDown={e => e.key === 'Enter' && save()}
            />
            <p className="text-xs text-muted-foreground">Give your resume a descriptive name so you can find it easily in your library.</p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>Cancel</Button>
            <Button onClick={save} disabled={!saveTitle.trim()} className="gap-2">
              <Save className="w-4 h-4" /> Save to Library
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}