import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Eye, EyeOff, Zap, ArrowRight, Check, Loader2, AlertCircle, Mail, Lock, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Auth() {
  const [mode, setMode] = useState('login'); // 'login' | 'signup' | 'reset'
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});
  const [resetSent, setResetSent] = useState(false);

  // Login fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);

  // Signup fields
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);

  // Password reset fields
  const [resetEmail, setResetEmail] = useState('');

  // Redirect if already authenticated
  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (authed) {
        window.location.href = '/';
      } else {
        setChecking(false);
      }
    });

    // Check URL params for mode
    const params = new URLSearchParams(window.location.search);
    if (params.get('mode') === 'signup') setMode('signup');
    if (params.get('reset') === 'true') setMode('reset');

    // Load saved email if "remember me" was checked
    const savedEmail = localStorage.getItem('resumevault_saved_email');
    if (savedEmail) {
      setLoginEmail(savedEmail);
      setRememberMe(true);
    }
  }, []);

  const clearErrors = () => {
    setError('');
    setFieldErrors({});
  };

  const switchMode = (newMode) => {
    setMode(newMode);
    clearErrors();
    setShowPassword(false);
    setShowConfirmPassword(false);
  };

  // Validation helpers
  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validatePasswordStrength = (pw) => {
    if (pw.length < 8) return 'Password must be at least 8 characters';
    if (!/[A-Z]/.test(pw)) return 'Password must contain at least one uppercase letter';
    if (!/[0-9]/.test(pw)) return 'Password must contain at least one number';
    return null;
  };

  const validateLoginForm = () => {
    const errors = {};
    if (!loginEmail.trim()) errors.loginEmail = 'Email is required';
    else if (!validateEmail(loginEmail)) errors.loginEmail = 'Enter a valid email address';
    if (!loginPassword) errors.loginPassword = 'Password is required';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const validateSignupForm = () => {
    const errors = {};
    if (!firstName.trim()) errors.firstName = 'First name is required';
    if (!lastName.trim()) errors.lastName = 'Last name is required';
    if (!signupEmail.trim()) errors.signupEmail = 'Email is required';
    else if (!validateEmail(signupEmail)) errors.signupEmail = 'Enter a valid email address';
    const pwError = validatePasswordStrength(signupPassword);
    if (!signupPassword) errors.signupPassword = 'Password is required';
    else if (pwError) errors.signupPassword = pwError;
    if (!confirmPassword) errors.confirmPassword = 'Please confirm your password';
    else if (signupPassword !== confirmPassword) errors.confirmPassword = 'Passwords do not match';
    if (!agreeTerms) errors.agreeTerms = 'You must agree to the Terms of Service';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    clearErrors();
    if (!validateLoginForm()) return;

    // Save email if "remember me" is checked
    if (rememberMe) {
      localStorage.setItem('resumevault_saved_email', loginEmail);
    } else {
      localStorage.removeItem('resumevault_saved_email');
    }

    setLoading(true);
    try {
      // Base44 platform handles auth — redirect to platform login
      base44.auth.redirectToLogin('/');
    } catch (err) {
      setError('Unable to connect. Please check your network and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    clearErrors();
    if (!validateSignupForm()) return;

    setLoading(true);
    try {
      // Base44 platform handles auth — redirect to platform login (which includes signup)
      base44.auth.redirectToLogin('/');
    } catch (err) {
      setError('Unable to connect. Please check your network and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    // Redirect to password reset flow on the platform
    window.location.href = '/auth?reset=true';
  };

  const handleGoogleAuth = () => {
    // Trigger Google OAuth login via the platform
    base44.auth.redirectToLogin('/', { provider: 'google' });
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Left branding panel — hidden on small screens */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-primary/20 via-primary/5 to-background flex-col justify-between p-10 border-r border-border">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
            <Zap className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <div className="font-bold text-base leading-tight">ResumeVault</div>
            <div className="text-xs text-primary font-semibold leading-tight">GOD-MODE JOB HUNT</div>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-4xl font-extrabold leading-tight">
            Land your<br /><span className="text-primary">dream job</span><br />with AI.
          </h2>
          <div className="space-y-3">
            {[
              'ATS-optimized resumes in seconds',
              'Tailored cover letters that get noticed',
              'Mock interview coaching',
              'Auto-apply to matching jobs',
            ].map(f => (
              <div key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                  <Check className="w-3 h-3 text-primary" />
                </div>
                {f}
              </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-muted-foreground">Trusted by 50,000+ job seekers • 4.9★ rating</p>
      </div>

      {/* Right auth panel */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        {/* Mobile logo */}
        <div className="flex md:hidden items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-bold">ResumeVault</span>
        </div>

        <div className="w-full max-w-sm">
          {/* Mode tabs */}
          {mode !== 'reset' && (
            <div className="flex rounded-xl border border-border overflow-hidden mb-6">
              <button
                type="button"
                onClick={() => switchMode('login')}
                className={`flex-1 py-2.5 text-sm font-semibold transition-all ${mode === 'login' ? 'bg-primary text-primary-foreground' : 'bg-secondary/40 text-muted-foreground hover:text-foreground'}`}
              >
                Log In
              </button>
              <button
                type="button"
                onClick={() => switchMode('signup')}
                className={`flex-1 py-2.5 text-sm font-semibold transition-all ${mode === 'signup' ? 'bg-primary text-primary-foreground' : 'bg-secondary/40 text-muted-foreground hover:text-foreground'}`}
              >
                Create Account
              </button>
            </div>
          )}

          <h1 className="text-2xl font-extrabold mb-1">
            {mode === 'login' ? 'Welcome back' : 'Get started free'}
          </h1>
          <p className="text-sm text-muted-foreground mb-6">
            {mode === 'login' ? 'Log in to your ResumeVault account.' : 'Create your account in seconds.'}
          </p>

          {/* Google button */}
          <Button
            type="button"
            variant="outline"
            className="w-full mb-4 gap-2 font-semibold"
            onClick={handleGoogleAuth}
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continue with Google
          </Button>

          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 h-px bg-border"></div>
            <span className="text-xs text-muted-foreground">or</span>
            <div className="flex-1 h-px bg-border"></div>
          </div>

          {/* Global error */}
          {error && (
            <div className="flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/30 rounded-xl mb-4">
              <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-xs text-destructive">{error}</p>
            </div>
          )}

          {/* PASSWORD RESET FORM */}
          {mode === 'reset' && (
            <div className="space-y-4">
              <h1 className="text-2xl font-extrabold mb-1">Reset Password</h1>
              <p className="text-sm text-muted-foreground mb-6">Enter your email and we'll send you a link to reset your password.</p>
              
              {resetSent ? (
                <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 text-center">
                  <div className="flex justify-center mb-3">
                    <Check className="w-8 h-8 text-green-400" />
                  </div>
                  <h3 className="font-semibold text-green-400 mb-1">Check your email</h3>
                  <p className="text-xs text-muted-foreground mb-4">We've sent a password reset link to <strong>{resetEmail}</strong>.</p>
                  <p className="text-xs text-muted-foreground mb-4">Click the link in your email to create a new password.</p>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => switchMode('login')}
                  >
                    Back to Log In
                  </Button>
                </div>
              ) : (
                <form onSubmit={(e) => {
                  e.preventDefault();
                  setLoading(true);
                  // Trigger password reset via platform
                  base44.auth.redirectToLogin('/', { resetEmail });
                }} className="space-y-4">
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="reset-email">Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="reset-email"
                        type="email"
                        value={resetEmail}
                        onChange={e => { setResetEmail(e.target.value); setFieldErrors(p => ({ ...p, resetEmail: '' })); }}
                        placeholder="you@email.com"
                        className={`pl-9 h-11 ${fieldErrors.resetEmail ? 'border-destructive' : ''}`}
                      />
                    </div>
                    {fieldErrors.resetEmail && <p className="text-xs text-destructive mt-1">{fieldErrors.resetEmail}</p>}
                  </div>

                  <Button type="submit" disabled={loading} className="w-full h-11 font-bold gap-2">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                    {loading ? 'Sending...' : 'Send Reset Link'}
                  </Button>

                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full"
                    onClick={() => switchMode('login')}
                  >
                    Back to Log In
                  </Button>
                </form>
              )}
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} noValidate autoComplete="on" className="space-y-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="login-email">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="login-email"
                    type="email"
                    name="email"
                    autoComplete="email"
                    value={loginEmail}
                    onChange={e => { setLoginEmail(e.target.value); setFieldErrors(p => ({ ...p, loginEmail: '' })); }}
                    placeholder="you@email.com"
                    className={`pl-9 h-11 ${fieldErrors.loginEmail ? 'border-destructive' : ''}`}
                  />
                </div>
                {fieldErrors.loginEmail && <p className="text-xs text-destructive mt-1">{fieldErrors.loginEmail}</p>}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-muted-foreground" htmlFor="login-password">Password</label>
                  <button type="button" onClick={handleForgotPassword} className="text-xs text-primary hover:underline">Forgot password?</button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    autoComplete="current-password"
                    value={loginPassword}
                    onChange={e => { setLoginPassword(e.target.value); setFieldErrors(p => ({ ...p, loginPassword: '' })); }}
                    placeholder="Enter your password"
                    className={`pl-9 pr-10 h-11 ${fieldErrors.loginPassword ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.loginPassword && <p className="text-xs text-destructive mt-1">{fieldErrors.loginPassword}</p>}
              </div>

              <div className="flex items-center gap-2">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={e => setRememberMe(e.target.checked)}
                  className="w-4 h-4 accent-primary"
                />
                <label htmlFor="remember-me" className="text-sm text-muted-foreground cursor-pointer select-none">Remember me</label>
              </div>

              <Button type="submit" disabled={loading} className="w-full h-11 font-bold gap-2">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                {loading ? 'Logging in...' : 'Log In'}
              </Button>
            </form>
          )}

          {/* SIGNUP FORM */}
          {mode === 'signup' && (
            <form onSubmit={handleSignup} noValidate autoComplete="on" className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="first-name">First Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="first-name"
                      type="text"
                      name="given-name"
                      autoComplete="given-name"
                      value={firstName}
                      onChange={e => { setFirstName(e.target.value); setFieldErrors(p => ({ ...p, firstName: '' })); }}
                      placeholder="Jane"
                      className={`pl-9 h-11 ${fieldErrors.firstName ? 'border-destructive' : ''}`}
                    />
                  </div>
                  {fieldErrors.firstName && <p className="text-xs text-destructive mt-1">{fieldErrors.firstName}</p>}
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="last-name">Last Name</label>
                  <Input
                    id="last-name"
                    type="text"
                    name="family-name"
                    autoComplete="family-name"
                    value={lastName}
                    onChange={e => { setLastName(e.target.value); setFieldErrors(p => ({ ...p, lastName: '' })); }}
                    placeholder="Smith"
                    className={`h-11 ${fieldErrors.lastName ? 'border-destructive' : ''}`}
                  />
                  {fieldErrors.lastName && <p className="text-xs text-destructive mt-1">{fieldErrors.lastName}</p>}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="signup-email">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="signup-email"
                    type="email"
                    name="email"
                    autoComplete="email"
                    value={signupEmail}
                    onChange={e => { setSignupEmail(e.target.value); setFieldErrors(p => ({ ...p, signupEmail: '' })); }}
                    placeholder="you@email.com"
                    className={`pl-9 h-11 ${fieldErrors.signupEmail ? 'border-destructive' : ''}`}
                  />
                </div>
                {fieldErrors.signupEmail && <p className="text-xs text-destructive mt-1">{fieldErrors.signupEmail}</p>}
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="signup-password">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="signup-password"
                    type={showPassword ? 'text' : 'password'}
                    name="new-password"
                    autoComplete="new-password"
                    value={signupPassword}
                    onChange={e => { setSignupPassword(e.target.value); setFieldErrors(p => ({ ...p, signupPassword: '' })); }}
                    placeholder="Min. 8 chars, 1 uppercase, 1 number"
                    className={`pl-9 pr-10 h-11 ${fieldErrors.signupPassword ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.signupPassword && <p className="text-xs text-destructive mt-1">{fieldErrors.signupPassword}</p>}
                {/* Password strength indicator */}
                {signupPassword && (
                  <div className="mt-1.5 flex gap-1">
                    {[
                      signupPassword.length >= 8,
                      /[A-Z]/.test(signupPassword),
                      /[0-9]/.test(signupPassword),
                    ].map((met, i) => (
                      <div key={i} className={`flex-1 h-1 rounded-full transition-colors ${met ? 'bg-green-500' : 'bg-border'}`} />
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1 block" htmlFor="confirm-password">Confirm Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    name="confirm-password"
                    autoComplete="new-password"
                    value={confirmPassword}
                    onChange={e => { setConfirmPassword(e.target.value); setFieldErrors(p => ({ ...p, confirmPassword: '' })); }}
                    placeholder="Repeat your password"
                    className={`pl-9 pr-10 h-11 ${fieldErrors.confirmPassword ? 'border-destructive' : ''}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.confirmPassword && <p className="text-xs text-destructive mt-1">{fieldErrors.confirmPassword}</p>}
                {confirmPassword && signupPassword && confirmPassword === signupPassword && (
                  <p className="text-xs text-green-400 mt-1 flex items-center gap-1"><Check className="w-3 h-3" /> Passwords match</p>
                )}
              </div>

              <div>
                <div className="flex items-start gap-2">
                  <input
                    id="agree-terms"
                    type="checkbox"
                    checked={agreeTerms}
                    onChange={e => { setAgreeTerms(e.target.checked); setFieldErrors(p => ({ ...p, agreeTerms: '' })); }}
                    className="mt-0.5 w-4 h-4 accent-primary shrink-0"
                  />
                  <label htmlFor="agree-terms" className="text-xs text-muted-foreground cursor-pointer select-none leading-relaxed">
                    I agree to the{' '}
                    <span className="text-primary underline cursor-pointer">Terms of Service</span>{' '}
                    and{' '}
                    <span className="text-primary underline cursor-pointer">Privacy Policy</span>
                  </label>
                </div>
                {fieldErrors.agreeTerms && <p className="text-xs text-destructive mt-1">{fieldErrors.agreeTerms}</p>}
              </div>

              <Button type="submit" disabled={loading} className="w-full h-11 font-bold gap-2">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                {loading ? 'Creating account...' : 'Create Account'}
              </Button>
            </form>
          )}

          <p className="text-xs text-muted-foreground text-center mt-4">
            {mode === 'login' ? (
              <>Don't have an account?{' '}<button type="button" onClick={() => switchMode('signup')} className="text-primary underline font-semibold">Sign up free</button></>
            ) : (
              <>Already have an account?{' '}<button type="button" onClick={() => switchMode('login')} className="text-primary underline font-semibold">Log in</button></>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}