import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Mail, Zap, Copy } from 'lucide-react';
import PlanGate from '@/components/PlanGate';
import { usePlanLimits } from '@/hooks/usePlanLimits';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/PageHeader';

export default function CoverLetter() {
  const { profile, plan, canUse, getUsage, incrementUsage } = usePlanLimits();
  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [hiringManager, setHiringManager] = useState('');
  const [tone, setTone] = useState('professional');
  const [jobDesc, setJobDesc] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');

  const generate = async () => {
    if (!jobDesc.trim() || !canUse('cover_letter')) return;
    setLoading(true);
    const profileCtx = profile ? `Applicant: ${profile.full_name}, Skills: ${profile.skills}, Summary: ${profile.professional_summary}` : '';
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a compelling, ${tone} cover letter for the following:

Job Title: ${jobTitle}
Company: ${company}
Hiring Manager: ${hiringManager || 'Hiring Manager'}
${profileCtx}
Job Description: ${jobDesc}

Make it personalized, impactful, and under 400 words. Show enthusiasm and highlight key matching skills.`
    });
    await incrementUsage('cover_letter');
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader icon={Mail} title="Cover Letter Writer" subtitle="Create a compelling cover letter matched to the role" />

      {!profile && (
        <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg text-sm text-yellow-300">
          ⚠️ <a href="/profile" className="underline">Set up your profile</a> first for personalized cover letters.
        </div>
      )}

      <Card className="mb-6">
        <CardContent className="pt-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Job Title</label>
              <Input placeholder="e.g. Senior Product Manager" value={jobTitle} onChange={e => setJobTitle(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Company</label>
              <Input placeholder="e.g. Google" value={company} onChange={e => setCompany(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Hiring Manager (optional)</label>
              <Input placeholder="e.g. Jane Smith" value={hiringManager} onChange={e => setHiringManager(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Tone</label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                  <SelectItem value="confident">Confident</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Job Description</label>
            <Textarea placeholder="Paste the job description here..." value={jobDesc} onChange={e => setJobDesc(e.target.value)} className="min-h-[150px]" />
          </div>
          <PlanGate feature="cover_letter" canUse={canUse('cover_letter')} plan={plan} getUsage={getUsage} profile={profile}>
            <Button onClick={generate} disabled={loading || !jobDesc.trim()} className="bg-primary text-primary-foreground gap-2">
              {loading ? <><Zap className="w-4 h-4 animate-spin" /> Generating...</> : <><Zap className="w-4 h-4" /> Generate Cover Letter</>}
            </Button>
          </PlanGate>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardContent className="pt-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Your Cover Letter</h3>
              <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(result)} className="gap-1 text-xs">
                <Copy className="w-3 h-3" /> Copy
              </Button>
            </div>
            <div className="whitespace-pre-wrap text-sm bg-secondary/30 rounded-lg p-4">{result}</div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}