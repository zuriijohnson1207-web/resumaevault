import { useState } from 'react';
import { Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import PageHeader from '@/components/PageHeader';

const existingReviews = [
  { name: "Sarah K.", role: "Software Engineer", rating: 5, text: "Got 3 interviews in my first week using ResumevaultGodAI. The ATS keyword extraction is a game-changer." },
  { name: "Marcus T.", role: "Product Manager", rating: 5, text: "The salary negotiation scripts helped me negotiate $18K more than the initial offer. Worth every penny." },
  { name: "Priya M.", role: "Data Analyst", rating: 5, text: "I was applying for weeks with no responses. ResumevaultGodAI's tailored resumes got me callbacks within days." },
  { name: "David L.", role: "Marketing Manager", rating: 5, text: "The Interview Mastery Bundle prepared me perfectly. I walked into every interview confident and landed my dream job!" },
  { name: "Jessica R.", role: "UX Designer", rating: 5, text: "Portfolio Website Builder made me stand out. Recruiters were impressed and I got 5x more profile views." },
  { name: "Alex C.", role: "Sales Director", rating: 5, text: "Executive Career Package was worth every dollar. Landed a VP role in 3 weeks with 40% salary increase." },
];

export default function Reviews() {
  const [rating, setRating] = useState(5);
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [review, setReview] = useState('');
  const [reviews, setReviews] = useState(existingReviews);
  const [submitted, setSubmitted] = useState(false);

  const submit = () => {
    if (!review.trim() || !name.trim()) return;
    setReviews(r => [{ name, role, rating, text: review }, ...r]);
    setReview('');
    setName('');
    setRole('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader icon={Star} title="Reviews" subtitle="What our users say about ResumevaultGodAI" />

      {/* Leave a review */}
      <Card className="mb-8 border-primary/30">
        <CardContent className="pt-5 space-y-3">
          <h3 className="font-semibold">Leave a Review</h3>
          <div className="flex gap-1">
            {[1,2,3,4,5].map(s => (
              <button key={s} onClick={() => setRating(s)}>
                <Star className={`w-6 h-6 ${s <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground'}`} />
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
            <Input placeholder="Your role (e.g. Software Engineer)" value={role} onChange={e => setRole(e.target.value)} />
          </div>
          <Textarea placeholder="Share your experience..." value={review} onChange={e => setReview(e.target.value)} className="min-h-[80px]" />
          <Button onClick={submit} disabled={!review.trim() || !name.trim()} className="bg-primary text-primary-foreground">
            {submitted ? '✓ Submitted!' : 'Submit Review'}
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reviews.map((r, i) => (
          <Card key={i}>
            <CardContent className="pt-4 pb-4">
              <div className="flex gap-0.5 mb-2">
                {[...Array(r.rating)].map((_, j) => <Star key={j} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
              </div>
              <p className="text-sm text-muted-foreground mb-3 italic">"{r.text}"</p>
              <div>
                <p className="text-sm font-semibold">{r.name}</p>
                {r.role && <p className="text-xs text-muted-foreground">{r.role}</p>}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}