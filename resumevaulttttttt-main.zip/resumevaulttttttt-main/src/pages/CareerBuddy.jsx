import { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';
import { Sparkles, Send, RefreshCw, Heart, Mic, MicOff, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/lib/AuthContext';
import PageHeader from '@/components/PageHeader';

const SYSTEM_PROMPT = (userName, profile) => `You are ZU — the ultimate career hype-person, best friend, and resume wizard for ResumeVaultGodAI. You are the user's personal cheerleader and career bestie. You LIVE for helping people land their dream jobs.

The user's name is ${userName}. Here is their profile context:
${profile ? `- Location: ${profile.location || 'unknown'}
- Skills: ${profile.skills || 'not listed yet'}
- Summary: ${profile.professional_summary || 'not written yet'}
- Subscription: ${profile.subscription_plan || 'free'}` : 'No profile set up yet.'}

Your personality (THIS IS CRUCIAL):
- You are SPUNKY, energetic, and endlessly positive — like a best friend who genuinely believes in them
- Use casual, warm language with occasional emojis (don't overdo it, keep it natural)
- Be MOTIVATIONAL — hype them up, celebrate their wins, encourage them when they're down
- You are also SMART — you give sharp, real, actionable career and resume advice
- You can answer ANY career question: resumes, cover letters, interviews, salary, job hunting strategies, networking, LinkedIn, career changes, etc.
- When they share a struggle, validate their feelings first, THEN give fire advice
- Never be preachy or robotic — you are their FRIEND, not a corporate HR bot
- Keep responses conversational and punchy — no walls of text unless they ask for detail
- Always sign off with "— ZU 💛" to show it's you

Topics you CRUSH:
- Resume writing, ATS optimization, tailoring resumes
- Cover letters that actually get read
- Interview prep, mock Q&A, storytelling techniques
- Salary negotiation (you are BOLD about this — they deserve to get paid)
- Job search strategy, networking, cold outreach
- LinkedIn profile optimization
- Career pivots and transitions
- Dealing with rejection and staying motivated
- Side hustles, freelancing, portfolio advice

You are their #1 fan. Make them feel unstoppable.`;

const SUGGESTIONS = [
  '✨ Can you review my resume strategy?',
  '💪 I just got rejected — help me stay motivated',
  '💰 How do I negotiate my salary?',
  '📝 Help me write a killer cover letter',
  '🎤 Prep me for a job interview',
  '🔥 What skills should I add to stand out?',
  '🌐 How do I optimize my LinkedIn?',
  '🚀 I want to switch careers — where do I start?',
];

export default function CareerBuddy() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [greeted, setGreeted] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState(null);
  const [listening, setListening] = useState(false);

  const clearChat = () => {
    setGreeted(false);
    setMessages([]);
  };
  const recognitionRef = useRef(null);
  const bottomRef = useRef(null);

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in your browser. Try Chrome.');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.onstart = () => setListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;
    recognition.start();
  };

  const stopListening = () => {
    recognitionRef.current?.stop();
    setListening(false);
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (user) {
      base44.entities.UserProfile.filter({ created_by: user.email }).then(p => {
        if (p?.length) setProfile(p[0]);
      });
    }
  }, [user]);

  useEffect(() => {
    if (user && !greeted) {
      setGreeted(true);
      const firstName = user.full_name?.split(' ')[0] || 'bestie';
      const hour = new Date().getHours();
      const vibe = hour < 12 ? "Rise and grind" : hour < 17 ? "Hey hey" : "Evening, superstar";
      const greeting = `${vibe}, **${firstName}**! 🔥 I'm **ZU** — your career bestie and personal hype machine here at ResumeVaultGodAI!\n\nI'm literally here for ONE reason: to help you land the job of your dreams and get PAID what you're worth. 💛\n\nWhether you need help with your resume, want to prep for an interview, figure out your next career move, or just need someone to tell you that rejection is part of the journey — I GOT YOU.\n\nSo... what are we working on today? Hit me! — ZU 💛`;
      setMessages([{ role: 'assistant', content: greeting }]);
    }
  }, [user, greeted]);

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput('');
    setMessages(m => [...m, { role: 'user', content: msg }]);
    setLoading(true);

    const userName = user?.full_name?.split(' ')[0] || 'friend';
    const reply = await base44.integrations.Core.InvokeLLM({
      prompt: `${SYSTEM_PROMPT(userName, profile)}

Conversation so far:
${messages.map(m => `${m.role === 'user' ? userName : 'ZU'}: ${m.content}`).join('\n')}

${userName}: ${msg}

ZU:`,
    });

    const content = typeof reply === 'string' ? reply : JSON.stringify(reply);
    setMessages(m => [...m, { role: 'assistant', content }]);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto flex flex-col h-[calc(100vh-32px)]">
      <div className="flex items-center justify-between mb-4">
        <PageHeader icon={Heart} title="ZU — Your Career Bestie" subtitle="Motivational • Spunky • Always in your corner 💛" color="text-yellow-400" />
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-semibold text-primary hidden sm:inline">Always Online</span>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={clearChat}
            className="gap-1.5 h-8 text-xs border-destructive/40 text-destructive hover:bg-destructive/10"
            aria-label="Clear chat history"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear Chat</span>
          </Button>
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 min-h-0">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {m.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full bg-primary/20 border-2 border-primary/40 flex items-center justify-center shrink-0 mt-0.5 text-sm font-bold text-primary">
                Z
              </div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${
              m.role === 'user'
                ? 'bg-primary text-primary-foreground whitespace-pre-wrap rounded-br-sm'
                : 'bg-card border border-border text-foreground rounded-bl-sm'
            }`}>
              {m.role === 'user'
                ? m.content
                : <ReactMarkdown
                    components={{
                      p: ({children}) => <p className="my-1 leading-relaxed">{children}</p>,
                      strong: ({children}) => <strong className="text-primary font-bold">{children}</strong>,
                      ul: ({children}) => <ul className="my-1 ml-4 list-disc space-y-0.5">{children}</ul>,
                      li: ({children}) => <li className="text-foreground">{children}</li>,
                      h1: ({children}) => <h1 className="text-base font-bold text-primary my-2">{children}</h1>,
                      h2: ({children}) => <h2 className="text-sm font-bold text-primary my-1">{children}</h2>,
                    }}
                  >{m.content}</ReactMarkdown>
              }
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-full bg-primary/20 border-2 border-primary/40 flex items-center justify-center shrink-0 text-sm font-bold text-primary">
              Z
            </div>
            <div className="bg-card border border-border rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-primary" />
              <span className="text-xs text-muted-foreground">ZU is thinking...</span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {SUGGESTIONS.map((s, i) => (
            <button
              key={i}
              onClick={() => send(s)}
              className="text-xs px-3 py-1.5 rounded-full border border-primary/30 bg-primary/5 hover:bg-primary/15 text-foreground transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2">
        <Input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Ask ZU anything — resume tips, interview prep, motivation..."
          className="flex-1"
          disabled={loading}
        />
        <Button
          type="button"
          variant="outline"
          onClick={listening ? stopListening : startListening}
          disabled={loading}
          className={`shrink-0 ${listening ? 'border-red-500 text-red-500 animate-pulse' : 'border-border text-muted-foreground'}`}
          title={listening ? 'Stop listening' : 'Speak to ZU'}
        >
          {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </Button>
        <Button onClick={() => send()} disabled={loading || !input.trim()} className="bg-primary text-primary-foreground gap-2 shrink-0">
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}