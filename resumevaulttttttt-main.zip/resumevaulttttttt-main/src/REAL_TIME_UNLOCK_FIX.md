# Real-Time Credit/Subscription/Override Unlock System

## Overview
Implemented a complete real-time access control system that instantly unlocks features when:
- Admin adds/removes credits
- Admin applies/removes subscription overrides
- User purchases credits (via Stripe)
- Admin upgrades/downgrades plan

**Key: No refresh required. Changes visible instantly.**

---

## Architecture

### 1. **Central Access Function** (`lib/checkUserAccess.js`)
Single source of truth for all feature access decisions.

**Priority (highest to lowest):**
1. Admin Override (lock/unlock/temporary)
2. Active Subscription Plan
3. Available Credit Balance
4. Free Plan Monthly Limits
5. Locked

**Returns:**
```javascript
{
  canUse: boolean,
  reason: 'admin_override' | 'plan_unlimited' | 'credit_purchase' | 'locked' | etc,
  creditsNeeded: number
}
```

### 2. **Real-Time Hooks** (`hooks/useRealTimeAccess.js`)
Frontend hooks that subscribe to backend changes.

**Included:**
- `useRealTimeAccess(feature)` - Get access for single feature
- `useUnlockedFeatures()` - Get all unlocked features for user

Both automatically:
- Subscribe to UserProfile changes
- Subscribe to AdminOverride changes
- Recalculate access instantly
- Update UI without refresh

### 3. **Feature Gates** (`components/RealTimeFeatureGate.jsx`)
Wraps any feature to enforce access control.

```jsx
<RealTimeFeatureGate feature="resume">
  <ResumeBuilder />
</RealTimeFeatureGate>
```

Shows:
- Unlock status (instantly updated)
- Upgrade/Buy Credits buttons
- Lock icon if locked

### 4. **Admin Sync Function** (`functions/syncAccessState.js`)
Backend function that triggers real-time push when access changes.

Called after:
- Admin adds/removes credits
- Admin applies/removes overrides
- Stripe webhook updates subscription

---

## How It Works

### When Admin Adds Credits
1. Admin uses `AdminOverridePanel`
2. Clicks "Add Credits" override
3. System:
   - Creates `AdminOverride` record (is_active: true)
   - Updates `UserProfile.ai_credits`
   - Creates `CreditHistory` log entry
   - Triggers `UserProfile` real-time subscription
4. Frontend instantly receives update via subscription
5. `useRealTimeAccess()` recalculates access
6. UI updates with unlocked features
7. **No refresh needed**

### When User Buys Credits (Stripe)
1. User clicks "Buy Credits"
2. Redirected to Stripe checkout
3. On return:
   - Stripe webhook updates `UserProfile.ai_credits`
   - `syncAccessState` function triggered
   - Real-time subscription fires
4. Frontend:
   - Detects credit balance change
   - `useRealTimeAccess()` rechecks access
   - Features unlock instantly
5. **Dashboard shows new balance immediately**

### When Admin Applies Subscription Override
1. Admin selects "Upgrade Plan" override
2. Chooses plan (pro/elite)
3. System:
   - Creates `AdminOverride` record
   - Updates `UserProfile.subscription_plan`
4. Frontend receives real-time update
5. All plan features unlock instantly
6. **User sees "Pro" or "Elite" badge immediately**

### Real-Time Sync Flow
```
Admin Action
    ↓
Create AdminOverride + Update UserProfile
    ↓
UserProfile real-time subscription fires
    ↓
Frontend receives update event
    ↓
useRealTimeAccess() recalculates
    ↓
UI re-renders with new access state
    ↓
Features instantly visible/clickable
```

---

## Feature Definitions

### Unlocked by Credits (credit_cost > 0):
- Resume Builder (5 credits)
- Job Analyzer (2 credits)
- ATS Score (1 credit)
- Advanced ATS Report (3 credits)
- Cover Letter (3 credits)
- Resume Comparison (0 - unlocked by plan)

### Unlocked by Subscription Plan:
**Free Plan:**
- Resume Builder (2/month)
- Cover Letter (2/month)
- Job Analysis (2/month)
- Library Editing
- PDF Download

**Pro Plan:**
- Resume Builder (80/month)
- Unlimited cover letters
- Unlimited job analyses
- Job Analyzer
- ATS Score + Advanced Report
- Resume Templates
- Resume Comparison
- Auto Apply (50/month)
- Word Download
- Mock Interview (20/month)

**Elite Plan:**
- Unlimited everything
- Auto Apply (200/month)

### Unlocked by Admin Override:
- Can unlock any feature
- Can add/remove credits
- Can override subscription
- Can lock specific features
- Can grant temporary access

---

## Test Flows

### Test 1: Admin Adds Credits
```
1. Go to Admin > AdminOverridePanel
2. Select user email
3. Choose "Add Credits"
4. Enter amount (e.g., 50)
5. Click "Apply Override"
6. Check user's Dashboard
→ Credits balance updates instantly
→ Resume Builder/Job Analyzer buttons unlock
→ No page refresh needed
```

### Test 2: User Buys Credits
```
1. Go to Profile tab
2. Click "Buy Credits" (any pack)
3. Complete Stripe checkout
4. Return to app
→ Credits show new balance instantly
→ Dashboard shows "Feature Unlocked"
→ Buttons no longer show lock icon
```

### Test 3: Admin Upgrades Plan
```
1. Go to Admin > AdminOverridePanel
2. Select user
3. Choose "Upgrade Plan"
4. Select "Pro"
5. Click "Apply Override"
6. Check user's Dashboard
→ Plan badge shows "Pro" instantly
→ All Pro features unlock instantly
→ "Unlock Features" shows 15+ unlocked
```

### Test 4: Credits Hit Zero
```
1. User has 5 credits
2. Generates one resume (costs 5)
3. Profile updates instantly
4. Dashboard shows 0 credits
→ Resume Builder button shows lock icon
→ "Buy Credits" message appears
→ Cannot use feature anymore
```

### Test 5: Mobile + Desktop Sync
```
1. Open app on Desktop
2. Open same app on Mobile
3. On Desktop, buy 100 credits
4. Check Mobile immediately
→ Credits appear instantly (no refresh)
→ Features unlock on Mobile too
→ Both stay in sync
```

---

## Priority Checklist

✅ Central `checkUserAccess()` function
✅ Real-time hooks (`useRealTimeAccess`, `useUnlockedFeatures`)
✅ Feature gate component (`RealTimeFeatureGate`)
✅ Admin sync function (`syncAccessState`)
✅ AdminOverridePanel triggers sync on create/update
✅ Dashboard uses `useUnlockedFeatures()` for instant display
✅ Profile page triggers sync after Stripe purchase
✅ Real-time subscriptions on profile + overrides
✅ No delayed updates or refresh required
✅ Access recalculates on any change
✅ Frontend + backend always in sync

---

## Implementation Notes

### Real-Time Subscription
The system uses Base44's built-in real-time subscriptions:
```javascript
const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
  if (event.data?.created_by === user.email) {
    // Access recalculated automatically
  }
});
```

No polling. No delays. Instant updates.

### Credit Deduction
Credits are deducted ONLY after successful AI action:
```javascript
const access = await checkUserAccess(user.email, 'resume');
if (access.reason === 'credit_purchase') {
  // Run AI feature
  const result = await generateResume(...);
  // Then deduct
  await recordFeatureUsage(user.email, 'resume');
}
```

### Admin Override Priority
If user has:
- Admin unlock override → Use it (instant access)
- Subscription plan → Use it
- Sufficient credits → Use credits
- Otherwise → Locked

---

## Files Modified/Created

### Created:
- `hooks/useRealTimeAccess.js` - Real-time access hooks
- `components/RealTimeFeatureGate.jsx` - Feature gate wrapper
- `functions/syncAccessState.js` - Backend sync trigger

### Modified:
- `lib/checkUserAccess.js` - Central access function (already correct)
- `pages/Dashboard.jsx` - Use `useUnlockedFeatures()`
- `pages/Profile.jsx` - Trigger sync after credit purchase
- `components/admin/AdminOverridePanel.jsx` - Instant sync on override

---

## Verification Checklist

Before deployment:
- [ ] Admin can add credits → user sees instant unlock
- [ ] Admin can upgrade plan → all features unlock instantly
- [ ] User can buy credits → balance updates instantly
- [ ] Credits deducted only after AI action completes
- [ ] Locked button shows upgrade/buy message
- [ ] Mobile + desktop stay in sync
- [ ] No duplicate credits awarded
- [ ] Override records logged properly
- [ ] CreditHistory entries created
- [ ] Dashboard shows correct credit balance
- [ ] Feature unlock display shows correct status