import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Verify all overridden users have proper access
 * Checks for bugs like taitiant case-sensitivity issue
 * Admin-only function
 */

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const results = {
      total_overrides_checked: 0,
      users_fixed: [],
      users_with_issues: [],
      errors: [],
    };

    // Get all active overrides
    const overrides = await base44.asServiceRole.entities.AdminOverride.list();
    const activeOverrides = overrides.filter(o => o.is_active);
    
    // Group by user_email
    const userEmails = [...new Set(activeOverrides.map(o => o.user_email))];
    results.total_overrides_checked = userEmails.length;

    for (const userEmail of userEmails) {
      try {
        const userEmail_lower = userEmail.toLowerCase();
        let profiles = await base44.asServiceRole.entities.UserProfile.list();
        let profile = profiles.find(p => 
          p.created_by?.toLowerCase() === userEmail_lower || 
          p.email?.toLowerCase() === userEmail_lower
        );

        if (!profile) {
          results.users_with_issues.push({
            email: userEmail,
            issue: 'profile_not_found',
            fixed: false,
          });
          continue;
        }

        const userOverrides = activeOverrides.filter(o => o.user_email.toLowerCase() === userEmail_lower);
        let needsFix = false;
        let fix = { email: userEmail };

        // Check credit overrides
        const creditOverride = userOverrides.find(o => 
          ['credit_add', 'credit_reset'].includes(o.override_type)
        );
        if (creditOverride && creditOverride.credits_amount) {
          const expectedCredits = creditOverride.credits_amount;
          const actualCredits = profile.ai_credits || 0;
          
          if (actualCredits !== expectedCredits) {
            await base44.asServiceRole.entities.UserProfile.update(profile.id, {
              ai_credits: expectedCredits,
            });
            fix.credits_fixed = { from: actualCredits, to: expectedCredits };
            needsFix = true;
          }
        }

        // Check plan overrides
        const planOverride = userOverrides.find(o => 
          ['plan_upgrade', 'plan_downgrade'].includes(o.override_type)
        );
        if (planOverride && planOverride.plan_granted) {
          const expectedPlan = planOverride.plan_granted;
          const actualPlan = profile.subscription_plan || 'free';
          
          if (actualPlan !== expectedPlan) {
            await base44.asServiceRole.entities.UserProfile.update(profile.id, {
              subscription_plan: expectedPlan,
            });
            fix.plan_fixed = { from: actualPlan, to: expectedPlan };
            needsFix = true;
          }
        }

        // Check feature unlock overrides
        const featureOverride = userOverrides.find(o => o.override_type === 'feature_unlock');
        if (featureOverride && featureOverride.features_affected?.length > 0) {
          // Features are checked via AdminOverride table, just verify record is active
          if (!featureOverride.is_active) {
            // If marked inactive, log it
            fix.feature_unlock_inactive = featureOverride.features_affected;
          }
        }

        if (needsFix) {
          results.users_fixed.push(fix);
        }
      } catch (e) {
        results.errors.push(`Failed to verify ${userEmail}: ${e.message}`);
        results.users_with_issues.push({
          email: userEmail,
          issue: `error: ${e.message}`,
          fixed: false,
        });
      }
    }

    return Response.json({ success: true, ...results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});