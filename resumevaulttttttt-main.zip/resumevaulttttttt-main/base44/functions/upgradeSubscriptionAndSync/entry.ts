import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * CRITICAL: Called when:
 * 1. Admin upgrades user subscription via AdminOverridePanel
 * 2. User subscribes via Stripe
 * 3. Subscription plan changes
 * 
 * This function MUST:
 * - Update UserProfile.subscription_plan
 * - Create AdminOverride record if admin action
 * - Trigger real-time sync (no refresh needed)
 */

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userEmail, newPlan, reason, adminEmail } = await req.json();

    if (!userEmail || !newPlan || !['free', 'pro', 'elite'].includes(newPlan)) {
      return Response.json({ error: 'Invalid params' }, { status: 400 });
    }

    // Only admin can upgrade others
    if (userEmail.toLowerCase() !== user.email.toLowerCase() && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Fetch user profile
    const profiles = await base44.asServiceRole.entities.UserProfile.filter({
      created_by: userEmail,
    });

    if (!profiles || profiles.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = profiles[0];
    const oldPlan = profile.subscription_plan || 'free';

    // Update profile with new plan (THIS TRIGGERS REAL-TIME SYNC)
    await base44.asServiceRole.entities.UserProfile.update(profile.id, {
      subscription_plan: newPlan,
      monthly_uses: 0, // Reset monthly usage on plan change
    });

    // If admin action, create override record for audit
    if (adminEmail && adminEmail !== userEmail) {
      await base44.asServiceRole.entities.AdminOverride.create({
        user_email: userEmail.toLowerCase(),
        admin_email: adminEmail.toLowerCase(),
        override_type: 'plan_upgrade',
        plan_granted: newPlan,
        previous_value: oldPlan,
        new_value: newPlan,
        reason: reason || 'Subscription upgrade',
        is_active: true,
      }).catch(() => {});
    }

    // Log to credit history for context
    await base44.asServiceRole.entities.CreditHistory.create({
      user_email: userEmail,
      action: 'subscription',
      feature: '',
      credits_spent: 0,
      credits_added: 0,
      balance_after: profile.ai_credits || 0,
      source: 'subscription_change',
      product_key: `plan_${newPlan}`,
      notes: `Plan upgraded from ${oldPlan} to ${newPlan}${adminEmail ? ` by admin (${adminEmail})` : ''}`,
    }).catch(() => {});

    return Response.json({
      success: true,
      userEmail,
      oldPlan,
      newPlan,
      message: `✅ Plan upgraded to ${newPlan}. All features will unlock instantly.`,
    });
  } catch (error) {
    console.error('upgradeSubscriptionAndSync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});