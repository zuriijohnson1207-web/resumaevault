import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * CRITICAL: Called after ANY unlock action to ensure frontend gets immediate update
 * This function is safe to call repeatedly — it's idempotent
 * 
 * Responsibilities:
 * 1. Verify user profile exists
 * 2. Verify AdminOverride records are correct
 * 3. Return current state so frontend knows what to display
 * 4. Frontend listens to real-time updates automatically via subscriptions
 */

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch user profile
    const profiles = await base44.asServiceRole.entities.UserProfile.filter({
      created_by: user.email,
    });

    if (!profiles || profiles.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = profiles[0];

    // Fetch active overrides
    const overrides = await base44.asServiceRole.entities.AdminOverride.filter({
      user_email: user.email.toLowerCase(),
      is_active: true,
    }).catch(() => []);

    // Calculate what features should be unlocked
    const unlocked = {
      plan: profile.subscription_plan || 'free',
      credits: profile.ai_credits || 0,
      overrides: overrides.length,
      timestamp: new Date().toISOString(),
    };

    return Response.json({
      success: true,
      user: {
        email: user.email,
        role: user.role,
      },
      profile: {
        plan: profile.subscription_plan || 'free',
        credits: profile.ai_credits || 0,
        usage: profile.usage_counts || {},
      },
      overrides: overrides.map(o => ({
        type: o.override_type,
        features: o.features_affected || [],
        until: o.temporary_until,
      })),
      unlocked,
      message: 'Sync state confirmed',
    });
  } catch (error) {
    console.error('syncUnlockState error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});