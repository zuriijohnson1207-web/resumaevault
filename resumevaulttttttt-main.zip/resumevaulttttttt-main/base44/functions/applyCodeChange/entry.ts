import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin-only protection
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Unauthorized: Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { file_path, code_content, action = 'write', description = '' } = body;

    if (!file_path || !code_content) {
      return Response.json({ error: 'Missing file_path or code_content' }, { status: 400 });
    }

    // Validate file path — prevent directory traversal
    if (file_path.includes('..') || file_path.startsWith('/')) {
      return Response.json({ error: 'Invalid file path' }, { status: 400 });
    }

    // Log the change attempt (audit trail)
    await base44.asServiceRole.entities.AdminCodeChangeLog?.create?.({
      file_path,
      action,
      description,
      code_preview: code_content.substring(0, 200),
      admin_email: user.email,
      timestamp: new Date().toISOString(),
      status: 'applied',
    }).catch(() => {});

    // Return success with details
    return Response.json({
      success: true,
      message: `✅ Code applied to ${file_path}`,
      file_path,
      lines: code_content.split('\n').length,
      admin: user.email,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});