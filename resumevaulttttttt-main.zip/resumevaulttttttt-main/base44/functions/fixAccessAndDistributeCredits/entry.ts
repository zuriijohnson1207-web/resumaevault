import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Fix access issue for user 'taitiant' and distribute credits to other users
 * Admin-only function
 */

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin check
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const results = {
      taitiant_fixed: null,
      credits_distributed: [],
      errors: [],
    };

    // 1. Find and fix taitiant's profile
    try {
      let taitiantProfiles = await base44.asServiceRole.entities.UserProfile.list();
      let taitiant = taitiantProfiles.find(p => p.created_by?.toLowerCase() === 'taitiant' || p.email?.toLowerCase() === 'taitiant');
      
      if (taitiant) {
        // Ensure ai_credits is properly set (re-save to trigger sync)
        const credits = taitiant.ai_credits || 0;
        await base44.asServiceRole.entities.UserProfile.update(taitiant.id, {
          ai_credits: credits,
          subscription_plan: taitiant.subscription_plan || 'free',
        });
        
        results.taitiant_fixed = {
          email: taitiant.created_by,
          plan: taitiant.subscription_plan,
          credits: credits,
          status: 'fixed',
        };
      } else {
        results.errors.push('Could not find taitiant profile');
      }
    } catch (e) {
      results.errors.push(`Failed to fix taitiant: ${e.message}`);
    }

    // 2. Distribute credits to other users needing it
    // Look for users with plan upgrades but low/missing credits
    try {
      const allProfiles = await base44.asServiceRole.entities.UserProfile.list();
      
      const usersNeedingCredits = allProfiles.filter(p => {
        const credits = p.ai_credits || 0;
        const plan = p.subscription_plan || 'free';
        // Upgraded users with insufficient credits
        return (plan === 'pro' || plan === 'elite') && credits < 10;
      });

      for (const userProfile of usersNeedingCredits) {
        try {
          const creditsToAdd = userProfile.subscription_plan === 'elite' ? 50 : 20;
          const newCredits = (userProfile.ai_credits || 0) + creditsToAdd;
          
          await base44.asServiceRole.entities.UserProfile.update(userProfile.id, {
            ai_credits: newCredits,
          });

          // Log the distribution
          await base44.asServiceRole.entities.CreditHistory.create({
            user_email: userProfile.created_by,
            action: 'admin_adjustment',
            credits_added: creditsToAdd,
            credits_spent: 0,
            balance_after: newCredits,
            source: 'admin',
            notes: 'Access fix — credits distributed for plan upgrade',
          });

          results.credits_distributed.push({
            email: userProfile.created_by,
            plan: userProfile.subscription_plan,
            credits_added: creditsToAdd,
            new_balance: newCredits,
          });
        } catch (e) {
          results.errors.push(`Failed to add credits to ${userProfile.created_by}: ${e.message}`);
        }
      }
    } catch (e) {
      results.errors.push(`Failed to distribute credits: ${e.message}`);
    }

    return Response.json({ success: true, ...results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});