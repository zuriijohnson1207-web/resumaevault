import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Fetch all customers from Stripe (paginate through all)
    let allCustomers = [];
    let hasMore = true;
    let startingAfter = undefined;

    while (hasMore) {
      const params = { limit: 100 };
      if (startingAfter) params.starting_after = startingAfter;

      const batch = await stripe.customers.list(params);
      allCustomers = allCustomers.concat(batch.data);
      hasMore = batch.has_more;
      if (batch.data.length > 0) {
        startingAfter = batch.data[batch.data.length - 1].id;
      }
    }

    // Get existing profiles
    const existingProfiles = await base44.asServiceRole.entities.UserProfile.list();
    const existingEmails = new Set(existingProfiles.map(p => p.email?.toLowerCase()).filter(Boolean));

    let imported = 0;
    let skipped = 0;
    const importedList = [];

    for (const customer of allCustomers) {
      if (!customer.email) { skipped++; continue; }
      if (existingEmails.has(customer.email.toLowerCase())) { skipped++; continue; }

      // Get their subscription from Stripe if any
      const subs = await stripe.subscriptions.list({ customer: customer.id, limit: 1, status: 'active' });
      let plan = 'free';
      if (subs.data.length > 0) {
        const amount = subs.data[0].items.data[0]?.price?.unit_amount || 0;
        if (amount >= 7999) plan = 'elite';
        else if (amount >= 2999) plan = 'pro';
      }

      await base44.asServiceRole.entities.UserProfile.create({
        email: customer.email,
        full_name: customer.name || '',
        subscription_plan: plan,
        ai_credits: plan === 'elite' ? 200 : plan === 'pro' ? 50 : 0,
      });

      existingEmails.add(customer.email.toLowerCase());
      importedList.push({ email: customer.email, plan });
      imported++;
    }

    return Response.json({
      success: true,
      total_stripe_customers: allCustomers.length,
      imported,
      skipped,
      imported_list: importedList,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});