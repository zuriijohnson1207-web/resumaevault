import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Reads the actual source code of app files by fetching from base44's file API.
 * Admin-only.
 */

// Map of all known file paths to their source (embedded at build time via fetch from public CDN or inline)
// Since we can't use a secret-less file API, we embed key files as strings the LLM can work with.
// The real content is passed through by the admin invoking the tool from the frontend read_file utility.

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { file_path, content } = await req.json();
    if (!file_path) {
      return Response.json({ error: 'file_path required' }, { status: 400 });
    }

    // If content was passed from frontend (via read_file tool), just echo it back structured
    if (content) {
      const lines = content.split('\n').length;
      return Response.json({ file_path, content, lines, success: true });
    }

    // Otherwise, try to fetch it from the base44 source storage
    const appId = Deno.env.get('BASE44_APP_ID');
    const fileRes = await fetch(
      `https://api.base44.com/api/apps/${appId}/source-files/${encodeURIComponent(file_path)}`,
      {
        headers: { 'X-App-Id': appId }
      }
    );

    if (fileRes.ok) {
      const data = await fileRes.json();
      const fileContent = data.content || data.source || data.code || '';
      return Response.json({
        file_path,
        content: fileContent,
        lines: fileContent.split('\n').length,
        success: true
      });
    }

    return Response.json({
      error: `Could not retrieve file: ${fileRes.status}`,
      file_path,
      success: false
    });
  } catch (error) {
    return Response.json({ error: error.message, success: false }, { status: 200 });
  }
});