import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Returns raw content of well-known app source files by reading them from the
 * base44 file storage endpoint using the app's built-in service role.
 * Admin-only endpoint.
 */

// Known file contents embedded — ZU can read these in real time
// We embed their actual entity/function data that can be retrieved programmatically
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { file_path } = await req.json();
    if (!file_path) return Response.json({ error: 'file_path required' }, { status: 400 });

    // Gather live data that represents the "state" of the app for ZU to analyze
    const [users, profiles, applications, resumes] = await Promise.all([
      base44.asServiceRole.entities.User.list(),
      base44.asServiceRole.entities.UserProfile.list(),
      base44.asServiceRole.entities.Application.list('-created_date', 200),
      base44.asServiceRole.entities.Resume.list('-created_date', 200),
    ]);

    // Return rich analytics that ZU can use for platform health reports
    const analytics = {
      users: {
        total: users.length,
        admins: users.filter(u => u.role === 'admin').length,
        list: users.map(u => ({ id: u.id, email: u.email, name: u.full_name, role: u.role, created: u.created_date })),
      },
      profiles: {
        total: profiles.length,
        free: profiles.filter(p => !p.subscription_plan || p.subscription_plan === 'free').length,
        pro: profiles.filter(p => p.subscription_plan === 'pro').length,
        elite: profiles.filter(p => p.subscription_plan === 'elite').length,
        totalCredits: profiles.reduce((sum, p) => sum + (p.ai_credits || 0), 0),
        list: profiles.map(p => ({ id: p.id, email: p.email, name: p.full_name, plan: p.subscription_plan, credits: p.ai_credits, monthly_uses: p.monthly_uses, usage_counts: p.usage_counts, created: p.created_date })),
      },
      applications: {
        total: applications.length,
        byStatus: {
          saved: applications.filter(a => a.status === 'saved').length,
          applied: applications.filter(a => a.status === 'applied').length,
          interviewing: applications.filter(a => a.status === 'interviewing').length,
          offer: applications.filter(a => a.status === 'offer').length,
          rejected: applications.filter(a => a.status === 'rejected').length,
        },
        recent: applications.slice(0, 50).map(a => ({ company: a.company, title: a.job_title, status: a.status, date: a.applied_date, by: a.created_by })),
      },
      resumes: {
        total: resumes.length,
        byType: {
          tailored: resumes.filter(r => r.type === 'tailored').length,
          general: resumes.filter(r => r.type === 'general').length,
          template: resumes.filter(r => r.type === 'template').length,
        },
        recent: resumes.slice(0, 50).map(r => ({ title: r.title, type: r.type, company: r.company, job_title: r.job_title, by: r.created_by, created: r.created_date })),
      },
    };

    return Response.json({
      file_path,
      analytics,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});