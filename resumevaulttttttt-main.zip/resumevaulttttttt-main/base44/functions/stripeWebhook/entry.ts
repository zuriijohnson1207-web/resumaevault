import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

const CREDIT_MAP = {
  credits_50: 50,
  credits_150: 150,
  credits_400: 400,
  credits_1000: 1000,
  pack_50: 50,
  pack_150: 150,
  pack_500: 400,
};

const AMOUNT_MAP = {
  credits_50: 999,
  credits_150: 2499,
  credits_400: 5999,
  credits_1000: 12999,
  pro_monthly: 2999,
  elite_monthly: 7999,
};

const PLAN_MAP = {
  pro_monthly: 'pro',
  elite_monthly: 'elite',
};

const PRODUCT_NAMES = {
  credits_50: '50 AI Credits',
  credits_150: '150 AI Credits',
  credits_400: '400 AI Credits',
  credits_1000: '1000 AI Credits',
  pro_monthly: 'Pro Plan (Monthly)',
  elite_monthly: 'Elite Plan (Monthly)',
};

async function findOrCreateProfile(base44, userEmail) {
  let profiles = await base44.asServiceRole.entities.UserProfile.filter({ created_by: userEmail });
  if (profiles.length > 0) return profiles[0];
  profiles = await base44.asServiceRole.entities.UserProfile.filter({ email: userEmail });
  if (profiles.length > 0) return profiles[0];
  return null;
}

async function logCreditHistory(base44, { userEmail, action, feature, creditsSpent, creditsAdded, balanceAfter, source, stripeSessionId, productKey, amountPaidCents, notes }) {
  await base44.asServiceRole.entities.CreditHistory.create({
    user_email: userEmail,
    action,
    feature: feature || '',
    credits_spent: creditsSpent || 0,
    credits_added: creditsAdded || 0,
    balance_after: balanceAfter || 0,
    source: source || '',
    stripe_session_id: stripeSessionId || '',
    product_key: productKey || '',
    amount_paid_cents: amountPaidCents || 0,
    notes: notes || '',
  });
}

async function logPaymentRecord(base44, { userEmail, stripeSessionId, stripeCustomerId, productKey, amountCents, status, paymentType, creditsGranted, planGranted }) {
  await base44.asServiceRole.entities.PaymentRecord.create({
    user_email: userEmail,
    stripe_session_id: stripeSessionId || '',
    stripe_customer_id: stripeCustomerId || '',
    product_key: productKey || '',
    product_name: PRODUCT_NAMES[productKey] || productKey,
    amount_cents: amountCents || 0,
    currency: 'usd',
    status: status || 'succeeded',
    payment_type: paymentType || 'one_time',
    credits_granted: creditsGranted || 0,
    plan_granted: planGranted || '',
  });
}

Deno.serve(async (req) => {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature');

  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, sig, Deno.env.get('STRIPE_WEBHOOK_SECRET'));
  } catch (err) {
    return new Response(`Webhook signature verification failed: ${err.message}`, { status: 400 });
  }

  const base44 = createClientFromRequest(req);

  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const { user_email, product_key } = session.metadata || {};

      if (!user_email || !product_key) {
        return new Response('Missing metadata', { status: 400 });
      }

      let profile = await findOrCreateProfile(base44, user_email);

      if (!profile) {
        profile = await base44.asServiceRole.entities.UserProfile.create({
          email: user_email,
          created_by: user_email,
          subscription_plan: PLAN_MAP[product_key] || 'free',
          ai_credits: CREDIT_MAP[product_key] || 0,
        });
      }

      const creditsToAdd = CREDIT_MAP[product_key] || 0;
       const planToGrant = PLAN_MAP[product_key] || null;
       const currentCredits = profile.ai_credits || 0;
       const newCredits = currentCredits + creditsToAdd;
       const amountCents = AMOUNT_MAP[product_key] || session.amount_total || 0;

       // Build single update payload with all changes
       const updatePayload = {};

       if (creditsToAdd > 0) {
         updatePayload.ai_credits = newCredits;
       }

       if (planToGrant) {
         updatePayload.subscription_plan = planToGrant;
         updatePayload.usage_counts = { resume: 0, cover_letter: 0, job_analysis: 0, follow_up_email: 0, mock_interview: 0, auto_apply: 0, salary_negotiation: 0, career_roadmap: 0, portfolio_ideas: 0 };
         updatePayload.monthly_uses = 0;
       }

       // Single update call to ensure atomic sync
       if (Object.keys(updatePayload).length > 0) {
         await base44.asServiceRole.entities.UserProfile.update(profile.id, updatePayload);
       }

       // Log credit history for credits purchase
       if (creditsToAdd > 0) {
         await logCreditHistory(base44, {
           userEmail: user_email,
           action: 'purchase',
           creditsAdded: creditsToAdd,
           balanceAfter: newCredits,
           source: 'stripe_purchase',
           stripeSessionId: session.id,
           productKey: product_key,
           amountPaidCents: amountCents,
           notes: `Purchased ${PRODUCT_NAMES[product_key] || product_key}`,
         });
       }

       // Log credit history for subscription
       if (planToGrant) {
         await logCreditHistory(base44, {
           userEmail: user_email,
           action: 'subscription',
           creditsAdded: 0,
           balanceAfter: newCredits,
           source: 'stripe_subscription',
           stripeSessionId: session.id,
           productKey: product_key,
           amountPaidCents: amountCents,
           notes: `Subscribed to ${PRODUCT_NAMES[product_key]}`,
         });
       }

      // Log payment record
      await logPaymentRecord(base44, {
        userEmail: user_email,
        stripeSessionId: session.id,
        stripeCustomerId: session.customer,
        productKey: product_key,
        amountCents: amountCents,
        status: 'succeeded',
        paymentType: planToGrant ? 'subscription' : 'one_time',
        creditsGranted: creditsToAdd,
        planGranted: planToGrant || '',
      });
    }

    if (event.type === 'customer.subscription.deleted') {
      const subscription = event.data.object;
      const customer = await stripe.customers.retrieve(subscription.customer);
      const userEmail = customer.email;

      if (userEmail) {
        const profile = await findOrCreateProfile(base44, userEmail);
        if (profile) {
          await base44.asServiceRole.entities.UserProfile.update(profile.id, {
            subscription_plan: 'free',
          });
          await logCreditHistory(base44, {
            userEmail,
            action: 'subscription',
            creditsAdded: 0,
            balanceAfter: profile.ai_credits || 0,
            source: 'stripe_cancellation',
            notes: 'Subscription cancelled — downgraded to Free',
          });
        }
      }
    }

    if (event.type === 'customer.subscription.updated') {
      const subscription = event.data.object;
      if (subscription.status === 'active') {
        const customer = await stripe.customers.retrieve(subscription.customer);
        const userEmail = customer.email;
        const meta = subscription.metadata || {};
        if (userEmail && meta.product_key && PLAN_MAP[meta.product_key]) {
          const profile = await findOrCreateProfile(base44, userEmail);
          if (profile) {
            await base44.asServiceRole.entities.UserProfile.update(profile.id, {
              subscription_plan: PLAN_MAP[meta.product_key],
            });
          }
        }
      }
    }

    // Handle failed payments
    if (event.type === 'payment_intent.payment_failed') {
      const pi = event.data.object;
      const customer = pi.customer ? await stripe.customers.retrieve(pi.customer) : null;
      const userEmail = customer?.email;
      if (userEmail) {
        await logPaymentRecord(base44, {
          userEmail,
          stripeSessionId: pi.id,
          stripeCustomerId: pi.customer,
          productKey: 'unknown',
          amountCents: pi.amount || 0,
          status: 'failed',
          paymentType: 'one_time',
          notes: pi.last_payment_error?.message || 'Payment failed',
        });
      }
    }

  } catch (err) {
    console.error('Webhook processing error:', err.message);
    return Response.json({ error: err.message }, { status: 500 });
  }

  return Response.json({ received: true });
});