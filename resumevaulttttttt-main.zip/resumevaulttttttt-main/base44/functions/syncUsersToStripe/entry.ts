import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const users = await base44.asServiceRole.entities.User.list();

    let created = 0;
    let skipped = 0;
    const errors = [];

    for (const u of users) {
      if (!u.email) { skipped++; continue; }
      try {
        // Check if customer already exists in Stripe
        const existing = await stripe.customers.list({ email: u.email, limit: 1 });
        if (existing.data.length > 0) {
          skipped++;
          continue;
        }
        // Create new Stripe customer
        await stripe.customers.create({
          email: u.email,
          name: u.full_name || u.email,
          metadata: { user_id: u.id },
        });
        created++;
      } catch (err) {
        errors.push({ email: u.email, error: err.message });
      }
    }

    return Response.json({ success: true, created, skipped, errors });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});