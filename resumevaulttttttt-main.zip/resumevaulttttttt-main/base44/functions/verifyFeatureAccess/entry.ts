import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Backend function to verify feature access
 * This MUST be called by ANY feature that uses credits or has plan restrictions
 * Do not trust frontend access checks alone
 */

const FEATURE_DEFINITIONS = {
  resume: { label: 'AI Resume', creditCost: 5, free: 2, pro: 80, elite: 150 },
  cover_letter: { label: 'Cover Letter', creditCost: 3, free: 2, pro: Infinity, elite: Infinity },
  job_analysis: { label: 'Job Analysis', creditCost: 2, free: 2, pro: Infinity, elite: Infinity },
  follow_up_email: { label: 'Follow-Up Email', creditCost: 2, free: 2, pro: Infinity, elite: Infinity },
  mock_interview: { label: 'Mock Interview', creditCost: 10, free: 0, pro: 20, elite: Infinity },
  auto_apply: { label: 'Auto Apply', creditCost: 2, free: 0, pro: 50, elite: 200 },
  salary_negotiation: { label: 'Salary Negotiation', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  career_roadmap: { label: 'Career Roadmap', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  portfolio_ideas: { label: 'Portfolio Ideas', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  ats_score: { label: 'ATS Score', creditCost: 1, free: 0, pro: Infinity, elite: Infinity },
  advanced_ats_report: { label: 'Advanced ATS Report', creditCost: 3, free: 0, pro: Infinity, elite: Infinity },
  resume_templates: { label: 'Resume Templates', creditCost: 0, free: 3, pro: Infinity, elite: Infinity },
  resume_comparison: { label: 'Resume Comparison', creditCost: 0, free: false, pro: true, elite: true },
  library_editing: { label: 'Library Editing', creditCost: 0, free: true, pro: true, elite: true },
  pdf_download: { label: 'PDF Download', creditCost: 0, free: true, pro: true, elite: true },
  word_download: { label: 'Word Download', creditCost: 0, free: false, pro: true, elite: true },
};

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { featureKey } = await req.json();

    if (!featureKey) {
      return Response.json({ error: 'featureKey required' }, { status: 400 });
    }

    // Admins always have access
    if (user.role === 'admin') {
      return Response.json({ canUse: true, reason: 'admin' });
    }

    // Fetch user profile
    const profiles = await base44.asServiceRole.entities.UserProfile.filter({ created_by: user.email });
    const profile = profiles[0];

    if (!profile) {
      return Response.json({ canUse: false, reason: 'no_profile' });
    }

    const featureDef = FEATURE_DEFINITIONS[featureKey];
    if (!featureDef) {
      return Response.json({ canUse: false, reason: 'unknown_feature' });
    }

    const userEmail_lower = user.email.toLowerCase();

    // Check admin overrides
    const overrides = await base44.asServiceRole.entities.AdminOverride.filter({
      user_email: userEmail_lower,
      is_active: true,
    });

    // Feature unlock override
    const featureUnlock = overrides.find(
      o => o.override_type === 'feature_unlock' && o.features_affected?.includes(featureKey)
    );
    if (featureUnlock) {
      return Response.json({ canUse: true, reason: 'admin_override' });
    }

    // Feature lock override
    const featureLock = overrides.find(
      o => o.override_type === 'feature_lock' && o.features_affected?.includes(featureKey)
    );
    if (featureLock) {
      return Response.json({ canUse: false, reason: 'admin_lock' });
    }

    // Temporary access
    const tempAccess = overrides.find(
      o => o.override_type === 'temporary_access' &&
        o.features_affected?.includes(featureKey) &&
        o.temporary_until &&
        new Date(o.temporary_until) > new Date()
    );
    if (tempAccess) {
      return Response.json({ canUse: true, reason: 'temporary_access' });
    }

    // Check subscription plan
    const plan = profile.subscription_plan || 'free';
    const planLimit = featureDef[plan];
    const monthlyUsed = profile.usage_counts?.[featureKey] || 0;
    const userCredits = profile.ai_credits || 0;

    // Unlimited in plan
    if (planLimit === Infinity) {
      return Response.json({ canUse: true, reason: 'plan_unlimited' });
    }

    // Monthly limit available
    if (typeof planLimit === 'number' && planLimit > 0 && monthlyUsed < planLimit) {
      return Response.json({ canUse: true, reason: 'plan_monthly_limit' });
    }

    // Check credits
    if (userCredits >= featureDef.creditCost) {
      return Response.json({ canUse: true, reason: 'credit_purchase', creditsNeeded: featureDef.creditCost });
    }

    // Locked
    return Response.json({ canUse: false, reason: 'locked', creditsNeeded: featureDef.creditCost });
  } catch (error) {
    console.error('verifyFeatureAccess error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});