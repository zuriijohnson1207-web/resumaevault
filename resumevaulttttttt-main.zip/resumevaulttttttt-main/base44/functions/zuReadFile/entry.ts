import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Admin-only: serves real source code + full platform data to ZU.
 * Source files are embedded at deploy time so ZU can actually read them.
 */

// ─── EMBEDDED SOURCE CODE ────────────────────────────────────────────────────
// These are the actual live source files ZU can read and analyze.

const SOURCE_FILES = {

'hooks/usePlanLimits.js': `import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export const PLAN_LIMITS = {
  free:  { resume:2, cover_letter:2, job_analysis:2, follow_up_email:2, mock_interview:0, auto_apply:0, salary_negotiation:0, career_roadmap:0, portfolio_ideas:0 },
  pro:   { resume:80, cover_letter:Infinity, job_analysis:Infinity, follow_up_email:Infinity, mock_interview:20, auto_apply:50, salary_negotiation:Infinity, career_roadmap:Infinity, portfolio_ideas:Infinity },
  elite: { resume:150, cover_letter:Infinity, job_analysis:Infinity, follow_up_email:Infinity, mock_interview:Infinity, auto_apply:200, salary_negotiation:Infinity, career_roadmap:Infinity, portfolio_ideas:Infinity },
};

export const FEATURE_LABELS = { resume:'AI Resume', cover_letter:'Cover Letter', job_analysis:'Job Analysis', follow_up_email:'Follow-Up Email', mock_interview:'Mock Interview', auto_apply:'Auto Apply', salary_negotiation:'Salary Negotiation', career_roadmap:'Career Roadmap', portfolio_ideas:'Portfolio Ideas' };

export function usePlanLimits() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.UserProfile.list().then(profiles => { setProfile(profiles[0] || null); setLoading(false); }).catch(() => setLoading(false));
    const unsubscribe = base44.entities.UserProfile.subscribe((event) => {
      if (event.type === 'update' || event.type === 'create') setProfile(event.data);
    });
    return () => unsubscribe();
  }, []);

  const plan = profile?.subscription_plan || 'free';
  const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;
  const usageCounts = profile?.usage_counts || {};

  const canUse = (feature) => { const limit = limits[feature]; if (limit === Infinity) return true; if (limit === 0) return false; return (usageCounts[feature] || 0) < limit; };
  const getUsage = (feature) => { const limit = limits[feature]; const used = usageCounts[feature] || 0; return { used, limit, remaining: limit === Infinity ? Infinity : Math.max(0, limit - used) }; };

  const CREDIT_COSTS = { resume:5, cover_letter:3, job_analysis:2, follow_up_email:2, mock_interview:10, auto_apply:2, salary_negotiation:3, career_roadmap:3, portfolio_ideas:3 };

  const incrementUsage = async (feature) => {
    if (!profile) return;
    const newCounts = { ...usageCounts, [feature]: (usageCounts[feature] || 0) + 1 };
    const newCredits = Math.max(0, (profile.ai_credits || 0) - (CREDIT_COSTS[feature] || 1));
    await base44.entities.UserProfile.update(profile.id, { usage_counts: newCounts, ai_credits: newCredits });
    setProfile(p => ({ ...p, usage_counts: newCounts, ai_credits: newCredits }));
  };

  return { profile, plan, limits, canUse, getUsage, incrementUsage, loading, CREDIT_COSTS };
}`,

'App.jsx': `// App.jsx — router
// Routes: / => Dashboard, /auto-apply, /job-analyzer, /resume-builder, /resume-library,
// /cover-letter, /follow-up-email, /profile, /application-tracker, /analytics,
// /pricing, /reviews, /mock-interview, /salary-negotiation, /career-roadmap,
// /portfolio-ideas, /admin, /admin-assistant, /career-buddy
// Landing page at /landing (no auth wrapper)
// All other routes wrapped in AuthProvider + Layout (sidebar + outlet)`,

'entities/UserProfile': `{
  "name": "UserProfile",
  "properties": {
    "full_name": { "type": "string" },
    "email": { "type": "string" },
    "phone": { "type": "string" },
    "location": { "type": "string" },
    "linkedin_url": { "type": "string" },
    "portfolio_url": { "type": "string" },
    "professional_summary": { "type": "string" },
    "skills": { "type": "string" },
    "certifications": { "type": "string" },
    "experience": { "type": "array", "items": { "type": "object", "properties": { "job_title":{"type":"string"}, "company":{"type":"string"}, "start_date":{"type":"string"}, "end_date":{"type":"string"}, "current":{"type":"boolean"}, "description":{"type":"string"} } } },
    "education": { "type": "array", "items": { "type": "object", "properties": { "degree":{"type":"string"}, "school":{"type":"string"}, "field":{"type":"string"}, "graduation_year":{"type":"string"} } } },
    "subscription_plan": { "type": "string", "enum": ["free","pro","elite"], "default": "free" },
    "ai_credits": { "type": "number", "default": 0 },
    "monthly_uses": { "type": "number", "default": 0 },
    "usage_counts": { "type": "object", "properties": { "resume":{"type":"number"}, "cover_letter":{"type":"number"}, "job_analysis":{"type":"number"}, "follow_up_email":{"type":"number"}, "mock_interview":{"type":"number"}, "auto_apply":{"type":"number"}, "salary_negotiation":{"type":"number"}, "career_roadmap":{"type":"number"}, "portfolio_ideas":{"type":"number"} } }
  }
}`,

'entities/Resume': `{ "name": "Resume", "properties": { "title":{"type":"string"}, "job_title":{"type":"string"}, "company":{"type":"string"}, "content":{"type":"string"}, "type":{"type":"string","enum":["tailored","general","template"],"default":"tailored"} }, "required":["title"] }`,

'entities/Application': `{ "name": "Application", "properties": { "job_title":{"type":"string"}, "company":{"type":"string"}, "job_url":{"type":"string"}, "status":{"type":"string","enum":["saved","applied","interviewing","offer","rejected"],"default":"applied"}, "applied_date":{"type":"string","format":"date"}, "notes":{"type":"string"}, "salary_range":{"type":"string"}, "location":{"type":"string"} }, "required":["job_title","company"] }`,

'entities/JobApplication': `{ "name": "JobApplication", "properties": { "company":{"type":"string"}, "position":{"type":"string"}, "status":{"type":"string","enum":["saved","applied","interviewing","offer","rejected"],"default":"applied"}, "applied_date":{"type":"string","format":"date"}, "job_url":{"type":"string"}, "notes":{"type":"string"}, "salary_range":{"type":"string"} }, "required":["company","position"] }`,

'functions/createCheckout': `// Stripe Checkout session creator
// Products: pro_monthly ($29.99/mo sub), elite_monthly ($79.99/mo sub),
//           credits_100 ($9.99 one-time 100 credits), credits_250 ($19.99), credits_500 ($34.99)
// POST body: { product_key: string }
// Returns: { url: string } — Stripe Checkout URL
// Requires: STRIPE_SECRET_KEY env var`,

'functions/stripeWebhook': `// Stripe webhook handler
// Handles: checkout.session.completed → grants credits or sets subscription plan
// Handles: customer.subscription.deleted → resets to free plan
// Handles: customer.subscription.updated → updates plan
// Credit pack keys: credits_100 (100cr), credits_250 (250cr), credits_500 (500cr)
// Plan keys: pro_monthly → 'pro', elite_monthly → 'elite'
// Requires: STRIPE_WEBHOOK_SECRET, STRIPE_SECRET_KEY`,

};

// ─── HANDLER ──────────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const { file_path, fetch_platform_data } = body;

    // --- File content ---
    let fileContent = null;
    let fileError = null;

    if (file_path) {
      // Try exact key, then without extension, then partial match
      fileContent = SOURCE_FILES[file_path]
        || SOURCE_FILES[file_path.replace(/\.(jsx?|tsx?|json)$/, '')]
        || Object.entries(SOURCE_FILES).find(([k]) => k.includes(file_path.split('/').pop()))?.[1]
        || null;

      if (!fileContent) {
        fileError = `File "${file_path}" not embedded. Available: ${Object.keys(SOURCE_FILES).join(', ')}`;
      }
    }

    // --- Platform data ---
    let platformData = null;
    if (fetch_platform_data) {
      const [users, profiles, applications, resumes, jobApps] = await Promise.all([
        base44.asServiceRole.entities.User.list(),
        base44.asServiceRole.entities.UserProfile.list(),
        base44.asServiceRole.entities.Application.list('-created_date', 200),
        base44.asServiceRole.entities.Resume.list('-created_date', 200),
        base44.asServiceRole.entities.JobApplication.list('-created_date', 100),
      ]);

      platformData = {
        users: {
          total: users.length,
          admins: users.filter(u => u.role === 'admin').length,
          list: users.map(u => ({ id: u.id, email: u.email, name: u.full_name, role: u.role, created: u.created_date })),
        },
        profiles: {
          total: profiles.length,
          free: profiles.filter(p => !p.subscription_plan || p.subscription_plan === 'free').length,
          pro: profiles.filter(p => p.subscription_plan === 'pro').length,
          elite: profiles.filter(p => p.subscription_plan === 'elite').length,
          totalCredits: profiles.reduce((sum, p) => sum + (p.ai_credits || 0), 0),
          list: profiles.map(p => ({
            id: p.id, email: p.email || p.created_by, name: p.full_name,
            plan: p.subscription_plan, credits: p.ai_credits,
            monthly_uses: p.monthly_uses, usage_counts: p.usage_counts,
            created: p.created_date,
          })),
        },
        applications: {
          total: applications.length,
          byStatus: {
            saved: applications.filter(a => a.status === 'saved').length,
            applied: applications.filter(a => a.status === 'applied').length,
            interviewing: applications.filter(a => a.status === 'interviewing').length,
            offer: applications.filter(a => a.status === 'offer').length,
            rejected: applications.filter(a => a.status === 'rejected').length,
          },
          recent: applications.slice(0, 30).map(a => ({ company: a.company, title: a.job_title, status: a.status, date: a.applied_date, by: a.created_by })),
        },
        resumes: {
          total: resumes.length,
          byType: {
            tailored: resumes.filter(r => r.type === 'tailored').length,
            general: resumes.filter(r => r.type === 'general').length,
          },
        },
        jobApplications: {
          total: jobApps.length,
          byStatus: {
            saved: jobApps.filter(a => a.status === 'saved').length,
            applied: jobApps.filter(a => a.status === 'applied').length,
            interviewing: jobApps.filter(a => a.status === 'interviewing').length,
            offer: jobApps.filter(a => a.status === 'offer').length,
            rejected: jobApps.filter(a => a.status === 'rejected').length,
          },
        },
        availableFiles: Object.keys(SOURCE_FILES),
      };
    }

    return Response.json({
      file_path,
      file_content: fileContent,
      file_error: fileError,
      platform_data: platformData,
      available_files: Object.keys(SOURCE_FILES),
      timestamp: new Date().toISOString(),
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});