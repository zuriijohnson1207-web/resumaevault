import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * CRITICAL: Called when:
 * 1. Admin adds credits via AdminOverridePanel
 * 2. User purchases credits via Stripe
 * 3. Subscription is upgraded (grants bonus credits)
 * 
 * This function MUST:
 * - Update UserProfile.ai_credits
 * - Log to CreditHistory
 * - Return immediately (frontend listens to real-time update)
 */

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'POST only' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userEmail, creditsToAdd, reason, adminEmail } = await req.json();

    if (!userEmail || creditsToAdd === undefined || creditsToAdd < 0) {
      return Response.json({ error: 'Invalid params' }, { status: 400 });
    }

    // Only admin can add credits to others
    if (userEmail.toLowerCase() !== user.email.toLowerCase() && user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Fetch user profile (by created_by to ensure data consistency)
    const profiles = await base44.asServiceRole.entities.UserProfile.filter({
      created_by: userEmail,
    });

    if (!profiles || profiles.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = profiles[0];
    const currentCredits = profile.ai_credits || 0;
    const newCredits = currentCredits + creditsToAdd;

    // Update profile with new credits (THIS TRIGGERS REAL-TIME SYNC)
    await base44.asServiceRole.entities.UserProfile.update(profile.id, {
      ai_credits: newCredits,
    });

    // Log to credit history for audit trail
    await base44.asServiceRole.entities.CreditHistory.create({
      user_email: userEmail,
      action: 'add',
      feature: '',
      credits_spent: 0,
      credits_added: creditsToAdd,
      balance_after: newCredits,
      source: reason === 'admin' ? 'admin_override' : reason || 'stripe_purchase',
      stripe_session_id: reason?.sessionId || '',
      notes: `${adminEmail ? `Added by admin (${adminEmail})` : reason || 'Credits added'} • Reason: ${reason}`,
    }).catch(() => {});

    return Response.json({
      success: true,
      userEmail,
      oldCredits: currentCredits,
      newCredits,
      message: `✅ ${creditsToAdd} credits added. Features will unlock instantly.`,
    });
  } catch (error) {
    console.error('addCreditsAndSync error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});