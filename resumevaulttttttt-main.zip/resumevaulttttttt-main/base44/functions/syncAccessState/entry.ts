import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * Backend function to sync access state when credits/subscription changes
 * Called after:
 * - Admin adds/removes credits
 * - Admin applies/removes subscription override
 * - Stripe webhook updates subscription
 * 
 * Triggers real-time push to frontend without requiring refresh
 */
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userEmail, action } = await req.json();

    // Only admins can sync other users
    if (userEmail && userEmail.toLowerCase() !== user.email.toLowerCase()) {
      if (user.role !== 'admin') {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }
    }

    const targetEmail = userEmail || user.email;
    const targetEmailLower = targetEmail.toLowerCase();

    // Fetch user profile
    let profiles = await base44.entities.UserProfile.filter({ 
      created_by: targetEmail 
    });
    if (!profiles[0]) {
      profiles = await base44.entities.UserProfile.filter({ 
        created_by: targetEmailLower 
      });
    }

    if (!profiles[0]) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = profiles[0];

    // Fetch active overrides
    const overrides = await base44.entities.AdminOverride.filter({
      user_email: targetEmailLower,
      is_active: true,
    });

    // Calculate effective state
    const creditOverride = overrides.find(o => o.override_type === 'credit_add');
    const subscriptionOverride = overrides.find(
      o => ['plan_upgrade', 'plan_downgrade'].includes(o.override_type)
    );

    const effectiveState = {
      email: targetEmail,
      credits: profile.ai_credits || 0,
      plan: subscriptionOverride?.plan_granted || profile.subscription_plan || 'free',
      overrides: overrides.map(o => ({
        type: o.override_type,
        reason: o.reason,
        expiresAt: o.temporary_until,
      })),
      syncedAt: new Date().toISOString(),
    };

    // Force a profile update (triggers real-time subscription on frontend)
    await base44.entities.UserProfile.update(profile.id, {
      // Minimal touch to trigger real-time event
      updated_at: new Date().toISOString(),
    });

    // Also trigger override subscription
    if (action === 'credit_added' || action === 'subscription_changed') {
      // This ensures frontend gets real-time updates
      const overrideTrigger = await base44.entities.AdminOverride.filter({
        user_email: targetEmailLower,
      });
    }

    return Response.json({
      success: true,
      state: effectiveState,
      message: 'Access state synced',
    });
  } catch (error) {
    console.error('syncAccessState error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});