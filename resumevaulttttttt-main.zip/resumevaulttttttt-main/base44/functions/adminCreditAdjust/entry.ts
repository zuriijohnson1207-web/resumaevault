import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { profile_id, credits_delta, notes, user_email } = await req.json();

    if (!profile_id || credits_delta === undefined) {
      return Response.json({ error: 'profile_id and credits_delta are required' }, { status: 400 });
    }

    const profile = await base44.asServiceRole.entities.UserProfile.filter({ id: profile_id });
    if (!profile || profile.length === 0) {
      return Response.json({ error: 'Profile not found' }, { status: 404 });
    }

    const p = profile[0];
    const currentCredits = p.ai_credits || 0;
    const newCredits = Math.max(0, currentCredits + credits_delta);

    await base44.asServiceRole.entities.UserProfile.update(profile_id, { ai_credits: newCredits });

    await base44.asServiceRole.entities.CreditHistory.create({
      user_email: user_email || p.email || p.created_by || '',
      action: 'admin_adjustment',
      credits_spent: credits_delta < 0 ? Math.abs(credits_delta) : 0,
      credits_added: credits_delta > 0 ? credits_delta : 0,
      balance_after: newCredits,
      source: 'admin',
      notes: notes || `Admin adjustment by ${user.email}`,
    });

    return Response.json({ success: true, new_credits: newCredits });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});