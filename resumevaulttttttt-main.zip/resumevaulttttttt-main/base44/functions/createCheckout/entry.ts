import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

// Price map — replace with your actual Stripe Price IDs after creating products in Stripe dashboard
// For now these create one-time or subscription sessions dynamically via price_data
const PRODUCTS = {
  pro_monthly: { name: 'ResumeVaultGodAI Pro', amount: 2999, interval: 'month' },
  elite_monthly: { name: 'ResumeVaultGodAI Elite', amount: 7999, interval: 'month' },
  credits_50: { name: '50 AI Credits', amount: 999, type: 'one_time' },
  credits_150: { name: '150 AI Credits', amount: 2499, type: 'one_time' },
  credits_400: { name: '400 AI Credits', amount: 5999, type: 'one_time' },
  credits_1000: { name: '1000 AI Credits', amount: 12999, type: 'one_time' },
  // Legacy pack keys (Profile page previously used these)
  pack_50: { name: '50 AI Credits', amount: 999, type: 'one_time' },
  pack_150: { name: '150 AI Credits', amount: 2499, type: 'one_time' },
  pack_500: { name: '500 AI Credits', amount: 5999, type: 'one_time' },
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { product_key } = await req.json();
    const product = PRODUCTS[product_key];
    if (!product) {
      return Response.json({ error: 'Invalid product' }, { status: 400 });
    }

    const origin = req.headers.get('origin') || 'https://app.base44.com';

    let sessionConfig = {
      customer_email: user.email,
      metadata: { user_id: user.id, user_email: user.email, product_key },
      success_url: `${origin}/pricing?success=true&product=${product_key}`,
      cancel_url: `${origin}/pricing?cancelled=true`,
    };

    if (product.type === 'one_time') {
      sessionConfig.mode = 'payment';
      sessionConfig.line_items = [{
        price_data: {
          currency: 'usd',
          product_data: { name: product.name },
          unit_amount: product.amount,
        },
        quantity: 1,
      }];
    } else {
      sessionConfig.mode = 'subscription';
      sessionConfig.subscription_data = {
        metadata: { user_id: user.id, user_email: user.email, product_key },
      };
      sessionConfig.line_items = [{
        price_data: {
          currency: 'usd',
          product_data: { name: product.name },
          unit_amount: product.amount,
          recurring: { interval: product.interval },
        },
        quantity: 1,
      }];
    }

    const session = await stripe.checkout.sessions.create(sessionConfig);
    return Response.json({ url: session.url });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});